# Consumer ProGuard rules for the :app module (kept for parity with library builds).
