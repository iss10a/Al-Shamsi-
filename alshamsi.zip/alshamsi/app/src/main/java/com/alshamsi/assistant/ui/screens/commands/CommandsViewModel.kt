package com.alshamsi.assistant.ui.screens.commands

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.alshamsi.assistant.command.CommandCoordinator
import com.alshamsi.assistant.domain.model.CommandSource
import com.alshamsi.assistant.domain.model.Macro
import com.alshamsi.assistant.domain.model.MacroStep
import com.alshamsi.assistant.domain.repository.MacroRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@HiltViewModel
class CommandsViewModel @Inject constructor(
    private val macroRepository: MacroRepository,
    private val coordinator: CommandCoordinator
) : ViewModel() {

    val macros: StateFlow<List<Macro>> = macroRepository.observeMacros()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val busy: StateFlow<Boolean> = coordinator.busy

    fun save(name: String, description: String, stepsText: String, existingId: Long) {
        val cleanName = name.trim()
        if (cleanName.isEmpty()) return
        val steps = stepsText.split("\n")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .map { MacroStep(rawCommand = it) }
        if (steps.isEmpty()) return
        viewModelScope.launch {
            macroRepository.upsert(
                Macro(
                    id = existingId,
                    name = cleanName,
                    description = description.trim(),
                    steps = steps
                )
            )
        }
    }

    fun delete(macro: Macro) {
        viewModelScope.launch { macroRepository.delete(macro.id) }
    }

    fun run(macro: Macro) {
        viewModelScope.launch {
            coordinator.handle("شغل ماكرو " + macro.name, CommandSource.MACRO)
        }
    }
}
