package com.alshamsi.assistant.di

import com.alshamsi.assistant.data.ai.LocalLlmProvider
import com.alshamsi.assistant.data.ai.OfflineRuleProvider
import com.alshamsi.assistant.domain.ai.AiProvider
import dagger.Binds
import dagger.Module
import dagger.multibindings.IntoSet
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

/**
 * The only place that needs to change when a new free engine is added:
 * implement [AiProvider] and add one more `@Binds @IntoSet` method here.
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class AiModule {

    @Binds
    @IntoSet
    abstract fun bindOfflineProvider(provider: OfflineRuleProvider): AiProvider

    @Binds
    @IntoSet
    abstract fun bindLocalLlmProvider(provider: LocalLlmProvider): AiProvider
}
