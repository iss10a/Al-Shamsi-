package com.alshamsi.assistant.di

import android.content.Context
import androidx.room.Room
import com.alshamsi.assistant.core.Constants
import com.alshamsi.assistant.data.local.AlshamsiDatabase
import com.alshamsi.assistant.data.local.dao.ChatDao
import com.alshamsi.assistant.data.local.dao.LogDao
import com.alshamsi.assistant.data.local.dao.MacroDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AlshamsiDatabase =
        Room.databaseBuilder(context, AlshamsiDatabase::class.java, Constants.DATABASE_NAME)
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    fun provideChatDao(database: AlshamsiDatabase): ChatDao = database.chatDao()

    @Provides
    fun provideLogDao(database: AlshamsiDatabase): LogDao = database.logDao()

    @Provides
    fun provideMacroDao(database: AlshamsiDatabase): MacroDao = database.macroDao()
}
