package com.alshamsi.assistant.data.ai

import com.alshamsi.assistant.core.Constants
import com.alshamsi.assistant.core.IoDispatcher
import com.alshamsi.assistant.domain.ai.AiProvider
import com.alshamsi.assistant.domain.ai.AiRequest
import com.alshamsi.assistant.domain.ai.AiResult
import com.alshamsi.assistant.domain.ai.AiRole
import com.alshamsi.assistant.domain.model.AppSettings
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/**
 * Talks to a free, self-hosted model server that speaks the Ollama HTTP API
 * (Ollama, llama.cpp server with the Ollama shim, LM Studio, …).
 *
 * No account, no API key and no paid service is involved: the endpoint is a machine
 * the user owns, configured from the settings screen.
 */
@Singleton
class LocalLlmProvider @Inject constructor(
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) : AiProvider {

    override val id: String = Constants.PROVIDER_LOCAL_LLM

    override val displayName: String = "نموذج محلي مفتوح المصدر (Ollama)"

    override val requiresNetwork: Boolean = true

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    override suspend fun isAvailable(settings: AppSettings): Boolean = withContext(ioDispatcher) {
        val base = normalizeEndpoint(settings.localEndpoint) ?: return@withContext false
        runCatching {
            val request = Request.Builder().url(base + "/api/tags").get().build()
            client.newCall(request).execute().use { response -> response.isSuccessful }
        }.getOrDefault(false)
    }

    override suspend fun generate(request: AiRequest, settings: AppSettings): AiResult =
        withContext(ioDispatcher) {
            val base = normalizeEndpoint(settings.localEndpoint)
                ?: return@withContext AiResult.Unavailable("عنوان الخادم المحلي غير صحيح.")

            val payload = buildPayload(request, settings)
            val httpRequest = Request.Builder()
                .url(base + "/api/chat")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            runCatching {
                client.newCall(httpRequest).execute().use { response ->
                    if (!response.isSuccessful) {
                        return@use AiResult.Unavailable(
                            "الخادم المحلي رد بالرمز " + response.code + "."
                        )
                    }
                    val body = response.body?.string().orEmpty()
                    val text = extractContent(body)
                    if (text.isBlank()) {
                        AiResult.Unavailable("رد الخادم المحلي كان فارغاً.")
                    } else {
                        AiResult.Answer(text.trim(), id)
                    }
                }
            }.getOrElse { throwable ->
                AiResult.Unavailable(
                    "تعذر الوصول للخادم المحلي: " +
                        (throwable.message ?: throwable.javaClass.simpleName)
                )
            }
        }

    private fun buildPayload(request: AiRequest, settings: AppSettings): JSONObject {
        val messages = JSONArray()
        messages.put(messageObject("system", request.systemPrompt))
        if (request.screenContext.isNotBlank()) {
            messages.put(
                messageObject(
                    "system",
                    "محتوى الشاشة الحالي كما قرأه التطبيق:\n" + request.screenContext
                )
            )
        }
        for (turn in request.history) {
            val role = when (turn.role) {
                AiRole.USER -> "user"
                AiRole.ASSISTANT -> "assistant"
                AiRole.SYSTEM -> "system"
            }
            messages.put(messageObject(role, turn.content))
        }
        messages.put(messageObject("user", request.prompt))

        val options = JSONObject()
        options.put("temperature", 0.6)
        options.put("num_predict", 320)

        val payload = JSONObject()
        payload.put("model", settings.localModel.ifBlank { Constants.DEFAULT_LOCAL_MODEL })
        payload.put("messages", messages)
        payload.put("stream", false)
        payload.put("options", options)
        return payload
    }

    private fun messageObject(role: String, content: String): JSONObject {
        val obj = JSONObject()
        obj.put("role", role)
        obj.put("content", content)
        return obj
    }

    private fun extractContent(body: String): String {
        if (body.isBlank()) return ""
        return runCatching {
            val root = JSONObject(body)
            val message = root.optJSONObject("message")
            if (message != null) {
                message.optString("content")
            } else {
                root.optString("response")
            }
        }.getOrDefault("")
    }

    private fun normalizeEndpoint(raw: String): String? {
        val trimmed = raw.trim().trimEnd('/')
        if (trimmed.isEmpty()) return null
        val withScheme = if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
            trimmed
        } else {
            "http://" + trimmed
        }
        return if (withScheme.length > 8) withScheme else null
    }
}
