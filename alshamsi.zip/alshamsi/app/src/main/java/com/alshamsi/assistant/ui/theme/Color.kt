package com.alshamsi.assistant.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

val DesertGold = Color(0xFFC79A2E)
val DesertGoldLight = Color(0xFFF4C542)
val NightBlue = Color(0xFF0B1F3A)
val NightBlueLight = Color(0xFF1B3B63)
val SandLight = Color(0xFFFBF6EC)
val SandDark = Color(0xFF141A20)
val PalmGreen = Color(0xFF2E7D62)
val ErrorRed = Color(0xFFB3261E)

val LightColors = lightColorScheme(
    primary = NightBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E3F7),
    onPrimaryContainer = Color(0xFF07182C),
    secondary = DesertGold,
    onSecondary = Color(0xFF241A00),
    secondaryContainer = Color(0xFFFBE6B4),
    onSecondaryContainer = Color(0xFF241A00),
    tertiary = PalmGreen,
    onTertiary = Color.White,
    background = SandLight,
    onBackground = Color(0xFF1A1C1E),
    surface = Color(0xFFFFFDF8),
    onSurface = Color(0xFF1A1C1E),
    surfaceVariant = Color(0xFFE6E1D8),
    onSurfaceVariant = Color(0xFF48454E),
    outline = Color(0xFF7A7768),
    error = ErrorRed,
    onError = Color.White
)

val DarkColors = darkColorScheme(
    primary = Color(0xFFA7C8FF),
    onPrimary = Color(0xFF07182C),
    primaryContainer = NightBlueLight,
    onPrimaryContainer = Color(0xFFD6E3F7),
    secondary = DesertGoldLight,
    onSecondary = Color(0xFF3D2E00),
    secondaryContainer = Color(0xFF574400),
    onSecondaryContainer = Color(0xFFFBE6B4),
    tertiary = Color(0xFF8FD6BA),
    onTertiary = Color(0xFF00382A),
    background = SandDark,
    onBackground = Color(0xFFE4E2DC),
    surface = Color(0xFF1A2026),
    onSurface = Color(0xFFE4E2DC),
    surfaceVariant = Color(0xFF44474A),
    onSurfaceVariant = Color(0xFFC7C6CA),
    outline = Color(0xFF8E9192),
    error = Color(0xFFF2B8B5),
    onError = Color(0xFF601410)
)
