package com.alshamsi.assistant.device.control

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import com.alshamsi.assistant.core.OperationResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FlashlightController @Inject constructor(
    @ApplicationContext private val context: Context
) {

    private val cameraManager: CameraManager?
        get() = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager

    fun hasFlash(): Boolean = runCatching { torchCameraId() != null }.getOrDefault(false)

    private fun torchCameraId(): String? {
        val manager = cameraManager ?: return null
        for (id in manager.cameraIdList) {
            val characteristics = manager.getCameraCharacteristics(id)
            val available = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE)
            val facing = characteristics.get(CameraCharacteristics.LENS_FACING)
            if (available == true && facing == CameraCharacteristics.LENS_FACING_BACK) {
                return id
            }
        }
        return manager.cameraIdList.firstOrNull { id ->
            manager.getCameraCharacteristics(id)
                .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
    }

    fun setTorch(enabled: Boolean): OperationResult<Boolean> =
        OperationResult.runCatchingResult("تعذر التحكم بالكشاف") {
            val manager = cameraManager ?: error("خدمة الكاميرا غير متاحة")
            val id = torchCameraId() ?: error("لا يوجد كشاف في هذا الجهاز")
            manager.setTorchMode(id, enabled)
            enabled
        }
}
