package com.alshamsi.assistant.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.alshamsi.assistant.domain.ai.AiProviderRegistry
import com.alshamsi.assistant.domain.model.AppSettings
import com.alshamsi.assistant.domain.model.ThemeMode
import com.alshamsi.assistant.domain.repository.ChatRepository
import com.alshamsi.assistant.domain.repository.SettingsRepository
import com.alshamsi.assistant.voice.SpeechEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ProviderOption(val id: String, val label: String, val requiresNetwork: Boolean)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val chatRepository: ChatRepository,
    private val speechEngine: SpeechEngine,
    aiProviderRegistry: AiProviderRegistry
) : ViewModel() {

    val settings: StateFlow<AppSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    val providers: List<ProviderOption> = aiProviderRegistry.all().map { provider ->
        ProviderOption(provider.id, provider.displayName, provider.requiresNetwork)
    }

    fun setTheme(mode: ThemeMode) = launchUpdate { settingsRepository.setThemeMode(mode) }

    fun setDynamicColor(enabled: Boolean) =
        launchUpdate { settingsRepository.setDynamicColor(enabled) }

    fun setSpokenReplies(enabled: Boolean) =
        launchUpdate { settingsRepository.setSpokenReplies(enabled) }

    fun setWakeWord(enabled: Boolean) =
        launchUpdate { settingsRepository.setWakeWordEnabled(enabled) }

    fun setSpeechRate(rate: Float) = launchUpdate {
        settingsRepository.setSpeechRate(rate)
        speechEngine.applyVoiceSettings(rate, settings.value.speechPitch)
    }

    fun setSpeechPitch(pitch: Float) = launchUpdate {
        settingsRepository.setSpeechPitch(pitch)
        speechEngine.applyVoiceSettings(settings.value.speechRate, pitch)
    }

    fun setConfirmDangerous(enabled: Boolean) =
        launchUpdate { settingsRepository.setConfirmDangerousActions(enabled) }

    fun setProvider(id: String) = launchUpdate { settingsRepository.setAiProvider(id) }

    fun setEndpoint(value: String) = launchUpdate { settingsRepository.setLocalEndpoint(value) }

    fun setModel(value: String) = launchUpdate { settingsRepository.setLocalModel(value) }

    fun setRetention(days: Int) = launchUpdate { settingsRepository.setLogRetentionDays(days) }

    fun clearChat() = launchUpdate { chatRepository.clear() }

    fun previewVoice() {
        speechEngine.speak("هلا والله، أنا الشامسي. تم ضبط الصوت.")
    }

    private fun launchUpdate(block: suspend () -> Unit) {
        viewModelScope.launch { block() }
    }
}
