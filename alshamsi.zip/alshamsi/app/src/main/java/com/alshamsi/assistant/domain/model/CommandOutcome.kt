package com.alshamsi.assistant.domain.model

data class CommandOutcome(
    val status: LogStatus,
    val userMessage: String,
    val spokenMessage: String = userMessage,
    val details: String = ""
) {
    val isSuccess: Boolean get() = status == LogStatus.SUCCESS

    companion object {
        fun success(message: String, details: String = ""): CommandOutcome =
            CommandOutcome(LogStatus.SUCCESS, message, message, details)

        fun failure(message: String, details: String = ""): CommandOutcome =
            CommandOutcome(LogStatus.FAILURE, message, message, details)

        fun cancelled(message: String = "تمام، ما نفذت شي."): CommandOutcome =
            CommandOutcome(LogStatus.CANCELLED, message, message, "")

        fun permissionRequired(message: String, details: String = ""): CommandOutcome =
            CommandOutcome(LogStatus.PERMISSION_REQUIRED, message, message, details)
    }
}
