package com.alshamsi.assistant.domain.model

data class NotificationInfo(
    val key: String,
    val packageName: String,
    val appLabel: String,
    val title: String,
    val text: String,
    val postedAt: Long,
    val canReply: Boolean
)
