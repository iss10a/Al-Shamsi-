package com.alshamsi.assistant.domain.repository

import com.alshamsi.assistant.domain.model.Macro
import kotlinx.coroutines.flow.Flow

interface MacroRepository {
    fun observeMacros(): Flow<List<Macro>>
    suspend fun getById(id: Long): Macro?
    suspend fun findByName(name: String): Macro?
    suspend fun upsert(macro: Macro): Long
    suspend fun delete(id: Long)
    suspend fun markRun(id: Long, timestamp: Long)
}
