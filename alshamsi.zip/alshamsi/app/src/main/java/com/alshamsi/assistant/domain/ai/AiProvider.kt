package com.alshamsi.assistant.domain.ai

import com.alshamsi.assistant.domain.model.AppSettings

/**
 * Abstraction over any assistant "brain".
 *
 * Adding a new engine later only requires implementing this interface and binding it
 * into the Hilt multibinding set in [com.alshamsi.assistant.di.AiModule] — no other
 * layer of the application needs to change. Only free / self-hosted engines are used.
 */
interface AiProvider {

    /** Stable identifier persisted in the settings store. */
    val id: String

    /** Human readable Arabic name shown in the settings screen. */
    val displayName: String

    /** Whether the provider needs a reachable network endpoint to answer. */
    val requiresNetwork: Boolean

    /** Quick availability probe; providers that cannot answer are skipped. */
    suspend fun isAvailable(settings: AppSettings): Boolean

    /** Produces a reply for [request]; must never throw. */
    suspend fun generate(request: AiRequest, settings: AppSettings): AiResult
}

data class AiRequest(
    val prompt: String,
    val history: List<AiTurn> = emptyList(),
    val systemPrompt: String = DEFAULT_SYSTEM_PROMPT,
    val screenContext: String = ""
) {
    companion object {
        const val DEFAULT_SYSTEM_PROMPT =
            "أنت «الشامسي»، مساعد شخصي عربي يعمل داخل هاتف أندرويد. " +
                "تحدث بالعربية بلهجة خليجية مهذبة ومختصرة، وجملك قصيرة. " +
                "لا تخترع تنفيذ أوامر لم تُطلب منك، وإذا لم تفهم الطلب اطلب توضيحاً."
    }
}

data class AiTurn(val role: AiRole, val content: String)

enum class AiRole { USER, ASSISTANT, SYSTEM }

sealed class AiResult {
    data class Answer(val text: String, val providerId: String) : AiResult()
    data class Unavailable(val reason: String) : AiResult()
}
