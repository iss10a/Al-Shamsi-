package com.alshamsi.assistant.command

import com.alshamsi.assistant.core.ArabicText
import com.alshamsi.assistant.domain.model.DeviceCommand
import com.alshamsi.assistant.domain.model.NavigationAction
import com.alshamsi.assistant.domain.model.SettingsSection
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Converts free Arabic (and a few English) phrases into a [DeviceCommand].
 * Detection runs on normalised text while arguments are extracted from the original
 * string so that file names and URLs keep their exact spelling.
 */
@Singleton
class CommandParser @Inject constructor() {

    private val affirmations = listOf("نعم", "ايه", "اي", "اكيد", "تمام", "موافق", "ok", "yes")
    private val denials = listOf("لا", "لاء", "الغاء", "الغ", "كنسل", "no", "cancel")
    private val stopWords = listOf("وقف", "توقف", "اسكت", "مع السلامه", "الى اللقاء", "خلاص")

    private val sequenceSeparators = listOf(" ثم ", " وبعدين ", " بعدين ", " وبعدها ", "؛")

    fun parse(raw: String): DeviceCommand {
        val input = raw.trim()
        if (input.isEmpty()) return DeviceCommand.Chat(raw)
        val normalized = ArabicText.normalize(input)

        if (affirmations.any { ArabicText.normalize(it) == normalized }) return DeviceCommand.Affirm
        if (denials.any { ArabicText.normalize(it) == normalized }) return DeviceCommand.Deny
        if (stopWords.any { normalized == ArabicText.normalize(it) }) {
            return DeviceCommand.StopListening
        }

        val parts = splitSequence(input)
        if (parts.size > 1) {
            val commands = parts.map { parseSingle(it) }
            return DeviceCommand.Sequence(commands)
        }
        return parseSingle(input)
    }

    private fun splitSequence(input: String): List<String> {
        var segments = listOf(input)
        for (separator in sequenceSeparators) {
            segments = segments.flatMap { segment ->
                segment.split(separator).map { it.trim() }
            }
        }
        return segments.filter { it.isNotBlank() }
    }

    private fun parseSingle(raw: String): DeviceCommand {
        val input = raw.trim()
        val text = ArabicText.normalize(input)

        // ---------------- macros ----------------
        if (containsAny(text, listOf("شغل ماكرو", "نفذ ماكرو", "شغل الماكرو", "نفذ الماكرو"))) {
            val name = tail(input, listOf("شغل ماكرو", "نفذ ماكرو", "شغل الماكرو", "نفذ الماكرو"))
            if (name.isNotBlank()) return DeviceCommand.RunMacro(name)
        }

        // ---------------- flashlight ----------------
        if (containsAny(text, listOf("كشاف", "الفلاش", "المصباح", "flashlight", "torch"))) {
            val turnOff = containsAny(
                text,
                listOf("اطفي", "طفي", "اطفئ", "اقفل", "اوقف", "سكر", "off")
            )
            return DeviceCommand.Flashlight(!turnOff)
        }

        // ---------------- notifications ----------------
        if (containsAny(text, listOf("رد على", "جاوب على", "ارسل رد"))) {
            val body = tail(input, listOf("رد على", "جاوب على", "ارسل رد"))
            val separatorIndex = indexOfAny(body, listOf(" بكلمه ", " وقل ", " بقول ", " بالنص ", ":"))
            return if (separatorIndex != null) {
                val appPart = body.substring(0, separatorIndex.first).trim()
                val messagePart = body.substring(separatorIndex.first + separatorIndex.second).trim()
                DeviceCommand.ReplyToNotification(appPart, messagePart)
            } else {
                DeviceCommand.ReplyToNotification("", body)
            }
        }
        if (containsAny(text, listOf("اقرا الاشعارات", "الاشعارات الجديده", "وش الاشعارات", "شنو الاشعارات", "اقرا اشعاراتي"))) {
            return DeviceCommand.ReadNotifications
        }

        // ---------------- screen reading ----------------
        if (containsAny(text, listOf("اقرا الشاشه", "وش على الشاشه", "شنو على الشاشه", "اقرا لي الشاشه", "محتوى الشاشه"))) {
            return DeviceCommand.ReadScreen
        }

        // ---------------- gestures ----------------
        if (containsAny(text, listOf("اسحب", "سحب", "swipe"))) {
            val numbers = ArabicText.extractNumbers(input)
            if (numbers.size >= 4) {
                return DeviceCommand.Swipe(numbers[0], numbers[1], numbers[2], numbers[3])
            }
            val upwards = containsAny(text, listOf("لفوق", "للاعلى", "فوق", "up"))
            return DeviceCommand.Scroll(forward = !upwards)
        }
        if (containsAny(text, listOf("مرر", "نزل الصفحه", "طلع الصفحه", "scroll"))) {
            val up = containsAny(text, listOf("لفوق", "للاعلى", "طلع", "up"))
            return DeviceCommand.Scroll(forward = !up)
        }
        if (containsAny(text, listOf("اضغط", "انقر", "كلك", "tap", "click"))) {
            val numbers = ArabicText.extractNumbers(input)
            if (numbers.size >= 2) {
                return DeviceCommand.Tap(numbers[0], numbers[1])
            }
            val label = tail(input, listOf("اضغط على", "انقر على", "اضغط", "انقر", "كلك على", "كلك"))
            if (label.isNotBlank()) return DeviceCommand.ClickText(label)
        }
        if (containsAny(text, listOf("اكتب", "دون", "type"))) {
            val body = tail(input, listOf("اكتب", "دون", "type"))
            if (body.isNotBlank()) return DeviceCommand.TypeText(body)
        }

        // ---------------- navigation ----------------
        if (containsAny(text, listOf("ارجع", "رجوع", "الخلف", "back"))) {
            return DeviceCommand.GlobalNavigation(NavigationAction.BACK)
        }
        if (containsAny(text, listOf("الشاشه الرئيسيه", "الصفحه الرئيسيه", "روح للرئيسيه", "هوم", "home"))) {
            return DeviceCommand.GlobalNavigation(NavigationAction.HOME)
        }
        if (containsAny(text, listOf("التطبيقات الاخيره", "المهام الاخيره", "recents"))) {
            return DeviceCommand.GlobalNavigation(NavigationAction.RECENTS)
        }
        if (containsAny(text, listOf("افتح الاشعارات", "شريط الاشعارات", "نزل الشريط"))) {
            return DeviceCommand.GlobalNavigation(NavigationAction.NOTIFICATIONS)
        }
        if (containsAny(text, listOf("الاعدادات السريعه", "لوحه الاعدادات السريعه"))) {
            return DeviceCommand.GlobalNavigation(NavigationAction.QUICK_SETTINGS)
        }
        if (containsAny(text, listOf("اقفل الشاشه", "قفل الشاشه", "نوم الشاشه"))) {
            return DeviceCommand.GlobalNavigation(NavigationAction.LOCK_SCREEN)
        }
        if (containsAny(text, listOf("اغلق التطبيق", "سكر التطبيق", "اقفل التطبيق", "اخرج من التطبيق", "close app"))) {
            return DeviceCommand.CloseCurrentApp
        }

        // ---------------- files ----------------
        if (containsAny(text, listOf("انسخ الملف", "انسخ ملف", "نسخ الملف", "انسخ"))) {
            val body = tail(input, listOf("انسخ الملف", "انسخ ملف", "نسخ الملف", "انسخ"))
            val pair = splitOnDestination(body)
            if (pair != null) return DeviceCommand.CopyFile(pair.first, pair.second)
        }
        if (containsAny(text, listOf("انقل الملف", "انقل ملف", "نقل الملف", "انقل"))) {
            val body = tail(input, listOf("انقل الملف", "انقل ملف", "نقل الملف", "انقل"))
            val pair = splitOnDestination(body)
            if (pair != null) return DeviceCommand.MoveFile(pair.first, pair.second)
        }
        if (containsAny(text, listOf("اعد تسميه", "غير اسم", "سم الملف", "rename"))) {
            val body = tail(input, listOf("اعد تسميه", "أعد تسمية", "غير اسم", "سم الملف", "rename"))
            val pair = splitOnDestination(body)
            if (pair != null) return DeviceCommand.RenameFile(pair.first, pair.second)
        }
        if (containsAny(text, listOf("احذف", "امسح الملف", "شيل الملف", "delete"))) {
            val body = tail(input, listOf("احذف الملف", "احذف ملف", "احذف", "امسح الملف", "شيل الملف", "delete"))
            if (body.isNotBlank()) return DeviceCommand.DeleteFile(body)
        }
        if (containsAny(text, listOf("شارك الملف", "ارسل الملف", "شارك", "share"))) {
            val body = tail(input, listOf("شارك الملف", "ارسل الملف", "شارك", "share"))
            if (body.isNotBlank()) return DeviceCommand.ShareFile(body)
        }
        if (containsAny(text, listOf("دور على ملف", "ابحث عن ملف", "ابحث في الملفات", "لقي لي ملف", "دور ملف"))) {
            val body = tail(
                input,
                listOf("دور على ملف", "ابحث عن ملف", "ابحث في الملفات", "لقي لي ملف", "دور ملف")
            )
            if (body.isNotBlank()) return DeviceCommand.SearchFiles(body)
        }

        // ---------------- links and search ----------------
        if (containsAny(text, listOf("افتح رابط", "افتح الرابط", "افتح موقع", "افتح الموقع", "open url"))) {
            val body = tail(input, listOf("افتح رابط", "افتح الرابط", "افتح موقع", "افتح الموقع", "open url"))
            if (body.isNotBlank()) return DeviceCommand.OpenUrl(body.replace(" ", ""))
        }
        if (Regex("(https?://|www\\.)").containsMatchIn(text)) {
            val url = Regex("(https?://\\S+|www\\.\\S+)").find(input)?.value
            if (!url.isNullOrBlank()) return DeviceCommand.OpenUrl(url)
        }
        if (containsAny(text, listOf("ابحث في قوقل", "ابحث في جوجل", "ابحث عن", "دور على", "ابحث", "search"))) {
            val body = tail(
                input,
                listOf("ابحث في قوقل عن", "ابحث في جوجل عن", "ابحث في قوقل", "ابحث في جوجل", "ابحث عن", "دور على", "ابحث", "search")
            )
            if (body.isNotBlank()) return DeviceCommand.WebSearch(body)
        }

        // ---------------- system intents ----------------
        if (containsAny(text, listOf("الكاميرا", "صور", "camera")) &&
            containsAny(text, listOf("افتح", "شغل", "open"))
        ) {
            return DeviceCommand.OpenCamera
        }
        if (containsAny(text, listOf("مدير الملفات", "الملفات")) &&
            containsAny(text, listOf("افتح", "شغل", "open"))
        ) {
            return DeviceCommand.OpenFilesApp
        }
        if (containsAny(text, listOf("الاعدادات", "اعدادات", "الإعدادات", "settings"))) {
            return DeviceCommand.OpenSettingsSection(settingsSection(text))
        }
        if (containsAny(text, listOf("شغل نيه", "نفذ نيه", "intent"))) {
            val body = tail(input, listOf("شغل نيه", "نفذ نيه", "intent"))
            val tokens = body.split(" ").filter { it.isNotBlank() }
            if (tokens.isNotEmpty()) {
                val action = tokens.first()
                val data = tokens.drop(1).joinToString(" ").ifBlank { null }
                return DeviceCommand.LaunchIntent(action, data)
            }
        }

        // ---------------- applications ----------------
        if (containsAny(text, listOf("افتح", "شغل", "ابدا", "open", "launch"))) {
            val body = tail(input, listOf("افتح لي", "افتح", "شغل لي", "شغل", "ابدا", "open", "launch"))
            val cleaned = body.removePrefix("تطبيق").removePrefix("برنامج").trim()
            if (cleaned.isNotBlank()) return DeviceCommand.OpenApp(cleaned)
        }

        return DeviceCommand.Chat(raw.trim())
    }

    private fun settingsSection(text: String): SettingsSection = when {
        containsAny(text, listOf("واي فاي", "الشبكه اللاسلكيه", "wifi")) -> SettingsSection.WIFI
        containsAny(text, listOf("بلوتوث", "bluetooth")) -> SettingsSection.BLUETOOTH
        containsAny(text, listOf("الشاشه", "السطوع", "display")) -> SettingsSection.DISPLAY
        containsAny(text, listOf("الصوت", "sound")) -> SettingsSection.SOUND
        containsAny(text, listOf("البطاريه", "battery")) -> SettingsSection.BATTERY
        containsAny(text, listOf("التخزين", "الذاكره", "storage")) -> SettingsSection.STORAGE
        containsAny(text, listOf("التطبيقات", "apps")) -> SettingsSection.APPS
        containsAny(text, listOf("الموقع", "gps", "location")) -> SettingsSection.LOCATION
        containsAny(text, listOf("الامان", "security")) -> SettingsSection.SECURITY
        containsAny(text, listOf("الوصول", "accessibility")) -> SettingsSection.ACCESSIBILITY
        containsAny(text, listOf("الاشعارات", "notifications")) -> SettingsSection.NOTIFICATIONS
        containsAny(text, listOf("التاريخ", "الوقت", "date")) -> SettingsSection.DATE
        else -> SettingsSection.MAIN
    }

    private fun splitOnDestination(body: String): Pair<String, String>? {
        val markers = listOf(" الى ", " إلى ", " ل ", " باسم ", " الي ", "->", " to ")
        val index = indexOfAny(body, markers) ?: return null
        val source = body.substring(0, index.first).trim()
        val destination = body.substring(index.first + index.second).trim()
        if (source.isBlank() || destination.isBlank()) return null
        return source to destination
    }

    /** Returns index and length of the first marker found in [body]. */
    private fun indexOfAny(body: String, markers: List<String>): Pair<Int, Int>? {
        var best: Pair<Int, Int>? = null
        for (marker in markers) {
            val index = body.indexOf(marker, ignoreCase = true)
            if (index >= 0 && (best == null || index < best.first)) {
                best = index to marker.length
            }
        }
        return best
    }

    private fun containsAny(normalizedText: String, keys: List<String>): Boolean =
        keys.any { key ->
            val normalizedKey = ArabicText.normalize(key)
            normalizedKey.isNotEmpty() && normalizedText.contains(normalizedKey)
        }

    private fun tail(raw: String, markers: List<String>): String {
        for (marker in markers) {
            val index = raw.indexOf(marker, ignoreCase = true)
            if (index >= 0) {
                return raw.substring(index + marker.length)
                    .trim()
                    .trim('،', '.', '!', '؟', ':', '"')
                    .trim()
            }
        }
        val normalizedTail = ArabicText.after(raw, markers)
        return normalizedTail?.trim().orEmpty()
    }
}
