package com.alshamsi.assistant.ui.screens.permissions

import androidx.lifecycle.ViewModel
import com.alshamsi.assistant.device.control.DeviceController
import com.alshamsi.assistant.device.control.PermissionsChecker
import com.alshamsi.assistant.domain.model.PermissionItem
import com.alshamsi.assistant.domain.model.PermissionKey
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

@HiltViewModel
class PermissionsViewModel @Inject constructor(
    private val permissionsChecker: PermissionsChecker,
    private val deviceController: DeviceController
) : ViewModel() {

    private val _items = MutableStateFlow<List<PermissionItem>>(emptyList())
    val items: StateFlow<List<PermissionItem>> = _items.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        _items.value = permissionsChecker.snapshot()
    }

    /** Returns true when the request is handled by a system screen instead of a runtime dialog. */
    fun openSystemScreen(key: PermissionKey): Boolean = when (key) {
        PermissionKey.ACCESSIBILITY -> {
            deviceController.openAccessibilitySettings()
            true
        }

        PermissionKey.NOTIFICATION_LISTENER -> {
            deviceController.openNotificationListenerSettings()
            true
        }

        PermissionKey.ALL_FILES_ACCESS -> {
            deviceController.openAllFilesAccessSettings()
            true
        }

        PermissionKey.MICROPHONE,
        PermissionKey.POST_NOTIFICATIONS,
        PermissionKey.MEDIA_ACCESS -> false
    }

    fun openAppDetails() {
        deviceController.openAppDetailsSettings()
    }
}
