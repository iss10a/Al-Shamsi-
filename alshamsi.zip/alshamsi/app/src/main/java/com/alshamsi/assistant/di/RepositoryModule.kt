package com.alshamsi.assistant.di

import com.alshamsi.assistant.data.repository.ChatRepositoryImpl
import com.alshamsi.assistant.data.repository.LogRepositoryImpl
import com.alshamsi.assistant.data.repository.MacroRepositoryImpl
import com.alshamsi.assistant.data.settings.SettingsRepositoryImpl
import com.alshamsi.assistant.domain.repository.ChatRepository
import com.alshamsi.assistant.domain.repository.LogRepository
import com.alshamsi.assistant.domain.repository.MacroRepository
import com.alshamsi.assistant.domain.repository.SettingsRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindChatRepository(impl: ChatRepositoryImpl): ChatRepository

    @Binds
    @Singleton
    abstract fun bindLogRepository(impl: LogRepositoryImpl): LogRepository

    @Binds
    @Singleton
    abstract fun bindMacroRepository(impl: MacroRepositoryImpl): MacroRepository

    @Binds
    @Singleton
    abstract fun bindSettingsRepository(impl: SettingsRepositoryImpl): SettingsRepository
}
