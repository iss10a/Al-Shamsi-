package com.alshamsi.assistant.domain.model

data class ChatMessage(
    val id: Long = 0L,
    val content: String,
    val role: MessageRole,
    val timestamp: Long = System.currentTimeMillis(),
    val source: CommandSource = CommandSource.TEXT
)

enum class MessageRole { USER, ASSISTANT, SYSTEM }

enum class CommandSource { TEXT, VOICE, MACRO, QUICK_ACTION }
