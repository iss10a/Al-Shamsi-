package com.alshamsi.assistant.domain.model

data class PermissionItem(
    val key: PermissionKey,
    val title: String,
    val reason: String,
    val granted: Boolean
)

enum class PermissionKey {
    ACCESSIBILITY,
    NOTIFICATION_LISTENER,
    MICROPHONE,
    POST_NOTIFICATIONS,
    ALL_FILES_ACCESS,
    MEDIA_ACCESS
}
