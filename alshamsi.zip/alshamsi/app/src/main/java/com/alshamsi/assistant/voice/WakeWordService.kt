package com.alshamsi.assistant.voice

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.alshamsi.assistant.MainActivity
import com.alshamsi.assistant.R
import com.alshamsi.assistant.command.CommandCoordinator
import com.alshamsi.assistant.core.ArabicText
import com.alshamsi.assistant.core.Constants
import com.alshamsi.assistant.domain.model.CommandSource
import com.alshamsi.assistant.domain.repository.SettingsRepository
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Always-on listener built on the free on-device speech recogniser shipped with Android.
 * It stays in wake-word mode until it hears «الشامسي» / «يا الشامسي», then forwards the
 * next utterance to [CommandCoordinator].
 */
@AndroidEntryPoint
class WakeWordService : Service() {

    @Inject
    lateinit var coordinator: CommandCoordinator

    @Inject
    lateinit var speechEngine: SpeechEngine

    @Inject
    lateinit var settingsRepository: SettingsRepository

    private val scope: CoroutineScope =
        CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private var recognizer: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var awake = false
    private var stopping = false

    private val wakeWords = listOf(
        "الشامسي",
        "يا الشامسي",
        "ياالشامسي",
        "شامسي",
        "يا شامسي"
    )

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForegroundCompat()
        speechEngine.initialize()
        VoiceState.setServiceRunning(true)
        scope.launch {
            val settings = settingsRepository.current()
            speechEngine.applyVoiceSettings(settings.speechRate, settings.speechPitch)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == Constants.ACTION_STOP_VOICE) {
            shutdown()
            return START_NOT_STICKY
        }
        if (!hasMicrophonePermission()) {
            VoiceState.setPhase(ListeningPhase.IDLE)
            shutdown()
            return START_NOT_STICKY
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            VoiceState.setPhase(ListeningPhase.IDLE)
            shutdown()
            return START_NOT_STICKY
        }
        ensureRecognizer()
        restartListening(300L)
        return START_STICKY
    }

    override fun onDestroy() {
        stopping = true
        handler.removeCallbacksAndMessages(null)
        runCatching { recognizer?.destroy() }
        recognizer = null
        VoiceState.setServiceRunning(false)
        scope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ recogniser

    private fun ensureRecognizer() {
        if (recognizer != null) return
        val instance = SpeechRecognizer.createSpeechRecognizer(this)
        instance.setRecognitionListener(listener)
        recognizer = instance
    }

    private fun buildRecognizerIntent(): Intent =
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                putExtra(RecognizerIntent.EXTRA_ENABLE_FORMATTING, RecognizerIntent.FORMATTING_OPTIMIZE_LATENCY)
            }
        }

    private fun restartListening(delayMillis: Long) {
        if (stopping) return
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({
            if (stopping) return@postDelayed
            ensureRecognizer()
            VoiceState.setPhase(
                if (awake) ListeningPhase.LISTENING_FOR_COMMAND
                else ListeningPhase.WAITING_FOR_WAKE_WORD
            )
            runCatching {
                recognizer?.cancel()
                recognizer?.startListening(buildRecognizerIntent())
            }
        }, delayMillis)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) = Unit

        override fun onBeginningOfSpeech() = Unit

        override fun onRmsChanged(rmsdB: Float) = Unit

        override fun onBufferReceived(buffer: ByteArray?) = Unit

        override fun onEndOfSpeech() = Unit

        override fun onError(error: Int) {
            val delayMillis = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> 250L

                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 900L
                SpeechRecognizer.ERROR_CLIENT -> 600L
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    shutdown()
                    return
                }

                else -> 1_200L
            }
            restartListening(delayMillis)
        }

        override fun onResults(results: Bundle?) {
            val spoken = firstResult(results)
            if (spoken.isNotBlank()) {
                VoiceState.setLastHeard(spoken)
                onHeard(spoken)
            } else {
                restartListening(300L)
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            if (awake) return
            val spoken = firstResult(partialResults)
            if (spoken.isNotBlank() && containsWakeWord(spoken)) {
                wakeUp()
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) = Unit
    }

    private fun firstResult(bundle: Bundle?): String {
        val list = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        return list?.firstOrNull()?.trim().orEmpty()
    }

    private fun containsWakeWord(text: String): Boolean {
        val normalized = ArabicText.normalize(text)
        return wakeWords.any { normalized.contains(ArabicText.normalize(it)) }
    }

    private fun wakeUp() {
        if (awake) return
        awake = true
        runCatching { recognizer?.cancel() }
        speechEngine.speak("نعم، أمرك؟")
        VoiceState.setPhase(ListeningPhase.LISTENING_FOR_COMMAND)
        restartListening(1_400L)
    }

    private fun onHeard(spoken: String) {
        if (!awake) {
            if (containsWakeWord(spoken)) {
                val remainder = stripWakeWord(spoken)
                if (remainder.isNotBlank()) {
                    awake = true
                    dispatch(remainder)
                    return
                }
                wakeUp()
            } else {
                restartListening(300L)
            }
            return
        }
        dispatch(spoken)
    }

    private fun stripWakeWord(spoken: String): String {
        var result = spoken
        for (word in wakeWords.sortedByDescending { it.length }) {
            val index = result.indexOf(word)
            if (index >= 0) {
                result = result.removeRange(index, index + word.length)
            }
        }
        return result.trim().trim('،', '.', '!', '؟')
    }

    private fun dispatch(spoken: String) {
        VoiceState.setPhase(ListeningPhase.PROCESSING)
        runCatching { recognizer?.cancel() }
        scope.launch {
            val outcome = coordinator.handle(spoken, CommandSource.VOICE)
            val goodbye = ArabicText.containsAny(
                spoken,
                listOf("وقف", "توقف", "مع السلامه", "خلاص", "الى اللقاء")
            )
            handler.post {
                if (goodbye) {
                    awake = false
                    shutdown()
                } else {
                    awake = false
                    restartListening(if (outcome.spokenMessage.length > 60) 3_500L else 2_000L)
                }
            }
        }
    }

    // ------------------------------------------------------------------ foreground

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(Constants.VOICE_CHANNEL_ID) != null) return
        val channel = NotificationChannel(
            Constants.VOICE_CHANNEL_ID,
            getString(R.string.voice_channel_name),
            NotificationManager.IMPORTANCE_LOW
        )
        channel.description = getString(R.string.voice_channel_description)
        channel.setShowBadge(false)
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val contentIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, WakeWordService::class.java).setAction(Constants.ACTION_STOP_VOICE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, Constants.VOICE_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.voice_notification_title))
            .setContentText(getString(R.string.voice_notification_text))
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, getString(R.string.voice_notification_stop), stopIntent)
            .build()
    }

    private fun startForegroundCompat() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                Constants.VOICE_NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(Constants.VOICE_NOTIFICATION_ID, notification)
        }
    }

    private fun hasMicrophonePermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    private fun shutdown() {
        stopping = true
        handler.removeCallbacksAndMessages(null)
        runCatching { recognizer?.cancel() }
        runCatching { recognizer?.destroy() }
        recognizer = null
        VoiceState.setServiceRunning(false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    companion object {

        fun start(context: Context) {
            val intent = Intent(context, WakeWordService::class.java)
                .setAction(Constants.ACTION_START_VOICE)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, WakeWordService::class.java)
                .setAction(Constants.ACTION_STOP_VOICE)
            runCatching { context.startService(intent) }
            runCatching { context.stopService(Intent(context, WakeWordService::class.java)) }
        }
    }
}
