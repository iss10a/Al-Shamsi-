package com.alshamsi.assistant.domain.model

/**
 * Every action the assistant is able to perform on the device.
 * The parser converts free Arabic text into one of these values, and the executor
 * is the only component that knows how to carry them out.
 */
sealed class DeviceCommand {

    open val isDangerous: Boolean get() = false

    open val confirmationMessage: String get() = "هل تريد تنفيذ هذه العملية؟"

    // ----- Applications -----
    data class OpenApp(val query: String) : DeviceCommand()

    data object CloseCurrentApp : DeviceCommand()

    data class OpenSettingsSection(val section: SettingsSection) : DeviceCommand()

    data object OpenCamera : DeviceCommand()

    data object OpenFilesApp : DeviceCommand()

    data class OpenUrl(val url: String) : DeviceCommand()

    data class WebSearch(val query: String) : DeviceCommand()

    data class LaunchIntent(val action: String, val data: String?) : DeviceCommand()

    // ----- Hardware -----
    data class Flashlight(val turnOn: Boolean) : DeviceCommand()

    // ----- Screen control (accessibility) -----
    data class Tap(val x: Int, val y: Int) : DeviceCommand()

    data class Swipe(
        val startX: Int,
        val startY: Int,
        val endX: Int,
        val endY: Int,
        val durationMillis: Long = 300L
    ) : DeviceCommand()

    data class ClickText(val label: String) : DeviceCommand()

    data class TypeText(val text: String) : DeviceCommand() {
        override val isDangerous: Boolean get() = true
        override val confirmationMessage: String
            get() = "هل تريد كتابة هذا النص في الحقل الحالي؟"
    }

    data object ReadScreen : DeviceCommand()

    data class GlobalNavigation(val action: NavigationAction) : DeviceCommand()

    data class Scroll(val forward: Boolean) : DeviceCommand()

    // ----- Notifications -----
    data object ReadNotifications : DeviceCommand()

    data class ReplyToNotification(val appQuery: String, val message: String) : DeviceCommand() {
        override val isDangerous: Boolean get() = true
        override val confirmationMessage: String
            get() = "هل تريد إرسال هذا الرد على الإشعار؟"
    }

    // ----- Files -----
    data class SearchFiles(val query: String) : DeviceCommand()

    data class CopyFile(val source: String, val destination: String) : DeviceCommand() {
        override val isDangerous: Boolean get() = true
        override val confirmationMessage: String get() = "هل تريد نسخ هذا الملف؟"
    }

    data class MoveFile(val source: String, val destination: String) : DeviceCommand() {
        override val isDangerous: Boolean get() = true
        override val confirmationMessage: String get() = "هل تريد نقل هذا الملف؟"
    }

    data class RenameFile(val source: String, val newName: String) : DeviceCommand() {
        override val isDangerous: Boolean get() = true
        override val confirmationMessage: String get() = "هل تريد إعادة تسمية هذا الملف؟"
    }

    data class DeleteFile(val path: String) : DeviceCommand() {
        override val isDangerous: Boolean get() = true
        override val confirmationMessage: String
            get() = "سيتم حذف الملف نهائياً. هل تريد المتابعة؟"
    }

    data class ShareFile(val path: String) : DeviceCommand() {
        override val isDangerous: Boolean get() = true
        override val confirmationMessage: String get() = "هل تريد مشاركة هذا الملف؟"
    }

    // ----- Composition -----
    data class RunMacro(val name: String) : DeviceCommand()

    data class Sequence(val commands: List<DeviceCommand>) : DeviceCommand() {
        override val isDangerous: Boolean get() = commands.any { it.isDangerous }
        override val confirmationMessage: String
            get() = "سيتم تنفيذ " + commands.size + " أوامر متتابعة. هل تريد المتابعة؟"
    }

    // ----- Conversation / control -----
    data class Chat(val text: String) : DeviceCommand()

    data object StopListening : DeviceCommand()

    data object Affirm : DeviceCommand()

    data object Deny : DeviceCommand()
}

enum class SettingsSection {
    MAIN,
    WIFI,
    BLUETOOTH,
    DISPLAY,
    SOUND,
    BATTERY,
    STORAGE,
    APPS,
    LOCATION,
    SECURITY,
    ACCESSIBILITY,
    NOTIFICATIONS,
    DATE
}

enum class NavigationAction { BACK, HOME, RECENTS, NOTIFICATIONS, QUICK_SETTINGS, LOCK_SCREEN }
