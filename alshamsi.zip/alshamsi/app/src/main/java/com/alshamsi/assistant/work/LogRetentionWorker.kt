package com.alshamsi.assistant.work

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.alshamsi.assistant.domain.repository.LogRepository
import com.alshamsi.assistant.domain.repository.SettingsRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.concurrent.TimeUnit

/** Periodically trims the activity log to the retention window chosen by the user. */
@HiltWorker
class LogRetentionWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted workerParams: WorkerParameters,
    private val logRepository: LogRepository,
    private val settingsRepository: SettingsRepository
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result = try {
        val settings = settingsRepository.current()
        val cutoff = System.currentTimeMillis() -
            TimeUnit.DAYS.toMillis(settings.logRetentionDays.toLong())
        logRepository.deleteOlderThan(cutoff)
        Result.success()
    } catch (throwable: Throwable) {
        Result.retry()
    }

    companion object {
        const val UNIQUE_NAME = "alshamsi_log_retention"
    }
}
