package com.alshamsi.assistant.device.notification

import com.alshamsi.assistant.core.Constants
import com.alshamsi.assistant.domain.model.NotificationInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Process-wide cache of the notifications seen by [ShamsiNotificationListener]. */
object NotificationBridge {

    @Volatile
    private var listener: ShamsiNotificationListener? = null

    private val _connected = MutableStateFlow(false)
    val connected: StateFlow<Boolean> = _connected.asStateFlow()

    private val _notifications = MutableStateFlow<List<NotificationInfo>>(emptyList())
    val notifications: StateFlow<List<NotificationInfo>> = _notifications.asStateFlow()

    fun attach(instance: ShamsiNotificationListener) {
        listener = instance
        _connected.value = true
    }

    fun detach() {
        listener = null
        _connected.value = false
        _notifications.value = emptyList()
    }

    fun isConnected(): Boolean = listener != null

    fun requireListener(): ShamsiNotificationListener? = listener

    fun publish(info: NotificationInfo) {
        val current = _notifications.value.filterNot { it.key == info.key }
        _notifications.value = (listOf(info) + current).take(Constants.MAX_NOTIFICATIONS_CACHED)
    }

    fun remove(key: String) {
        _notifications.value = _notifications.value.filterNot { it.key == key }
    }

    fun latest(limit: Int): List<NotificationInfo> = _notifications.value.take(limit)
}
