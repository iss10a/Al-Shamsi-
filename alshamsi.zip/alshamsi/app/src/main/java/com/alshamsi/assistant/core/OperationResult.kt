package com.alshamsi.assistant.core

/** Generic result wrapper used across the domain and data layers. */
sealed class OperationResult<out T> {

    data class Success<out T>(val data: T) : OperationResult<T>()

    data class Failure(val message: String, val cause: Throwable? = null) :
        OperationResult<Nothing>()

    val isSuccess: Boolean get() = this is Success

    fun getOrNull(): T? = (this as? Success)?.data

    fun errorMessageOrNull(): String? = (this as? Failure)?.message

    companion object {
        inline fun <T> runCatchingResult(
            errorMessage: String,
            block: () -> T
        ): OperationResult<T> = try {
            Success(block())
        } catch (throwable: Throwable) {
            Failure(
                errorMessage + ": " + (throwable.message ?: throwable.javaClass.simpleName),
                throwable
            )
        }
    }
}

/** Maps the success value while keeping any failure untouched. */
inline fun <T, R> OperationResult<T>.map(transform: (T) -> R): OperationResult<R> = when (this) {
    is OperationResult.Success -> OperationResult.Success(transform(data))
    is OperationResult.Failure -> this
}

/** Runs [block] only when the result is successful. */
inline fun <T> OperationResult<T>.onSuccess(block: (T) -> Unit): OperationResult<T> {
    if (this is OperationResult.Success) block(data)
    return this
}
