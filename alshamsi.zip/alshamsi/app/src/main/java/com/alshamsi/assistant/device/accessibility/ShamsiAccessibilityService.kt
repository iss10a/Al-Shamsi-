package com.alshamsi.assistant.device.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.alshamsi.assistant.core.ArabicText
import com.alshamsi.assistant.core.Constants
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine

/**
 * Performs the physical interactions the assistant is asked for: gestures, text input,
 * element lookup, screen reading and global navigation.
 */
class ShamsiAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        AccessibilityBridge.attach(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val packageName = event.packageName?.toString().orEmpty()
            if (packageName.isNotEmpty()) {
                AccessibilityBridge.updateForegroundPackage(packageName)
            }
        }
    }

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        AccessibilityBridge.detach()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        AccessibilityBridge.detach()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ gestures

    suspend fun tap(x: Int, y: Int): Boolean {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 60L)
        return dispatch(GestureDescription.Builder().addStroke(stroke).build())
    }

    suspend fun longPress(x: Int, y: Int): Boolean {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 700L)
        return dispatch(GestureDescription.Builder().addStroke(stroke).build())
    }

    suspend fun swipe(
        startX: Int,
        startY: Int,
        endX: Int,
        endY: Int,
        durationMillis: Long
    ): Boolean {
        val path = Path().apply {
            moveTo(startX.toFloat(), startY.toFloat())
            lineTo(endX.toFloat(), endY.toFloat())
        }
        val safeDuration = durationMillis.coerceIn(50L, 5_000L)
        val stroke = GestureDescription.StrokeDescription(path, 0L, safeDuration)
        return dispatch(GestureDescription.Builder().addStroke(stroke).build())
    }

    private suspend fun dispatch(gesture: GestureDescription): Boolean =
        suspendCancellableCoroutine { continuation ->
            val callback = object : GestureResultCallback() {
                override fun onCompleted(description: GestureDescription?) {
                    if (continuation.isActive) continuation.resume(true)
                }

                override fun onCancelled(description: GestureDescription?) {
                    if (continuation.isActive) continuation.resume(false)
                }
            }
            val accepted = dispatchGesture(gesture, callback, null)
            if (!accepted && continuation.isActive) {
                continuation.resume(false)
            }
        }

    // ------------------------------------------------------------------ nodes

    fun findNodeByText(label: String): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val target = ArabicText.normalize(label)
        if (target.isEmpty()) return null

        val exact = ArrayList<AccessibilityNodeInfo>()
        val partial = ArrayList<AccessibilityNodeInfo>()
        traverse(root) { node ->
            val candidates = listOfNotNull(
                node.text?.toString(),
                node.contentDescription?.toString(),
                node.viewIdResourceName
            )
            for (candidate in candidates) {
                val normalized = ArabicText.normalize(candidate)
                if (normalized.isEmpty()) continue
                if (normalized == target) {
                    exact.add(node)
                    return@traverse
                }
                if (normalized.contains(target) || target.contains(normalized)) {
                    partial.add(node)
                    return@traverse
                }
            }
        }
        return exact.firstOrNull() ?: partial.firstOrNull()
    }

    fun clickNodeWithText(label: String): Boolean {
        val node = findNodeByText(label) ?: return false
        var current: AccessibilityNodeInfo? = node
        var depth = 0
        while (current != null && depth < 8) {
            if (current.isClickable && current.isEnabled) {
                return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            current = current.parent
            depth++
        }
        val bounds = Rect()
        node.getBoundsInScreen(bounds)
        return if (!bounds.isEmpty) {
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        } else {
            false
        }
    }

    fun boundsOfNodeWithText(label: String): Rect? {
        val node = findNodeByText(label) ?: return null
        val bounds = Rect()
        node.getBoundsInScreen(bounds)
        return if (bounds.isEmpty) null else bounds
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: firstEditableNode(root)
            ?: return false
        val arguments = Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                text
            )
        }
        focused.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
    }

    private fun firstEditableNode(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var found: AccessibilityNodeInfo? = null
        traverse(root) { node ->
            if (found == null && node.isEditable && node.isEnabled) {
                found = node
            }
        }
        return found
    }

    fun readScreenText(): List<String> {
        val root = rootInActiveWindow ?: return emptyList()
        val collected = LinkedHashSet<String>()
        traverse(root) { node ->
            if (collected.size >= Constants.MAX_SCREEN_TEXT_NODES) return@traverse
            val text = node.text?.toString()?.trim()
            if (!text.isNullOrEmpty()) {
                collected.add(text)
                return@traverse
            }
            val description = node.contentDescription?.toString()?.trim()
            if (!description.isNullOrEmpty()) {
                collected.add(description)
            }
        }
        return collected.toList()
    }

    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        var scrollable: AccessibilityNodeInfo? = null
        traverse(root) { node ->
            if (scrollable == null && node.isScrollable) {
                scrollable = node
            }
        }
        val target = scrollable ?: return false
        val action = if (forward) {
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        } else {
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        }
        return target.performAction(action)
    }

    fun currentPackageName(): String =
        rootInActiveWindow?.packageName?.toString().orEmpty()

    private fun traverse(node: AccessibilityNodeInfo, visitor: (AccessibilityNodeInfo) -> Unit) {
        visitor(node)
        for (index in 0 until node.childCount) {
            val child = node.getChild(index) ?: continue
            traverse(child, visitor)
        }
    }

    // ------------------------------------------------------------------ globals

    fun goBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)

    fun goHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)

    fun openRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)

    fun openNotifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun openQuickSettings(): Boolean = performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)

    fun lockScreen(): Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
    } else {
        false
    }

    /**
     * Closes the foreground app by going back until the launcher is reached.
     * Android does not allow force-stopping another app without root, so this is the
     * supported approximation.
     */
    suspend fun closeForegroundApp(): Boolean {
        val startPackage = currentPackageName()
        if (startPackage.isEmpty()) return goHome()
        var attempts = 0
        while (attempts < 6) {
            if (!goBack()) break
            kotlinx.coroutines.delay(320L)
            val now = currentPackageName()
            if (now != startPackage) return true
            attempts++
        }
        return goHome()
    }
}
