package com.alshamsi.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.alshamsi.assistant.ui.AlshamsiRoot
import com.alshamsi.assistant.ui.MainViewModel
import com.alshamsi.assistant.ui.theme.AlshamsiTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            val settings by viewModel.settings.collectAsStateWithLifecycle()
            val pending by viewModel.pendingConfirmation.collectAsStateWithLifecycle()
            AlshamsiTheme(
                themeMode = settings.themeMode,
                dynamicColor = settings.dynamicColor
            ) {
                AlshamsiRoot(
                    pendingConfirmation = pending,
                    onConfirm = viewModel::confirm,
                    onCancel = viewModel::cancel
                )
            }
        }
    }
}
