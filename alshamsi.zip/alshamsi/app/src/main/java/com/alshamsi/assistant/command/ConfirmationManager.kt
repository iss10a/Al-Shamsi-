package com.alshamsi.assistant.command

import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

data class PendingConfirmation(
    val title: String,
    val message: String,
    val details: String = ""
)

/**
 * Bridges the execution pipeline and the UI: any dangerous command suspends here until
 * the user answers the "هل أنت متأكد؟" dialog, by touch or by voice.
 */
@Singleton
class ConfirmationManager @Inject constructor() {

    private val mutex = Mutex()

    private val _pending = MutableStateFlow<PendingConfirmation?>(null)
    val pending: StateFlow<PendingConfirmation?> = _pending.asStateFlow()

    @Volatile
    private var answer: CompletableDeferred<Boolean>? = null

    fun isWaiting(): Boolean = _pending.value != null

    suspend fun request(
        message: String,
        details: String = "",
        title: String = "هل أنت متأكد؟"
    ): Boolean = mutex.withLock {
        val deferred = CompletableDeferred<Boolean>()
        answer = deferred
        _pending.value = PendingConfirmation(title, message, details)
        try {
            deferred.await()
        } finally {
            _pending.value = null
            answer = null
        }
    }

    fun confirm() {
        answer?.complete(true)
    }

    fun cancel() {
        answer?.complete(false)
    }
}
