package com.alshamsi.assistant.command

import com.alshamsi.assistant.core.OperationResult
import com.alshamsi.assistant.core.map
import com.alshamsi.assistant.device.accessibility.AccessibilityBridge
import com.alshamsi.assistant.device.control.DeviceController
import com.alshamsi.assistant.device.control.FlashlightController
import com.alshamsi.assistant.device.files.FileOperations
import com.alshamsi.assistant.device.notification.NotificationBridge
import com.alshamsi.assistant.domain.model.CommandOutcome
import com.alshamsi.assistant.domain.model.DeviceCommand
import com.alshamsi.assistant.domain.model.NavigationAction
import com.alshamsi.assistant.domain.repository.MacroRepository
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.delay

/** Carries out a [DeviceCommand] using only officially supported Android APIs. */
@Singleton
class CommandExecutor @Inject constructor(
    private val deviceController: DeviceController,
    private val flashlightController: FlashlightController,
    private val fileOperations: FileOperations,
    private val macroRepository: MacroRepository,
    private val parser: CommandParser
) {

    private val timeFormat = SimpleDateFormat("hh:mm a", Locale("ar"))

    suspend fun execute(
        command: DeviceCommand,
        confirmer: suspend (DeviceCommand) -> Boolean
    ): CommandOutcome {
        if (command.isDangerous && command !is DeviceCommand.Sequence) {
            val approved = confirmer(command)
            if (!approved) return CommandOutcome.cancelled()
        }
        return runCommand(command, confirmer)
    }

    private suspend fun runCommand(
        command: DeviceCommand,
        confirmer: suspend (DeviceCommand) -> Boolean
    ): CommandOutcome = when (command) {

        is DeviceCommand.OpenApp -> when (val result = deviceController.openApp(command.query)) {
            is OperationResult.Success -> CommandOutcome.success("تم، فتحت " + result.data + ".")
            is OperationResult.Failure -> CommandOutcome.failure(result.message)
        }

        DeviceCommand.CloseCurrentApp -> withAccessibility { service ->
            val closed = service.closeForegroundApp()
            if (closed) {
                CommandOutcome.success("تم، سكرت التطبيق.")
            } else {
                CommandOutcome.failure("ما قدرت أغلق التطبيق الحالي.")
            }
        }

        is DeviceCommand.OpenSettingsSection ->
            toOutcome(deviceController.openSettings(command.section), "تم، فتحت الإعدادات.")

        DeviceCommand.OpenCamera ->
            toOutcome(deviceController.openCamera(), "تم، فتحت الكاميرا.")

        DeviceCommand.OpenFilesApp ->
            toOutcome(deviceController.openFilesApp(), "تم، فتحت الملفات.")

        is DeviceCommand.OpenUrl ->
            toOutcome(deviceController.openUrl(command.url), "تم، فتحت الرابط.")

        is DeviceCommand.WebSearch ->
            toOutcome(deviceController.webSearch(command.query), "تم، فتحت نتائج البحث.")

        is DeviceCommand.LaunchIntent ->
            toOutcome(
                deviceController.launchRawIntent(command.action, command.data),
                "تم تنفيذ الأمر."
            )

        is DeviceCommand.Flashlight -> {
            if (!flashlightController.hasFlash()) {
                CommandOutcome.failure("ما فيه كشاف في هذا الجهاز.")
            } else {
                when (val result = flashlightController.setTorch(command.turnOn)) {
                    is OperationResult.Success -> CommandOutcome.success(
                        if (command.turnOn) "تم، شغلت الكشاف." else "تم، طفيت الكشاف."
                    )

                    is OperationResult.Failure -> CommandOutcome.failure(result.message)
                }
            }
        }

        is DeviceCommand.Tap -> withAccessibility { service ->
            if (service.tap(command.x, command.y)) {
                CommandOutcome.success("تم الضغط.")
            } else {
                CommandOutcome.failure("ما نجحت الضغطة.")
            }
        }

        is DeviceCommand.Swipe -> withAccessibility { service ->
            val done = service.swipe(
                command.startX,
                command.startY,
                command.endX,
                command.endY,
                command.durationMillis
            )
            if (done) CommandOutcome.success("تم السحب.") else CommandOutcome.failure("ما نجح السحب.")
        }

        is DeviceCommand.ClickText -> withAccessibility { service ->
            if (service.clickNodeWithText(command.label)) {
                CommandOutcome.success("تم، ضغطت على «" + command.label + "».")
            } else {
                val bounds = service.boundsOfNodeWithText(command.label)
                if (bounds != null && service.tap(bounds.centerX(), bounds.centerY())) {
                    CommandOutcome.success("تم، ضغطت على «" + command.label + "».")
                } else {
                    CommandOutcome.failure("ما لقيت عنصراً باسم «" + command.label + "» على الشاشة.")
                }
            }
        }

        is DeviceCommand.TypeText -> withAccessibility { service ->
            if (service.typeText(command.text)) {
                CommandOutcome.success("تم، كتبت النص.")
            } else {
                CommandOutcome.failure("ما فيه حقل كتابة نشط الحين.")
            }
        }

        DeviceCommand.ReadScreen -> withAccessibility { service ->
            val lines = service.readScreenText()
            if (lines.isEmpty()) {
                CommandOutcome.failure("ما قدرت أقرأ محتوى الشاشة.")
            } else {
                val preview = lines.take(12).joinToString("، ")
                CommandOutcome(
                    status = com.alshamsi.assistant.domain.model.LogStatus.SUCCESS,
                    userMessage = "محتوى الشاشة:\n" + lines.take(30).joinToString("\n"),
                    spokenMessage = preview,
                    details = lines.size.toString() + " عنصراً"
                )
            }
        }

        is DeviceCommand.GlobalNavigation -> withAccessibility { service ->
            val done = when (command.action) {
                NavigationAction.BACK -> service.goBack()
                NavigationAction.HOME -> service.goHome()
                NavigationAction.RECENTS -> service.openRecents()
                NavigationAction.NOTIFICATIONS -> service.openNotifications()
                NavigationAction.QUICK_SETTINGS -> service.openQuickSettings()
                NavigationAction.LOCK_SCREEN -> service.lockScreen()
            }
            if (done) CommandOutcome.success("تم.") else CommandOutcome.failure("النظام ما سمح بهذا الإجراء.")
        }

        is DeviceCommand.Scroll -> withAccessibility { service ->
            if (service.scroll(command.forward)) {
                CommandOutcome.success("تم التمرير.")
            } else {
                CommandOutcome.failure("ما فيه قائمة قابلة للتمرير على الشاشة.")
            }
        }

        DeviceCommand.ReadNotifications -> {
            if (!NotificationBridge.isConnected()) {
                CommandOutcome.permissionRequired(
                    "أحتاج صلاحية قراءة الإشعارات. افتحها من شاشة الصلاحيات."
                )
            } else {
                val items = NotificationBridge.latest(8)
                if (items.isEmpty()) {
                    CommandOutcome.success("ما فيه إشعارات جديدة.")
                } else {
                    val text = items.joinToString("\n") { info ->
                        info.appLabel + " — " + info.title + ": " + info.text +
                            " (" + timeFormat.format(info.postedAt) + ")"
                    }
                    val spoken = items.take(3).joinToString("، ") { info ->
                        info.appLabel + " يقول " + (info.text.ifBlank { info.title })
                    }
                    CommandOutcome(
                        status = com.alshamsi.assistant.domain.model.LogStatus.SUCCESS,
                        userMessage = "عندك " + items.size + " إشعارات:\n" + text,
                        spokenMessage = "عندك " + items.size + " إشعارات. " + spoken,
                        details = ""
                    )
                }
            }
        }

        is DeviceCommand.ReplyToNotification -> {
            val listener = NotificationBridge.requireListener()
            if (listener == null) {
                CommandOutcome.permissionRequired(
                    "أحتاج صلاحية قراءة الإشعارات عشان أقدر أرد."
                )
            } else if (command.message.isBlank()) {
                CommandOutcome.failure("وش النص اللي أرد فيه؟")
            } else {
                val key = listener.findReplyableKey(command.appQuery)
                if (key == null) {
                    CommandOutcome.failure("ما فيه إشعار يقبل الرد المباشر الحين.")
                } else if (listener.replyTo(key, command.message)) {
                    CommandOutcome.success("تم، رديت على الإشعار.")
                } else {
                    CommandOutcome.failure("التطبيق رفض الرد المباشر.")
                }
            }
        }

        is DeviceCommand.SearchFiles -> when (val result = fileOperations.search(command.query)) {
            is OperationResult.Failure -> CommandOutcome.failure(result.message)
            is OperationResult.Success -> {
                val list = result.data.joinToString("\n") { match ->
                    (if (match.isDirectory) "📁 " else "📄 ") + match.name + "\n" + match.path
                }
                CommandOutcome(
                    status = com.alshamsi.assistant.domain.model.LogStatus.SUCCESS,
                    userMessage = "لقيت " + result.data.size + " نتيجة:\n" + list,
                    spokenMessage = "لقيت " + result.data.size + " نتيجة.",
                    details = ""
                )
            }
        }

        is DeviceCommand.CopyFile -> requireFileAccess {
            toOutcome(
                fileOperations.copy(command.source, command.destination).map { Unit },
                "تم، نسخت الملف."
            )
        }

        is DeviceCommand.MoveFile -> requireFileAccess {
            toOutcome(
                fileOperations.move(command.source, command.destination).map { Unit },
                "تم، نقلت الملف."
            )
        }

        is DeviceCommand.RenameFile -> requireFileAccess {
            toOutcome(
                fileOperations.rename(command.source, command.newName).map { Unit },
                "تم، غيرت اسم الملف."
            )
        }

        is DeviceCommand.DeleteFile -> requireFileAccess {
            when (val result = fileOperations.delete(command.path)) {
                is OperationResult.Success ->
                    CommandOutcome.success("تم، حذفت «" + result.data + "».")

                is OperationResult.Failure -> CommandOutcome.failure(result.message)
            }
        }

        is DeviceCommand.ShareFile -> when (val found = fileOperations.resolveSingle(command.path)) {
            is OperationResult.Failure -> CommandOutcome.failure(found.message)
            is OperationResult.Success -> toOutcome(
                deviceController.shareFile(File(found.data.absolutePath)),
                "تم، فتحت قائمة المشاركة."
            )
        }

        is DeviceCommand.RunMacro -> {
            val macro = macroRepository.findByName(command.name)
            if (macro == null) {
                CommandOutcome.failure("ما لقيت ماكرو باسم «" + command.name + "».")
            } else if (macro.steps.isEmpty()) {
                CommandOutcome.failure("الماكرو «" + macro.name + "» ما فيه خطوات.")
            } else {
                var failures = 0
                for (step in macro.steps) {
                    val parsed = parser.parse(step.rawCommand)
                    val outcome = execute(parsed, confirmer)
                    if (!outcome.isSuccess) failures++
                    delay(step.delayMillis.coerceIn(0L, 10_000L))
                }
                macroRepository.markRun(macro.id, System.currentTimeMillis())
                if (failures == 0) {
                    CommandOutcome.success("خلصت ماكرو «" + macro.name + "».")
                } else {
                    CommandOutcome.failure(
                        "نفذت الماكرو، لكن " + failures + " خطوة ما ضبطت."
                    )
                }
            }
        }

        is DeviceCommand.Sequence -> {
            var failures = 0
            for (step in command.commands) {
                val outcome = execute(step, confirmer)
                if (!outcome.isSuccess) failures++
                delay(250L)
            }
            if (failures == 0) {
                CommandOutcome.success("تم تنفيذ كل الأوامر.")
            } else {
                CommandOutcome.failure(failures.toString() + " من الأوامر ما نجحت.")
            }
        }

        is DeviceCommand.Chat -> CommandOutcome.success(command.text)

        DeviceCommand.StopListening -> CommandOutcome.success("في أمان الله.")

        DeviceCommand.Affirm -> CommandOutcome.success("تمام.")

        DeviceCommand.Deny -> CommandOutcome.cancelled()
    }

    private suspend fun withAccessibility(
        block: suspend (com.alshamsi.assistant.device.accessibility.ShamsiAccessibilityService) -> CommandOutcome
    ): CommandOutcome {
        val service = AccessibilityBridge.requireService()
            ?: return CommandOutcome.permissionRequired(
                "أحتاج تفعيل خدمة الوصول عشان أتحكم بالشاشة. افتح شاشة الصلاحيات وفعلها."
            )
        return block(service)
    }

    private suspend fun requireFileAccess(block: suspend () -> CommandOutcome): CommandOutcome {
        if (!fileOperations.hasFullFileAccess()) {
            return CommandOutcome.permissionRequired(
                "أحتاج صلاحية الوصول لكل الملفات. فعّلها من شاشة الصلاحيات."
            )
        }
        return block()
    }

    private fun toOutcome(result: OperationResult<Unit>, successMessage: String): CommandOutcome =
        when (result) {
            is OperationResult.Success -> CommandOutcome.success(successMessage)
            is OperationResult.Failure -> CommandOutcome.failure(result.message)
        }
}
