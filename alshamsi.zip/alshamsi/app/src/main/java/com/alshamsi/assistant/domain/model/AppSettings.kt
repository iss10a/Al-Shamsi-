package com.alshamsi.assistant.domain.model

import com.alshamsi.assistant.core.Constants

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = true,
    val spokenReplies: Boolean = true,
    val wakeWordEnabled: Boolean = true,
    val speechRate: Float = 1.0f,
    val speechPitch: Float = 1.0f,
    val confirmDangerousActions: Boolean = true,
    val aiProviderId: String = Constants.PROVIDER_OFFLINE,
    val localEndpoint: String = Constants.DEFAULT_LOCAL_ENDPOINT,
    val localModel: String = Constants.DEFAULT_LOCAL_MODEL,
    val logRetentionDays: Int = 30
)

enum class ThemeMode { SYSTEM, LIGHT, DARK }
