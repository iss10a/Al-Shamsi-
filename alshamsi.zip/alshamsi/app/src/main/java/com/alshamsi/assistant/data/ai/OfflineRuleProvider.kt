package com.alshamsi.assistant.data.ai

import android.content.Context
import android.os.BatteryManager
import com.alshamsi.assistant.core.ArabicText
import com.alshamsi.assistant.core.Constants
import com.alshamsi.assistant.domain.ai.AiProvider
import com.alshamsi.assistant.domain.ai.AiRequest
import com.alshamsi.assistant.domain.ai.AiResult
import com.alshamsi.assistant.domain.model.AppSettings
import dagger.hilt.android.qualifiers.ApplicationContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Fully offline conversational engine. It never touches the network, needs no account
 * and no API key, so the assistant keeps working on a device with no connectivity.
 */
@Singleton
class OfflineRuleProvider @Inject constructor(
    @ApplicationContext private val context: Context
) : AiProvider {

    override val id: String = Constants.PROVIDER_OFFLINE

    override val displayName: String = "المحرك المحلي (بدون إنترنت)"

    override val requiresNetwork: Boolean = false

    override suspend fun isAvailable(settings: AppSettings): Boolean = true

    override suspend fun generate(request: AiRequest, settings: AppSettings): AiResult {
        val text = ArabicText.normalize(request.prompt)
        val reply = when {
            text.isEmpty() -> "ما سمعت شي، عيد الطلب لو سمحت."

            matches(text, listOf("السلام عليكم", "سلام عليكم")) ->
                "وعليكم السلام ورحمة الله، أمرك؟"

            matches(text, listOf("هلا", "مرحبا", "اهلا", "صباح الخير", "مساء الخير", "هاي")) ->
                "هلا والله، تفضل شو تبي؟"

            matches(text, listOf("كيف حالك", "شخبارك", "كيفك", "شلونك")) ->
                "بخير الحمد لله، وأنت شلونك؟"

            matches(text, listOf("شكرا", "مشكور", "يعطيك العافيه", "تسلم")) ->
                "الله يعافيك، أمرني بأي وقت."

            matches(text, listOf("من انت", "منو انت", "عرف نفسك", "اسمك")) ->
                "أنا الشامسي، مساعدك الشخصي على الجهاز. أشتغل بالكامل عندك، وما أرسل شي برا الهاتف."

            matches(text, listOf("كم الساعه", "الساعه كم", "الوقت")) ->
                "الساعة الحين " + timeFormatter.format(System.currentTimeMillis()) + "."

            matches(text, listOf("التاريخ", "كم التاريخ", "اليوم كم")) ->
                "اليوم " + dateFormatter.format(System.currentTimeMillis()) + "."

            matches(text, listOf("البطاريه", "الشحن", "كم البطاريه")) ->
                batteryReply()

            matches(text, listOf("مساعده", "ساعدني", "شو تقدر", "وش تقدر", "الاوامر", "قائمه الاوامر")) ->
                helpReply()

            matches(text, listOf("تصبح على خير", "مع السلامه", "الى اللقاء")) ->
                "في أمان الله، أنا موجود إذا احتجتني."

            text.endsWith("؟") || text.contains("ليش") || text.contains("وش") || text.contains("شو") ->
                "ما عندي جواب أكيد لهالسؤال بدون محرك خارجي. تقدر تشغل نموذجاً محلياً من الإعدادات، أو تعطيني أمراً أنفذه لك على الجهاز."

            else ->
                "ما فهمت الطلب تماماً. جرب مثلاً: «افتح الكاميرا» أو «شغل الكشاف» أو «اقرأ الإشعارات»."
        }
        return AiResult.Answer(reply, id)
    }

    private fun matches(normalizedInput: String, keys: List<String>): Boolean =
        keys.any { normalizedInput.contains(ArabicText.normalize(it)) }

    private fun batteryReply(): String {
        val manager = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val level = manager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        return if (level in 0..100) {
            "البطارية الحين " + level + " بالمئة."
        } else {
            "ما قدرت أقرأ حالة البطارية على هذا الجهاز."
        }
    }

    private fun helpReply(): String = buildString {
        append("أقدر أسوي لك: ")
        append("فتح التطبيقات، إغلاق التطبيق الحالي، فتح الإعدادات والكاميرا والملفات، ")
        append("تشغيل وإطفاء الكشاف، الضغط والسحب والكتابة على الشاشة، قراءة الشاشة، ")
        append("قراءة الإشعارات والرد عليها، البحث عن الملفات ونسخها ونقلها وإعادة تسميتها وحذفها بعد التأكيد، ")
        append("المشاركة، فتح الروابط، وتشغيل الماكرو المحفوظ.")
    }

    private val timeFormatter = SimpleDateFormat("hh:mm a", Locale("ar"))
    private val dateFormatter = SimpleDateFormat("EEEE d MMMM yyyy", Locale("ar"))

    @Suppress("unused")
    private fun currentHour(): Int = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
}
