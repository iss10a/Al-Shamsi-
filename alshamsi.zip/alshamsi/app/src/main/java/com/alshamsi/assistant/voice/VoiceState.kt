package com.alshamsi.assistant.voice

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ListeningPhase {
    IDLE,
    WAITING_FOR_WAKE_WORD,
    LISTENING_FOR_COMMAND,
    PROCESSING
}

/** Shared, observable state of the background voice pipeline. */
object VoiceState {

    private val _phase = MutableStateFlow(ListeningPhase.IDLE)
    val phase: StateFlow<ListeningPhase> = _phase.asStateFlow()

    private val _serviceRunning = MutableStateFlow(false)
    val serviceRunning: StateFlow<Boolean> = _serviceRunning.asStateFlow()

    private val _lastHeard = MutableStateFlow("")
    val lastHeard: StateFlow<String> = _lastHeard.asStateFlow()

    fun setPhase(phase: ListeningPhase) {
        _phase.value = phase
    }

    fun setServiceRunning(running: Boolean) {
        _serviceRunning.value = running
        if (!running) {
            _phase.value = ListeningPhase.IDLE
        }
    }

    fun setLastHeard(text: String) {
        _lastHeard.value = text
    }
}
