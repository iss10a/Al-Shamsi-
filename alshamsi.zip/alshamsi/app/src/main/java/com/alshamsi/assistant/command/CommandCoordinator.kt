package com.alshamsi.assistant.command

import android.content.Context
import com.alshamsi.assistant.device.accessibility.AccessibilityBridge
import com.alshamsi.assistant.domain.ai.AiProviderRegistry
import com.alshamsi.assistant.domain.ai.AiRequest
import com.alshamsi.assistant.domain.ai.AiResult
import com.alshamsi.assistant.domain.ai.AiRole
import com.alshamsi.assistant.domain.ai.AiTurn
import com.alshamsi.assistant.domain.model.ChatMessage
import com.alshamsi.assistant.domain.model.CommandOutcome
import com.alshamsi.assistant.domain.model.CommandSource
import com.alshamsi.assistant.domain.model.DeviceCommand
import com.alshamsi.assistant.domain.model.LogEntry
import com.alshamsi.assistant.domain.model.LogStatus
import com.alshamsi.assistant.domain.model.MessageRole
import com.alshamsi.assistant.domain.repository.ChatRepository
import com.alshamsi.assistant.domain.repository.LogRepository
import com.alshamsi.assistant.domain.repository.SettingsRepository
import com.alshamsi.assistant.voice.SpeechEngine
import com.alshamsi.assistant.voice.WakeWordService
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Single entry point for every user request, whatever its origin (typed, spoken,
 * quick action or macro). It parses, confirms, executes, logs and answers.
 */
@Singleton
class CommandCoordinator @Inject constructor(
    @ApplicationContext private val context: Context,
    private val parser: CommandParser,
    private val executor: CommandExecutor,
    private val confirmationManager: ConfirmationManager,
    private val chatRepository: ChatRepository,
    private val logRepository: LogRepository,
    private val settingsRepository: SettingsRepository,
    private val aiRegistry: AiProviderRegistry,
    private val speechEngine: SpeechEngine
) {

    private val mutex = Mutex()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    suspend fun handle(rawInput: String, source: CommandSource): CommandOutcome {
        val input = rawInput.trim()
        if (input.isEmpty()) {
            return CommandOutcome.failure("ما وصلني نص.")
        }

        val command = parser.parse(input)

        // A pending confirmation swallows a plain yes / no answer.
        if (confirmationManager.isWaiting()) {
            when (command) {
                DeviceCommand.Affirm -> {
                    confirmationManager.confirm()
                    return CommandOutcome.success("تمام، جاري التنفيذ.")
                }

                DeviceCommand.Deny -> {
                    confirmationManager.cancel()
                    return CommandOutcome.cancelled("تمام، ألغيت العملية.")
                }

                else -> Unit
            }
        }

        return mutex.withLock {
            _busy.value = true
            try {
                process(input, command, source)
            } finally {
                _busy.value = false
            }
        }
    }

    private suspend fun process(
        input: String,
        command: DeviceCommand,
        source: CommandSource
    ): CommandOutcome {
        val settings = settingsRepository.current()

        chatRepository.add(
            ChatMessage(content = input, role = MessageRole.USER, source = source)
        )

        val outcome = when (command) {
            is DeviceCommand.Chat -> answerWithAi(command.text)

            DeviceCommand.StopListening -> {
                WakeWordService.stop(context)
                CommandOutcome.success("في أمان الله، أنا موجود إذا احتجتني.")
            }

            DeviceCommand.Affirm -> CommandOutcome.success("تمام.")

            DeviceCommand.Deny -> CommandOutcome.cancelled("تمام، ما نفذت شي.")

            else -> executor.execute(command) { dangerous ->
                if (!settings.confirmDangerousActions) {
                    true
                } else {
                    confirmationManager.request(
                        message = dangerous.confirmationMessage,
                        details = describe(dangerous)
                    )
                }
            }
        }

        chatRepository.add(
            ChatMessage(
                content = outcome.userMessage,
                role = MessageRole.ASSISTANT,
                source = source
            )
        )

        logRepository.add(
            LogEntry(
                title = describe(command),
                details = outcome.details.ifBlank { outcome.userMessage },
                status = outcome.status,
                source = source
            )
        )

        if (settings.spokenReplies && outcome.spokenMessage.isNotBlank()) {
            speechEngine.speak(outcome.spokenMessage)
        }

        return outcome
    }

    private suspend fun answerWithAi(prompt: String): CommandOutcome {
        val settings = settingsRepository.current()
        val history = chatRepository.recentHistory(12).map { message ->
            AiTurn(
                role = when (message.role) {
                    MessageRole.USER -> AiRole.USER
                    MessageRole.ASSISTANT -> AiRole.ASSISTANT
                    MessageRole.SYSTEM -> AiRole.SYSTEM
                },
                content = message.content
            )
        }
        val screenContext = AccessibilityBridge.requireService()
            ?.readScreenText()
            ?.take(20)
            ?.joinToString(" | ")
            .orEmpty()

        val request = AiRequest(
            prompt = prompt,
            history = history,
            screenContext = screenContext
        )
        return when (val result = aiRegistry.generate(request, settings)) {
            is AiResult.Answer -> CommandOutcome(
                status = LogStatus.SUCCESS,
                userMessage = result.text,
                spokenMessage = result.text,
                details = "المحرك: " + result.providerId
            )

            is AiResult.Unavailable -> CommandOutcome.failure(result.reason)
        }
    }

    fun describe(command: DeviceCommand): String = when (command) {
        is DeviceCommand.OpenApp -> "فتح تطبيق: " + command.query
        DeviceCommand.CloseCurrentApp -> "إغلاق التطبيق الحالي"
        is DeviceCommand.OpenSettingsSection -> "فتح الإعدادات: " + command.section.name
        DeviceCommand.OpenCamera -> "فتح الكاميرا"
        DeviceCommand.OpenFilesApp -> "فتح الملفات"
        is DeviceCommand.OpenUrl -> "فتح رابط: " + command.url
        is DeviceCommand.WebSearch -> "بحث: " + command.query
        is DeviceCommand.LaunchIntent -> "تشغيل Intent: " + command.action
        is DeviceCommand.Flashlight -> if (command.turnOn) "تشغيل الكشاف" else "إطفاء الكشاف"
        is DeviceCommand.Tap -> "ضغط عند " + command.x + "," + command.y
        is DeviceCommand.Swipe -> "سحب من " + command.startX + "," + command.startY +
            " إلى " + command.endX + "," + command.endY
        is DeviceCommand.ClickText -> "ضغط على عنصر: " + command.label
        is DeviceCommand.TypeText -> "كتابة نص"
        DeviceCommand.ReadScreen -> "قراءة الشاشة"
        is DeviceCommand.GlobalNavigation -> "تنقل: " + command.action.name
        is DeviceCommand.Scroll -> if (command.forward) "تمرير للأسفل" else "تمرير للأعلى"
        DeviceCommand.ReadNotifications -> "قراءة الإشعارات"
        is DeviceCommand.ReplyToNotification -> "الرد على إشعار"
        is DeviceCommand.SearchFiles -> "بحث عن ملف: " + command.query
        is DeviceCommand.CopyFile -> "نسخ ملف"
        is DeviceCommand.MoveFile -> "نقل ملف"
        is DeviceCommand.RenameFile -> "إعادة تسمية ملف"
        is DeviceCommand.DeleteFile -> "حذف ملف: " + command.path
        is DeviceCommand.ShareFile -> "مشاركة ملف"
        is DeviceCommand.RunMacro -> "تشغيل ماكرو: " + command.name
        is DeviceCommand.Sequence -> "أوامر متتابعة (" + command.commands.size + ")"
        is DeviceCommand.Chat -> "محادثة"
        DeviceCommand.StopListening -> "إيقاف الاستماع"
        DeviceCommand.Affirm -> "تأكيد"
        DeviceCommand.Deny -> "إلغاء"
    }
}
