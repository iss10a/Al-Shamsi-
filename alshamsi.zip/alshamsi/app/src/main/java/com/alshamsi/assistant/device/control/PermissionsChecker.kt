package com.alshamsi.assistant.device.control

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.alshamsi.assistant.device.accessibility.AccessibilityBridge
import com.alshamsi.assistant.device.accessibility.ShamsiAccessibilityService
import com.alshamsi.assistant.device.files.FileOperations
import com.alshamsi.assistant.domain.model.PermissionItem
import com.alshamsi.assistant.domain.model.PermissionKey
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PermissionsChecker @Inject constructor(
    @ApplicationContext private val context: Context,
    private val fileOperations: FileOperations
) {

    fun isAccessibilityEnabled(): Boolean {
        if (AccessibilityBridge.isConnected()) return true
        val expected = context.packageName + "/" +
            ShamsiAccessibilityService::class.java.canonicalName
        val enabled = runCatching {
            Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            )
        }.getOrNull().orEmpty()
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    fun isNotificationListenerEnabled(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(context)
            .contains(context.packageName)

    fun hasMicrophonePermission(): Boolean = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED

    fun hasPostNotificationsPermission(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }

    fun hasAllFilesAccess(): Boolean = fileOperations.hasFullFileAccess()

    fun hasMediaAccess(): Boolean = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU ->
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_MEDIA_IMAGES
            ) == PackageManager.PERMISSION_GRANTED

        else -> ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun snapshot(): List<PermissionItem> = listOf(
        PermissionItem(
            key = PermissionKey.ACCESSIBILITY,
            title = "خدمة الوصول (Accessibility)",
            reason = "تسمح للشامسي بقراءة الشاشة والضغط والسحب والكتابة والتنقل داخل التطبيقات. " +
                "بدونها تعمل الأوامر التي تعتمد على الـ Intents فقط.",
            granted = isAccessibilityEnabled()
        ),
        PermissionItem(
            key = PermissionKey.NOTIFICATION_LISTENER,
            title = "قراءة الإشعارات",
            reason = "لقراءة إشعاراتك بصوت عالٍ والرد عليها مباشرة عندما يسمح التطبيق المُرسِل بذلك.",
            granted = isNotificationListenerEnabled()
        ),
        PermissionItem(
            key = PermissionKey.MICROPHONE,
            title = "المايكروفون",
            reason = "لسماع كلمة التنبيه «يا الشامسي» والأوامر الصوتية. التعرف يتم عبر محرك النظام.",
            granted = hasMicrophonePermission()
        ),
        PermissionItem(
            key = PermissionKey.POST_NOTIFICATIONS,
            title = "إظهار الإشعارات",
            reason = "لعرض إشعار دائم أثناء عمل المساعد في الخلفية كما يتطلب النظام.",
            granted = hasPostNotificationsPermission()
        ),
        PermissionItem(
            key = PermissionKey.ALL_FILES_ACCESS,
            title = "الوصول لكل الملفات",
            reason = "لإدارة الملفات: البحث والنسخ والنقل وإعادة التسمية والحذف بعد موافقتك.",
            granted = hasAllFilesAccess()
        ),
        PermissionItem(
            key = PermissionKey.MEDIA_ACCESS,
            title = "الوسائط (صور وفيديو وصوت)",
            reason = "لقراءة ملفات الوسائط ومشاركتها عند الطلب.",
            granted = hasMediaAccess()
        )
    )
}
