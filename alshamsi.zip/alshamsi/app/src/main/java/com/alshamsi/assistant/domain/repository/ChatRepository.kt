package com.alshamsi.assistant.domain.repository

import com.alshamsi.assistant.domain.model.ChatMessage
import kotlinx.coroutines.flow.Flow

interface ChatRepository {
    fun observeMessages(limit: Int = 200): Flow<List<ChatMessage>>
    suspend fun add(message: ChatMessage): Long
    suspend fun recentHistory(limit: Int): List<ChatMessage>
    suspend fun clear()
}
