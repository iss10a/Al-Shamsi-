package com.alshamsi.assistant.domain.model

data class Macro(
    val id: Long = 0L,
    val name: String,
    val description: String = "",
    val steps: List<MacroStep> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val lastRunAt: Long? = null
)

data class MacroStep(
    val rawCommand: String,
    val delayMillis: Long = 400L
)
