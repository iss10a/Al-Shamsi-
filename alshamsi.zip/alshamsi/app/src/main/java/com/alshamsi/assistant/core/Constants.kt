package com.alshamsi.assistant.core

object Constants {
    const val DATABASE_NAME = "alshamsi.db"
    const val SETTINGS_STORE = "alshamsi_settings"

    const val VOICE_CHANNEL_ID = "alshamsi_voice_channel"
    const val VOICE_NOTIFICATION_ID = 1101

    const val PROVIDER_OFFLINE = "offline_rules"
    const val PROVIDER_LOCAL_LLM = "local_llm"

    const val DEFAULT_LOCAL_ENDPOINT = "http://192.168.1.10:11434"
    const val DEFAULT_LOCAL_MODEL = "qwen2.5:3b"

    const val ACTION_STOP_VOICE = "com.alshamsi.assistant.action.STOP_VOICE"
    const val ACTION_START_VOICE = "com.alshamsi.assistant.action.START_VOICE"

    const val MAX_SCREEN_TEXT_NODES = 120
    const val MAX_NOTIFICATIONS_CACHED = 50
}
