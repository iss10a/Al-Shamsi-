package com.alshamsi.assistant.device.control

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import com.alshamsi.assistant.core.ArabicText
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

data class InstalledApp(
    val packageName: String,
    val label: String
)

@Singleton
class AppLauncher @Inject constructor(
    @ApplicationContext private val context: Context
) {

    /** Common Arabic aliases mapped to the package families that provide them. */
    private val aliases: Map<String, List<String>> = mapOf(
        "الواتس" to listOf("com.whatsapp", "com.whatsapp.w4b"),
        "واتساب" to listOf("com.whatsapp", "com.whatsapp.w4b"),
        "تلجرام" to listOf("org.telegram.messenger", "org.thunderdog.challegram"),
        "تليجرام" to listOf("org.telegram.messenger"),
        "انستقرام" to listOf("com.instagram.android"),
        "سناب" to listOf("com.snapchat.android"),
        "تويتر" to listOf("com.twitter.android"),
        "يوتيوب" to listOf("com.google.android.youtube"),
        "خرائط" to listOf("com.google.android.apps.maps"),
        "الخرائط" to listOf("com.google.android.apps.maps"),
        "المتصفح" to listOf("com.android.chrome", "org.mozilla.firefox"),
        "كروم" to listOf("com.android.chrome"),
        "الاتصال" to listOf("com.google.android.dialer", "com.android.dialer"),
        "الهاتف" to listOf("com.google.android.dialer", "com.android.dialer"),
        "الرسائل" to listOf("com.google.android.apps.messaging", "com.android.messaging"),
        "الجاليري" to listOf("com.google.android.apps.photos", "com.android.gallery3d"),
        "الصور" to listOf("com.google.android.apps.photos"),
        "المعرض" to listOf("com.google.android.apps.photos", "com.android.gallery3d"),
        "الكاميرا" to listOf("com.android.camera", "com.google.android.GoogleCamera"),
        "المتجر" to listOf("com.android.vending"),
        "قوقل بلاي" to listOf("com.android.vending"),
        "الحاسبه" to listOf("com.google.android.calculator", "com.android.calculator2"),
        "التقويم" to listOf("com.google.android.calendar", "com.android.calendar"),
        "الساعه" to listOf("com.google.android.deskclock", "com.android.deskclock"),
        "المنبه" to listOf("com.google.android.deskclock", "com.android.deskclock")
    )

    fun installedApps(): List<InstalledApp> {
        val manager = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved: List<ResolveInfo> = runCatching {
            manager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        }.getOrDefault(emptyList())
        return resolved.mapNotNull { info ->
            val packageName = info.activityInfo?.packageName ?: return@mapNotNull null
            if (packageName == context.packageName) return@mapNotNull null
            val label = runCatching { info.loadLabel(manager).toString() }
                .getOrDefault(packageName)
            InstalledApp(packageName, label)
        }.distinctBy { it.packageName }.sortedBy { it.label }
    }

    fun resolve(query: String): InstalledApp? {
        val normalizedQuery = ArabicText.normalize(query)
        if (normalizedQuery.isEmpty()) return null
        val apps = installedApps()

        aliases.entries.firstOrNull { entry ->
            val key = ArabicText.normalize(entry.key)
            key.isNotEmpty() && (normalizedQuery.contains(key) || key.contains(normalizedQuery))
        }?.let { entry ->
            val match = entry.value.firstNotNullOfOrNull { candidate ->
                apps.firstOrNull { it.packageName == candidate }
            }
            if (match != null) return match
        }

        apps.firstOrNull { ArabicText.normalize(it.label) == normalizedQuery }?.let { return it }
        apps.firstOrNull { ArabicText.normalize(it.label).contains(normalizedQuery) }
            ?.let { return it }
        apps.firstOrNull { normalizedQuery.contains(ArabicText.normalize(it.label)) }
            ?.let { return it }
        return apps.firstOrNull { ArabicText.normalize(it.packageName).contains(normalizedQuery) }
    }

    fun launchIntentFor(packageName: String): Intent? =
        context.packageManager.getLaunchIntentForPackage(packageName)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}
