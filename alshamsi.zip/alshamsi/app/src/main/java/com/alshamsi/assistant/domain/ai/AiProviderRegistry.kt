package com.alshamsi.assistant.domain.ai

import com.alshamsi.assistant.core.Constants
import com.alshamsi.assistant.domain.model.AppSettings
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Chooses the provider selected in the settings and falls back to the offline engine
 * whenever the preferred one is not reachable, so the assistant always answers.
 */
@Singleton
class AiProviderRegistry @Inject constructor(
    private val providers: Set<@JvmSuppressWildcards AiProvider>
) {

    fun all(): List<AiProvider> = providers.sortedBy { it.requiresNetwork }

    fun byId(id: String): AiProvider? = providers.firstOrNull { it.id == id }

    private fun fallback(): AiProvider? =
        providers.firstOrNull { it.id == Constants.PROVIDER_OFFLINE } ?: providers.firstOrNull()

    suspend fun generate(request: AiRequest, settings: AppSettings): AiResult {
        val preferred = byId(settings.aiProviderId)
        if (preferred != null && preferred.isAvailable(settings)) {
            val result = preferred.generate(request, settings)
            if (result is AiResult.Answer) return result
        }
        val backup = fallback() ?: return AiResult.Unavailable("ما فيه محرك ذكاء متاح حالياً.")
        if (preferred != null && backup.id == preferred.id) {
            return AiResult.Unavailable("محرك «" + preferred.displayName + "» غير متاح الآن.")
        }
        return backup.generate(request, settings)
    }
}
