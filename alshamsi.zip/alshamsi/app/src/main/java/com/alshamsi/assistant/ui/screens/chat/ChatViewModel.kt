package com.alshamsi.assistant.ui.screens.chat

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.alshamsi.assistant.command.CommandCoordinator
import com.alshamsi.assistant.domain.model.ChatMessage
import com.alshamsi.assistant.domain.model.CommandSource
import com.alshamsi.assistant.domain.repository.ChatRepository
import com.alshamsi.assistant.voice.VoiceState
import com.alshamsi.assistant.voice.WakeWordService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@HiltViewModel
class ChatViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    chatRepository: ChatRepository,
    private val coordinator: CommandCoordinator
) : ViewModel() {

    val messages: StateFlow<List<ChatMessage>> = chatRepository.observeMessages(200)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val busy: StateFlow<Boolean> = coordinator.busy

    val listening: StateFlow<Boolean> = VoiceState.serviceRunning
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    private val _input = MutableStateFlow("")
    val input: StateFlow<String> = _input.asStateFlow()

    fun onInputChange(value: String) {
        _input.value = value
    }

    fun send() {
        val text = _input.value.trim()
        if (text.isEmpty()) return
        _input.value = ""
        viewModelScope.launch {
            coordinator.handle(text, CommandSource.TEXT)
        }
    }

    fun toggleVoice() {
        if (VoiceState.serviceRunning.value) {
            WakeWordService.stop(context)
        } else {
            WakeWordService.start(context)
        }
    }
}
