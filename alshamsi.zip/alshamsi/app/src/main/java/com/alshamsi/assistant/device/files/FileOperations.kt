package com.alshamsi.assistant.device.files

import android.content.Context
import android.os.Build
import android.os.Environment
import com.alshamsi.assistant.core.ArabicText
import com.alshamsi.assistant.core.IoDispatcher
import com.alshamsi.assistant.core.OperationResult
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.withContext

data class FileMatch(
    val path: String,
    val name: String,
    val sizeBytes: Long,
    val isDirectory: Boolean,
    val lastModified: Long
)

/**
 * File management on public storage. All destructive operations are only reached
 * after the confirmation dialog has been accepted by the user.
 */
@Singleton
class FileOperations @Inject constructor(
    @ApplicationContext private val context: Context,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) {

    private val maxSearchResults = 40
    private val maxSearchDepth = 6

    fun hasFullFileAccess(): Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Environment.isExternalStorageManager()
    } else {
        true
    }

    fun roots(): List<File> {
        val result = ArrayList<File>()
        runCatching { Environment.getExternalStorageDirectory() }.getOrNull()
            ?.takeIf { it.exists() }
            ?.let { result.add(it) }
        context.getExternalFilesDir(null)?.let { result.add(it) }
        result.add(context.filesDir)
        return result.distinctBy { it.absolutePath }
    }

    suspend fun search(query: String): OperationResult<List<FileMatch>> =
        withContext(ioDispatcher) {
            val normalizedQuery = ArabicText.normalize(query)
            if (normalizedQuery.isEmpty()) {
                return@withContext OperationResult.Failure("حدد اسم الملف المطلوب.")
            }
            val matches = LinkedHashMap<String, FileMatch>()
            for (root in roots()) {
                walk(root, 0) { file ->
                    if (matches.size >= maxSearchResults) return@walk false
                    val name = ArabicText.normalize(file.name)
                    if (name.contains(normalizedQuery)) {
                        matches[file.absolutePath] = file.toMatch()
                    }
                    true
                }
                if (matches.size >= maxSearchResults) break
            }
            if (matches.isEmpty()) {
                OperationResult.Failure("ما لقيت ملفاً يطابق «" + query + "».")
            } else {
                OperationResult.Success(matches.values.toList())
            }
        }

    suspend fun resolveSingle(query: String): OperationResult<File> = withContext(ioDispatcher) {
        val direct = File(query)
        if (direct.isAbsolute && direct.exists()) {
            return@withContext OperationResult.Success(direct)
        }
        when (val found = search(query)) {
            is OperationResult.Failure -> found
            is OperationResult.Success -> {
                val files = found.data.filter { !it.isDirectory }
                    .ifEmpty { found.data }
                val best = files.minByOrNull { it.name.length }
                if (best == null) {
                    OperationResult.Failure("ما لقيت الملف المطلوب.")
                } else {
                    OperationResult.Success(File(best.path))
                }
            }
        }
    }

    suspend fun copy(sourceQuery: String, destination: String): OperationResult<String> =
        withContext(ioDispatcher) {
            when (val source = resolveSingle(sourceQuery)) {
                is OperationResult.Failure -> source
                is OperationResult.Success -> OperationResult.runCatchingResult("فشل نسخ الملف") {
                    val target = resolveDestination(source.data, destination)
                    ensureParent(target)
                    source.data.copyTo(target, overwrite = true)
                    target.absolutePath
                }
            }
        }

    suspend fun move(sourceQuery: String, destination: String): OperationResult<String> =
        withContext(ioDispatcher) {
            when (val source = resolveSingle(sourceQuery)) {
                is OperationResult.Failure -> source
                is OperationResult.Success -> OperationResult.runCatchingResult("فشل نقل الملف") {
                    val target = resolveDestination(source.data, destination)
                    ensureParent(target)
                    if (!source.data.renameTo(target)) {
                        source.data.copyTo(target, overwrite = true)
                        if (!source.data.delete()) {
                            error("تم النسخ لكن تعذر حذف الأصل")
                        }
                    }
                    target.absolutePath
                }
            }
        }

    suspend fun rename(sourceQuery: String, newName: String): OperationResult<String> =
        withContext(ioDispatcher) {
            when (val source = resolveSingle(sourceQuery)) {
                is OperationResult.Failure -> source
                is OperationResult.Success ->
                    OperationResult.runCatchingResult("فشلت إعادة التسمية") {
                        val safeName = newName.trim().replace('/', '_')
                        if (safeName.isEmpty()) error("الاسم الجديد فارغ")
                        val target = File(source.data.parentFile, safeName)
                        if (!source.data.renameTo(target)) error("النظام رفض إعادة التسمية")
                        target.absolutePath
                    }
            }
        }

    suspend fun delete(pathQuery: String): OperationResult<String> = withContext(ioDispatcher) {
        when (val source = resolveSingle(pathQuery)) {
            is OperationResult.Failure -> source
            is OperationResult.Success -> OperationResult.runCatchingResult("فشل الحذف") {
                val file = source.data
                val name = file.name
                val deleted = if (file.isDirectory) file.deleteRecursively() else file.delete()
                if (!deleted) error("النظام رفض حذف الملف")
                name
            }
        }
    }

    private fun ensureParent(target: File) {
        val parent = target.parentFile ?: return
        if (!parent.exists() && !parent.mkdirs()) {
            error("تعذر إنشاء المجلد الهدف")
        }
    }

    private fun resolveDestination(source: File, destination: String): File {
        val trimmed = destination.trim()
        if (trimmed.isEmpty()) error("حدد المسار الهدف")
        val candidate = if (trimmed.startsWith("/")) {
            File(trimmed)
        } else {
            File(Environment.getExternalStorageDirectory(), trimmed)
        }
        return if (candidate.isDirectory || trimmed.endsWith("/")) {
            File(candidate, source.name)
        } else {
            candidate
        }
    }

    private fun walk(root: File, depth: Int, visitor: (File) -> Boolean) {
        if (depth > maxSearchDepth) return
        if (!root.exists() || !root.canRead()) return
        val children = root.listFiles() ?: return
        for (child in children) {
            if (child.name.startsWith(".")) continue
            if (!visitor(child)) return
            if (child.isDirectory) {
                walk(child, depth + 1, visitor)
            }
        }
    }

    private fun File.toMatch(): FileMatch = FileMatch(
        path = absolutePath,
        name = name,
        sizeBytes = if (isDirectory) 0L else length(),
        isDirectory = isDirectory,
        lastModified = lastModified()
    )
}
