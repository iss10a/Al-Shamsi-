package com.alshamsi.assistant.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.alshamsi.assistant.command.ConfirmationManager
import com.alshamsi.assistant.command.PendingConfirmation
import com.alshamsi.assistant.domain.model.AppSettings
import com.alshamsi.assistant.domain.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

@HiltViewModel
class MainViewModel @Inject constructor(
    settingsRepository: SettingsRepository,
    private val confirmationManager: ConfirmationManager
) : ViewModel() {

    val settings: StateFlow<AppSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    val pendingConfirmation: StateFlow<PendingConfirmation?> = confirmationManager.pending
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun confirm() = confirmationManager.confirm()

    fun cancel() = confirmationManager.cancel()
}
