package com.alshamsi.assistant.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.alshamsi.assistant.data.local.entity.LogEntryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface LogDao {

    @Query("SELECT * FROM log_entries ORDER BY timestamp DESC, id DESC LIMIT :limit")
    fun observeLogs(limit: Int): Flow<List<LogEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: LogEntryEntity): Long

    @Query("DELETE FROM log_entries")
    suspend fun clear()

    @Query("DELETE FROM log_entries WHERE timestamp < :timestamp")
    suspend fun deleteOlderThan(timestamp: Long): Int
}
