package com.alshamsi.assistant.core

/**
 * Normalisation helpers for Arabic user input so that keyword matching is tolerant
 * of diacritics, hamza variants, tatweel and Arabic-Indic digits.
 */
object ArabicText {

    private val DIACRITICS = Regex("[\\u064B-\\u065F\\u0670\\u06D6-\\u06ED]")
    private val TATWEEL = Regex("\\u0640")
    private val NON_MEANINGFUL = Regex("[^\\p{L}\\p{N}\\s./:_\\-]")
    private val MULTI_SPACE = Regex("\\s+")

    private const val ARABIC_INDIC_ZERO = '\u0660'
    private const val EXTENDED_ARABIC_INDIC_ZERO = '\u06F0'

    fun normalize(input: String): String {
        if (input.isEmpty()) return ""
        var text = input.trim()
        text = DIACRITICS.replace(text, "")
        text = TATWEEL.replace(text, "")
        val builder = StringBuilder(text.length)
        for (raw in text) {
            val ch = when (raw) {
                'أ', 'إ', 'آ', 'ٱ' -> 'ا'
                'ى' -> 'ي'
                'ؤ' -> 'و'
                'ئ' -> 'ي'
                'ة' -> 'ه'
                'ـ' -> ' '
                else -> raw
            }
            builder.append(convertDigit(ch))
        }
        text = builder.toString().lowercase()
        text = NON_MEANINGFUL.replace(text, " ")
        text = MULTI_SPACE.replace(text, " ")
        return text.trim()
    }

    private fun convertDigit(ch: Char): Char = when (ch) {
        in ARABIC_INDIC_ZERO..(ARABIC_INDIC_ZERO + 9) ->
            ('0' + (ch - ARABIC_INDIC_ZERO))

        in EXTENDED_ARABIC_INDIC_ZERO..(EXTENDED_ARABIC_INDIC_ZERO + 9) ->
            ('0' + (ch - EXTENDED_ARABIC_INDIC_ZERO))

        else -> ch
    }

    fun containsAny(haystack: String, needles: List<String>): Boolean {
        val normalized = normalize(haystack)
        return needles.any { normalized.contains(normalize(it)) }
    }

    fun startsWithAny(haystack: String, needles: List<String>): String? {
        val normalized = normalize(haystack)
        for (needle in needles) {
            val normalizedNeedle = normalize(needle)
            if (normalizedNeedle.isNotEmpty() && normalized.startsWith(normalizedNeedle)) {
                return normalized.removePrefix(normalizedNeedle).trim()
            }
        }
        return null
    }

    /** Returns the text that follows the first occurrence of any of [markers]. */
    fun after(haystack: String, markers: List<String>): String? {
        val normalized = normalize(haystack)
        for (marker in markers) {
            val normalizedMarker = normalize(marker)
            if (normalizedMarker.isEmpty()) continue
            val index = normalized.indexOf(normalizedMarker)
            if (index >= 0) {
                return normalized.substring(index + normalizedMarker.length).trim()
            }
        }
        return null
    }

    fun extractNumbers(input: String): List<Int> {
        return Regex("\\d+").findAll(normalize(input))
            .mapNotNull { it.value.toIntOrNull() }
            .toList()
    }
}
