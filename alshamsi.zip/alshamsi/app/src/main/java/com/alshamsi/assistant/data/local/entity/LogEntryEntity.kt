package com.alshamsi.assistant.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.alshamsi.assistant.domain.model.CommandSource
import com.alshamsi.assistant.domain.model.LogEntry
import com.alshamsi.assistant.domain.model.LogStatus

@Entity(tableName = "log_entries")
data class LogEntryEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Long = 0L,
    @ColumnInfo(name = "title")
    val title: String,
    @ColumnInfo(name = "details")
    val details: String,
    @ColumnInfo(name = "status")
    val status: LogStatus,
    @ColumnInfo(name = "source")
    val source: CommandSource,
    @ColumnInfo(name = "timestamp")
    val timestamp: Long
)

fun LogEntryEntity.toDomain(): LogEntry = LogEntry(
    id = id,
    title = title,
    details = details,
    status = status,
    source = source,
    timestamp = timestamp
)

fun LogEntry.toEntity(): LogEntryEntity = LogEntryEntity(
    id = id,
    title = title,
    details = details,
    status = status,
    source = source,
    timestamp = timestamp
)
