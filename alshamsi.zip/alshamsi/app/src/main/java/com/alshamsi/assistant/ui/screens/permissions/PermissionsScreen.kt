package com.alshamsi.assistant.ui.screens.permissions

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.alshamsi.assistant.domain.model.PermissionItem
import com.alshamsi.assistant.domain.model.PermissionKey
import com.alshamsi.assistant.ui.components.SectionCard
import com.alshamsi.assistant.ui.components.StatusPill

@Composable
fun PermissionsScreen(
    onBack: () -> Unit,
    viewModel: PermissionsViewModel = hiltViewModel()
) {
    val items by viewModel.items.collectAsStateWithLifecycle()

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { viewModel.refresh() }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(text = "الصلاحيات المطلوبة", style = MaterialTheme.typography.headlineSmall)
                Text(
                    text = "يشرح هذا القسم كل صلاحية وسبب طلبها. لن يعمل الشامسي بكامل قدراته " +
                        "إلا بعد منحها، وكل شيء يبقى داخل جهازك.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        items(items = items, key = { it.key.name }) { item ->
            PermissionCard(
                item = item,
                onRequest = {
                    val handled = viewModel.openSystemScreen(item.key)
                    if (!handled) {
                        launcher.launch(runtimePermissionsFor(item.key))
                    }
                }
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(onClick = viewModel::refresh, modifier = Modifier.weight(1f)) {
                    Text(text = "تحديث الحالة")
                }
                OutlinedButton(onClick = viewModel::openAppDetails, modifier = Modifier.weight(1f)) {
                    Text(text = "إعدادات التطبيق")
                }
            }
        }

        item {
            OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
                Text(text = "رجوع")
            }
        }
    }
}

@Composable
private fun PermissionCard(item: PermissionItem, onRequest: () -> Unit) {
    SectionCard(title = item.title, subtitle = item.reason) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatusPill(
                text = if (item.granted) "ممنوحة" else "غير ممنوحة",
                positive = item.granted
            )
            if (!item.granted) {
                Button(onClick = onRequest, modifier = Modifier.padding(start = 8.dp)) {
                    Text(text = "منح الصلاحية")
                }
            }
        }
    }
}

private fun runtimePermissionsFor(key: PermissionKey): Array<String> = when (key) {
    PermissionKey.MICROPHONE -> arrayOf(Manifest.permission.RECORD_AUDIO)

    PermissionKey.POST_NOTIFICATIONS ->
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            emptyArray()
        }

    PermissionKey.MEDIA_ACCESS ->
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            )
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

    else -> emptyArray()
}
