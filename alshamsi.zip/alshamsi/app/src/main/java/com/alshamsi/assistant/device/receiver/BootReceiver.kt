package com.alshamsi.assistant.device.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.alshamsi.assistant.domain.repository.SettingsRepository
import com.alshamsi.assistant.voice.WakeWordService
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Restores the background listener after a reboot or an application update. */
@AndroidEntryPoint
class BootReceiver : BroadcastReceiver() {

    @Inject
    lateinit var settingsRepository: SettingsRepository

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) {
            return
        }
        val pendingResult = goAsync()
        val appContext = context.applicationContext
        scope.launch {
            try {
                val settings = settingsRepository.current()
                if (settings.wakeWordEnabled) {
                    WakeWordService.start(appContext)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
