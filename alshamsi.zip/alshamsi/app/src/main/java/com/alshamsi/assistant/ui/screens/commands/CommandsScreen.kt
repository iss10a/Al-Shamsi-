package com.alshamsi.assistant.ui.screens.commands

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.alshamsi.assistant.domain.model.Macro
import com.alshamsi.assistant.ui.components.SectionCard

private val builtInCommands = listOf(
    "افتح [اسم التطبيق]" to "يفتح أي تطبيق مثبت، ويفهم الأسماء الشائعة مثل «الواتس» و«الخرائط».",
    "أغلق التطبيق" to "يرجع للخلف حتى يخرج من التطبيق الحالي (ضمن ما يسمح به النظام).",
    "افتح الإعدادات / الواي فاي / البلوتوث" to "يفتح صفحة الإعدادات المطلوبة مباشرة.",
    "شغل الكشاف / اطفِ الكشاف" to "يتحكم بمصباح الكاميرا.",
    "اضغط على [نص]" to "يبحث عن العنصر على الشاشة ويضغطه.",
    "اضغط 540 1200" to "ضغطة بإحداثيات دقيقة.",
    "اسحب 500 1500 500 500" to "سحب من نقطة إلى أخرى.",
    "اكتب [النص]" to "يكتب النص في حقل الإدخال النشط (يطلب تأكيدك).",
    "اقرأ الشاشة" to "يقرأ محتوى الشاشة الحالي.",
    "اقرأ الإشعارات" to "يقرأ آخر الإشعارات.",
    "رد على واتساب: [النص]" to "يرد مباشرة على الإشعار إذا سمح التطبيق (يطلب تأكيدك).",
    "ابحث عن ملف [اسم]" to "يبحث في ذاكرة الجهاز.",
    "انسخ [ملف] إلى [مسار]" to "نسخ ملف (يطلب تأكيدك).",
    "انقل [ملف] إلى [مسار]" to "نقل ملف (يطلب تأكيدك).",
    "أعد تسمية [ملف] إلى [اسم]" to "إعادة تسمية (يطلب تأكيدك).",
    "احذف [ملف]" to "حذف نهائي بعد التأكيد.",
    "شارك [ملف]" to "يفتح قائمة المشاركة (يطلب تأكيدك).",
    "افتح رابط [العنوان]" to "يفتح الرابط في المتصفح.",
    "ابحث عن [كلمة]" to "بحث في الويب.",
    "افتح الكاميرا ثم اضغط على تصوير" to "أوامر متتابعة مفصولة بكلمة «ثم».",
    "شغل ماكرو [الاسم]" to "ينفذ ماكرو محفوظ.",
    "وقف / مع السلامة" to "يوقف الاستماع."
)

@Composable
fun CommandsScreen(viewModel: CommandsViewModel = hiltViewModel()) {
    val macros by viewModel.macros.collectAsStateWithLifecycle()
    var editorOpen by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Macro?>(null) }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(text = "الأوامر والماكرو", style = MaterialTheme.typography.headlineSmall)
            }

            if (macros.isEmpty()) {
                item {
                    Text(
                        text = "لا توجد أوامر مخصصة بعد. اضغط زر الإضافة لإنشاء ماكرو من عدة خطوات.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(items = macros, key = { it.id }) { macro ->
                    SectionCard(
                        title = macro.name,
                        subtitle = macro.description.ifBlank {
                            macro.steps.size.toString() + " خطوة"
                        }
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            macro.steps.forEachIndexed { index, step ->
                                Text(
                                    text = (index + 1).toString() + ". " + step.rawCommand,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(onClick = { viewModel.run(macro) }) {
                                    Text(text = "تشغيل")
                                }
                                OutlinedButton(onClick = {
                                    editing = macro
                                    editorOpen = true
                                }) {
                                    Text(text = "تعديل")
                                }
                                OutlinedButton(onClick = { viewModel.delete(macro) }) {
                                    Text(text = "حذف")
                                }
                            }
                        }
                    }
                }
            }

            item {
                SectionCard(
                    title = "الأوامر المدعومة",
                    subtitle = "اكتبها أو قلها بعد كلمة التنبيه."
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        builtInCommands.forEach { entry ->
                            Column {
                                Text(
                                    text = entry.first,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = entry.second,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = {
                editing = null
                editorOpen = true
            },
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(20.dp)
        ) {
            Icon(imageVector = Icons.Filled.Add, contentDescription = "ماكرو جديد")
        }
    }

    if (editorOpen) {
        MacroEditorDialog(
            macro = editing,
            onDismiss = { editorOpen = false },
            onSave = { name, description, steps, id ->
                viewModel.save(name, description, steps, id)
                editorOpen = false
            }
        )
    }
}

@Composable
private fun MacroEditorDialog(
    macro: Macro?,
    onDismiss: () -> Unit,
    onSave: (String, String, String, Long) -> Unit
) {
    var name by remember { mutableStateOf(macro?.name.orEmpty()) }
    var description by remember { mutableStateOf(macro?.description.orEmpty()) }
    var steps by remember {
        mutableStateOf(macro?.steps?.joinToString("\n") { it.rawCommand }.orEmpty())
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = if (macro == null) "ماكرو جديد" else "تعديل الماكرو") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(text = "اسم الماكرو") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text(text = "الوصف") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = steps,
                    onValueChange = { steps = it },
                    label = { Text(text = "الخطوات (أمر في كل سطر)") },
                    minLines = 3,
                    maxLines = 8,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onSave(name, description, steps, macro?.id ?: 0L) },
                enabled = name.isNotBlank() && steps.isNotBlank()
            ) {
                Text(text = "حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(text = "إلغاء") }
        }
    )
}
