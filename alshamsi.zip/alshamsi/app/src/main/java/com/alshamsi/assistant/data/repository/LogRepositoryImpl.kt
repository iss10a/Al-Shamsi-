package com.alshamsi.assistant.data.repository

import com.alshamsi.assistant.core.IoDispatcher
import com.alshamsi.assistant.data.local.dao.LogDao
import com.alshamsi.assistant.data.local.entity.toDomain
import com.alshamsi.assistant.data.local.entity.toEntity
import com.alshamsi.assistant.domain.model.LogEntry
import com.alshamsi.assistant.domain.repository.LogRepository
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

@Singleton
class LogRepositoryImpl @Inject constructor(
    private val logDao: LogDao,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) : LogRepository {

    override fun observeLogs(limit: Int): Flow<List<LogEntry>> =
        logDao.observeLogs(limit)
            .map { list -> list.map { it.toDomain() } }
            .flowOn(ioDispatcher)

    override suspend fun add(entry: LogEntry): Long = withContext(ioDispatcher) {
        logDao.insert(entry.toEntity())
    }

    override suspend fun clear() = withContext(ioDispatcher) {
        logDao.clear()
    }

    override suspend fun deleteOlderThan(timestamp: Long): Int = withContext(ioDispatcher) {
        logDao.deleteOlderThan(timestamp)
    }
}
