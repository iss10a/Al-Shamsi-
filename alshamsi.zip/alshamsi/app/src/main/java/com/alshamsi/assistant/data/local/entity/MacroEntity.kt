package com.alshamsi.assistant.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.alshamsi.assistant.domain.model.Macro
import com.alshamsi.assistant.domain.model.MacroStep

@Entity(tableName = "macros")
data class MacroEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Long = 0L,
    @ColumnInfo(name = "name")
    val name: String,
    @ColumnInfo(name = "description")
    val description: String,
    @ColumnInfo(name = "steps")
    val steps: List<MacroStep>,
    @ColumnInfo(name = "created_at")
    val createdAt: Long,
    @ColumnInfo(name = "last_run_at")
    val lastRunAt: Long?
)

fun MacroEntity.toDomain(): Macro = Macro(
    id = id,
    name = name,
    description = description,
    steps = steps,
    createdAt = createdAt,
    lastRunAt = lastRunAt
)

fun Macro.toEntity(): MacroEntity = MacroEntity(
    id = id,
    name = name,
    description = description,
    steps = steps,
    createdAt = createdAt,
    lastRunAt = lastRunAt
)
