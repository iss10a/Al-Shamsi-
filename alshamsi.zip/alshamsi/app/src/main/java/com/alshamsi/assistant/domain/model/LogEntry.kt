package com.alshamsi.assistant.domain.model

data class LogEntry(
    val id: Long = 0L,
    val title: String,
    val details: String,
    val status: LogStatus,
    val source: CommandSource,
    val timestamp: Long = System.currentTimeMillis()
)

enum class LogStatus {
    SUCCESS,
    FAILURE,
    CANCELLED,
    PERMISSION_REQUIRED
}
