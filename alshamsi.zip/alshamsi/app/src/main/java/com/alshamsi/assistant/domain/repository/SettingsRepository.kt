package com.alshamsi.assistant.domain.repository

import com.alshamsi.assistant.domain.model.AppSettings
import com.alshamsi.assistant.domain.model.ThemeMode
import kotlinx.coroutines.flow.Flow

interface SettingsRepository {
    val settings: Flow<AppSettings>
    suspend fun current(): AppSettings
    suspend fun setThemeMode(mode: ThemeMode)
    suspend fun setDynamicColor(enabled: Boolean)
    suspend fun setSpokenReplies(enabled: Boolean)
    suspend fun setWakeWordEnabled(enabled: Boolean)
    suspend fun setSpeechRate(rate: Float)
    suspend fun setSpeechPitch(pitch: Float)
    suspend fun setConfirmDangerousActions(enabled: Boolean)
    suspend fun setAiProvider(providerId: String)
    suspend fun setLocalEndpoint(endpoint: String)
    suspend fun setLocalModel(model: String)
    suspend fun setLogRetentionDays(days: Int)
}
