package com.alshamsi.assistant.device.notification

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.alshamsi.assistant.core.ArabicText
import com.alshamsi.assistant.domain.model.NotificationInfo

/**
 * Reads notifications and, when the posting app exposes a direct-reply action,
 * sends a reply on the user's behalf.
 */
class ShamsiNotificationListener : NotificationListenerService() {

    private val replyActions = HashMap<String, PendingReply>()

    override fun onListenerConnected() {
        super.onListenerConnected()
        NotificationBridge.attach(this)
        runCatching { activeNotifications }.getOrNull()?.forEach { cache(it) }
    }

    override fun onListenerDisconnected() {
        NotificationBridge.detach()
        replyActions.clear()
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        NotificationBridge.detach()
        replyActions.clear()
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        cache(sbn)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn == null) return
        NotificationBridge.remove(sbn.key)
        replyActions.remove(sbn.key)
    }

    private fun cache(sbn: StatusBarNotification) {
        val notification = sbn.notification ?: return
        if (notification.flags and Notification.FLAG_ONGOING_EVENT != 0 &&
            sbn.packageName == packageName
        ) {
            return
        }
        val extras: Bundle = notification.extras ?: Bundle()
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        val pendingReply = findReplyAction(notification)
        if (pendingReply != null) {
            replyActions[sbn.key] = pendingReply
        }

        NotificationBridge.publish(
            NotificationInfo(
                key = sbn.key,
                packageName = sbn.packageName,
                appLabel = appLabel(sbn.packageName),
                title = title,
                text = text,
                postedAt = sbn.postTime,
                canReply = pendingReply != null
            )
        )
    }

    private fun appLabel(packageName: String): String {
        val manager: PackageManager = packageManager
        return runCatching {
            val info = manager.getApplicationInfo(packageName, 0)
            manager.getApplicationLabel(info).toString()
        }.getOrDefault(packageName)
    }

    private fun findReplyAction(notification: Notification): PendingReply? {
        val actions = notification.actions ?: return null
        for (action in actions) {
            val remoteInputs = action.remoteInputs ?: continue
            val target = remoteInputs.firstOrNull { it.allowFreeFormInput } ?: continue
            val intent = action.actionIntent ?: continue
            return PendingReply(intent, target, remoteInputs)
        }
        return null
    }

    /** Returns true when a reply was actually dispatched. */
    fun replyTo(notificationKey: String, message: String): Boolean {
        val pending = replyActions[notificationKey] ?: return false
        return runCatching {
            val bundle = Bundle()
            bundle.putCharSequence(pending.target.resultKey, message)
            val intent = Intent()
            RemoteInput.addResultsToIntent(pending.allInputs, intent, bundle)
            pending.actionIntent.send(this, 0, intent)
            true
        }.getOrDefault(false)
    }

    fun findReplyableKey(appQuery: String): String? {
        val normalizedQuery = ArabicText.normalize(appQuery)
        val candidates = NotificationBridge.notifications.value.filter {
            it.canReply && replyActions.containsKey(it.key)
        }
        if (normalizedQuery.isEmpty()) return candidates.firstOrNull()?.key
        return candidates.firstOrNull {
            ArabicText.normalize(it.appLabel).contains(normalizedQuery) ||
                ArabicText.normalize(it.packageName).contains(normalizedQuery) ||
                ArabicText.normalize(it.title).contains(normalizedQuery)
        }?.key
    }

    private data class PendingReply(
        val actionIntent: PendingIntent,
        val target: RemoteInput,
        val allInputs: Array<RemoteInput>
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is PendingReply) return false
            return actionIntent == other.actionIntent && target == other.target
        }

        override fun hashCode(): Int = 31 * actionIntent.hashCode() + target.hashCode()
    }
}
