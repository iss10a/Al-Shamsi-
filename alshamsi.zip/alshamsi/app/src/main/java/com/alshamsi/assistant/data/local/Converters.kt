package com.alshamsi.assistant.data.local

import androidx.room.TypeConverter
import com.alshamsi.assistant.domain.model.CommandSource
import com.alshamsi.assistant.domain.model.LogStatus
import com.alshamsi.assistant.domain.model.MacroStep
import com.alshamsi.assistant.domain.model.MessageRole
import org.json.JSONArray
import org.json.JSONObject

class Converters {

    @TypeConverter
    fun fromMessageRole(value: MessageRole): String = value.name

    @TypeConverter
    fun toMessageRole(value: String): MessageRole =
        runCatching { MessageRole.valueOf(value) }.getOrDefault(MessageRole.SYSTEM)

    @TypeConverter
    fun fromCommandSource(value: CommandSource): String = value.name

    @TypeConverter
    fun toCommandSource(value: String): CommandSource =
        runCatching { CommandSource.valueOf(value) }.getOrDefault(CommandSource.TEXT)

    @TypeConverter
    fun fromLogStatus(value: LogStatus): String = value.name

    @TypeConverter
    fun toLogStatus(value: String): LogStatus =
        runCatching { LogStatus.valueOf(value) }.getOrDefault(LogStatus.FAILURE)

    @TypeConverter
    fun fromSteps(steps: List<MacroStep>): String {
        val array = JSONArray()
        for (step in steps) {
            val obj = JSONObject()
            obj.put("command", step.rawCommand)
            obj.put("delay", step.delayMillis)
            array.put(obj)
        }
        return array.toString()
    }

    @TypeConverter
    fun toSteps(raw: String): List<MacroStep> {
        if (raw.isBlank()) return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            val result = ArrayList<MacroStep>(array.length())
            for (index in 0 until array.length()) {
                val obj = array.optJSONObject(index) ?: continue
                val command = obj.optString("command")
                if (command.isBlank()) continue
                result.add(MacroStep(command, obj.optLong("delay", 400L)))
            }
            result.toList()
        }.getOrDefault(emptyList())
    }
}
