package com.alshamsi.assistant.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.alshamsi.assistant.command.PendingConfirmation
import com.alshamsi.assistant.ui.components.ConfirmationDialog
import com.alshamsi.assistant.ui.navigation.Destination
import com.alshamsi.assistant.ui.screens.chat.ChatScreen
import com.alshamsi.assistant.ui.screens.commands.CommandsScreen
import com.alshamsi.assistant.ui.screens.home.HomeScreen
import com.alshamsi.assistant.ui.screens.logs.LogsScreen
import com.alshamsi.assistant.ui.screens.permissions.PermissionsScreen
import com.alshamsi.assistant.ui.screens.settings.SettingsScreen

@Composable
fun AlshamsiRoot(
    pendingConfirmation: PendingConfirmation?,
    onConfirm: () -> Unit,
    onCancel: () -> Unit
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar {
                Destination.bottomBar.forEach { destination ->
                    val selected = currentDestination?.hierarchy?.any {
                        it.route == destination.route
                    } == true
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            navController.navigate(destination.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = {
                            Icon(
                                imageVector = destination.icon,
                                contentDescription = stringResource(destination.titleRes)
                            )
                        },
                        label = { Text(text = stringResource(destination.titleRes)) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Destination.Home.route,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            composable(Destination.Home.route) {
                HomeScreen(
                    onOpenPermissions = { navController.navigate(Destination.Permissions.route) },
                    onOpenChat = { navController.navigate(Destination.Chat.route) }
                )
            }
            composable(Destination.Chat.route) { ChatScreen() }
            composable(Destination.Commands.route) { CommandsScreen() }
            composable(Destination.Logs.route) { LogsScreen() }
            composable(Destination.Settings.route) {
                SettingsScreen(
                    onOpenPermissions = { navController.navigate(Destination.Permissions.route) }
                )
            }
            composable(Destination.Permissions.route) {
                PermissionsScreen(onBack = { navController.popBackStack() })
            }
        }
    }

    if (pendingConfirmation != null) {
        ConfirmationDialog(
            pending = pendingConfirmation,
            onConfirm = onConfirm,
            onCancel = onCancel
        )
    }
}
