package com.alshamsi.assistant.ui.screens.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.alshamsi.assistant.BuildConfig
import com.alshamsi.assistant.domain.model.ThemeMode
import com.alshamsi.assistant.ui.components.LabelledRow
import com.alshamsi.assistant.ui.components.SectionCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onOpenPermissions: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    var endpoint by remember(settings.localEndpoint) { mutableStateOf(settings.localEndpoint) }
    var model by remember(settings.localModel) { mutableStateOf(settings.localModel) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(text = "الإعدادات", style = MaterialTheme.typography.headlineSmall)
        }

        item {
            SectionCard(title = "المظهر") {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    ThemeMode.entries.forEach { mode ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = settings.themeMode == mode,
                                onClick = { viewModel.setTheme(mode) }
                            )
                            Text(
                                text = when (mode) {
                                    ThemeMode.SYSTEM -> "حسب النظام"
                                    ThemeMode.LIGHT -> "فاتح"
                                    ThemeMode.DARK -> "داكن"
                                },
                                modifier = Modifier.padding(start = 4.dp)
                            )
                        }
                    }
                    LabelledRow(label = "ألوان النظام (Material You)") {
                        Switch(
                            checked = settings.dynamicColor,
                            onCheckedChange = viewModel::setDynamicColor
                        )
                    }
                }
            }
        }

        item {
            SectionCard(title = "الصوت") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    LabelledRow(label = "الرد بالصوت") {
                        Switch(
                            checked = settings.spokenReplies,
                            onCheckedChange = viewModel::setSpokenReplies
                        )
                    }
                    LabelledRow(label = "كلمة التنبيه «يا الشامسي»") {
                        Switch(
                            checked = settings.wakeWordEnabled,
                            onCheckedChange = viewModel::setWakeWord
                        )
                    }
                    Text(
                        text = "سرعة النطق: " + formatFloat(settings.speechRate),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Slider(
                        value = settings.speechRate,
                        onValueChange = viewModel::setSpeechRate,
                        valueRange = 0.5f..2.0f,
                        steps = 5
                    )
                    Text(
                        text = "طبقة الصوت: " + formatFloat(settings.speechPitch),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Slider(
                        value = settings.speechPitch,
                        onValueChange = viewModel::setSpeechPitch,
                        valueRange = 0.5f..2.0f,
                        steps = 5
                    )
                    OutlinedButton(
                        onClick = viewModel::previewVoice,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "تجربة الصوت")
                    }
                }
            }
        }

        item {
            SectionCard(
                title = "الأمان",
                subtitle = "العمليات الخطيرة مثل الحذف والإرسال والتعديل تحتاج موافقتك."
            ) {
                LabelledRow(label = "تأكيد العمليات الخطيرة") {
                    Switch(
                        checked = settings.confirmDangerousActions,
                        onCheckedChange = viewModel::setConfirmDangerous
                    )
                }
            }
        }

        item {
            SectionCard(
                title = "محرك الذكاء الاصطناعي",
                subtitle = "كل المحركات مجانية: محرك محلي داخل التطبيق، أو خادم مفتوح المصدر تملكه."
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    viewModel.providers.forEach { provider ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = settings.aiProviderId == provider.id,
                                onClick = { viewModel.setProvider(provider.id) }
                            )
                            Column(modifier = Modifier.padding(start = 4.dp)) {
                                Text(text = provider.label)
                                Text(
                                    text = if (provider.requiresNetwork) {
                                        "يحتاج خادماً على شبكتك"
                                    } else {
                                        "يعمل بدون إنترنت"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                    OutlinedTextField(
                        value = endpoint,
                        onValueChange = { endpoint = it },
                        label = { Text(text = "عنوان الخادم المحلي") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = model,
                        onValueChange = { model = it },
                        label = { Text(text = "اسم النموذج") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            viewModel.setEndpoint(endpoint)
                            viewModel.setModel(model)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "حفظ إعدادات المحرك")
                    }
                }
            }
        }

        item {
            SectionCard(title = "البيانات") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "مدة حفظ السجل: " + settings.logRetentionDays + " يوماً",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(7, 30, 90, 365).forEach { days ->
                            FilterChip(
                                selected = settings.logRetentionDays == days,
                                onClick = { viewModel.setRetention(days) },
                                label = { Text(text = days.toString()) }
                            )
                        }
                    }
                    OutlinedButton(
                        onClick = viewModel::clearChat,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "مسح المحادثة")
                    }
                }
            }
        }

        item {
            SectionCard(title = "الصلاحيات") {
                OutlinedButton(onClick = onOpenPermissions, modifier = Modifier.fillMaxWidth()) {
                    Text(text = "فتح شاشة الصلاحيات")
                }
            }
        }

        item {
            SectionCard(title = "عن التطبيق") {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = "الشامسي — مساعد شخصي يعمل بدون روت.")
                    Text(
                        text = "الإصدار " + BuildConfig.VERSION_NAME,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "لا يستخدم أي خدمة مدفوعة، ولا يرسل بياناتك لأي جهة خارجية.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

private fun formatFloat(value: Float): String {
    val rounded = Math.round(value * 10f) / 10f
    return rounded.toString()
}
