package com.alshamsi.assistant.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.alshamsi.assistant.data.local.entity.MacroEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MacroDao {

    @Query("SELECT * FROM macros ORDER BY created_at DESC")
    fun observeMacros(): Flow<List<MacroEntity>>

    @Query("SELECT * FROM macros WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): MacroEntity?

    @Query("SELECT * FROM macros")
    suspend fun getAll(): List<MacroEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(macro: MacroEntity): Long

    @Query("DELETE FROM macros WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("UPDATE macros SET last_run_at = :timestamp WHERE id = :id")
    suspend fun markRun(id: Long, timestamp: Long)
}
