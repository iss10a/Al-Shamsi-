package com.alshamsi.assistant.data.repository

import com.alshamsi.assistant.core.ArabicText
import com.alshamsi.assistant.core.IoDispatcher
import com.alshamsi.assistant.data.local.dao.MacroDao
import com.alshamsi.assistant.data.local.entity.toDomain
import com.alshamsi.assistant.data.local.entity.toEntity
import com.alshamsi.assistant.domain.model.Macro
import com.alshamsi.assistant.domain.repository.MacroRepository
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

@Singleton
class MacroRepositoryImpl @Inject constructor(
    private val macroDao: MacroDao,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) : MacroRepository {

    override fun observeMacros(): Flow<List<Macro>> =
        macroDao.observeMacros()
            .map { list -> list.map { it.toDomain() } }
            .flowOn(ioDispatcher)

    override suspend fun getById(id: Long): Macro? = withContext(ioDispatcher) {
        macroDao.getById(id)?.toDomain()
    }

    override suspend fun findByName(name: String): Macro? = withContext(ioDispatcher) {
        val target = ArabicText.normalize(name)
        if (target.isEmpty()) return@withContext null
        val all = macroDao.getAll().map { it.toDomain() }
        all.firstOrNull { ArabicText.normalize(it.name) == target }
            ?: all.firstOrNull { ArabicText.normalize(it.name).contains(target) }
            ?: all.firstOrNull { target.contains(ArabicText.normalize(it.name)) }
    }

    override suspend fun upsert(macro: Macro): Long = withContext(ioDispatcher) {
        macroDao.upsert(macro.toEntity())
    }

    override suspend fun delete(id: Long) = withContext(ioDispatcher) {
        macroDao.delete(id)
    }

    override suspend fun markRun(id: Long, timestamp: Long) = withContext(ioDispatcher) {
        macroDao.markRun(id, timestamp)
    }
}
