package com.alshamsi.assistant.data.repository

import com.alshamsi.assistant.core.IoDispatcher
import com.alshamsi.assistant.data.local.dao.ChatDao
import com.alshamsi.assistant.data.local.entity.toDomain
import com.alshamsi.assistant.data.local.entity.toEntity
import com.alshamsi.assistant.domain.model.ChatMessage
import com.alshamsi.assistant.domain.repository.ChatRepository
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

@Singleton
class ChatRepositoryImpl @Inject constructor(
    private val chatDao: ChatDao,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) : ChatRepository {

    override fun observeMessages(limit: Int): Flow<List<ChatMessage>> =
        chatDao.observeMessages(limit)
            .map { list -> list.map { it.toDomain() } }
            .flowOn(ioDispatcher)

    override suspend fun add(message: ChatMessage): Long = withContext(ioDispatcher) {
        chatDao.insert(message.toEntity())
    }

    override suspend fun recentHistory(limit: Int): List<ChatMessage> = withContext(ioDispatcher) {
        chatDao.recent(limit).map { it.toDomain() }.reversed()
    }

    override suspend fun clear() = withContext(ioDispatcher) {
        chatDao.clear()
    }
}
