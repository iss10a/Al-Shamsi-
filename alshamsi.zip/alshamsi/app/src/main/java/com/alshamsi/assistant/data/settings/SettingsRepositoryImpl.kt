package com.alshamsi.assistant.data.settings

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import com.alshamsi.assistant.core.Constants
import com.alshamsi.assistant.domain.model.AppSettings
import com.alshamsi.assistant.domain.model.ThemeMode
import com.alshamsi.assistant.domain.repository.SettingsRepository
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

@Singleton
class SettingsRepositoryImpl @Inject constructor(
    private val dataStore: DataStore<Preferences>
) : SettingsRepository {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val DYNAMIC_COLOR = booleanPreferencesKey("dynamic_color")
        val SPOKEN_REPLIES = booleanPreferencesKey("spoken_replies")
        val WAKE_WORD = booleanPreferencesKey("wake_word")
        val SPEECH_RATE = floatPreferencesKey("speech_rate")
        val SPEECH_PITCH = floatPreferencesKey("speech_pitch")
        val CONFIRM_DANGEROUS = booleanPreferencesKey("confirm_dangerous")
        val AI_PROVIDER = stringPreferencesKey("ai_provider")
        val LOCAL_ENDPOINT = stringPreferencesKey("local_endpoint")
        val LOCAL_MODEL = stringPreferencesKey("local_model")
        val LOG_RETENTION = intPreferencesKey("log_retention_days")
    }

    override val settings: Flow<AppSettings> = dataStore.data
        .catch { throwable ->
            if (throwable is IOException) {
                emit(androidx.datastore.preferences.core.emptyPreferences())
            } else {
                throw throwable
            }
        }
        .map { preferences -> preferences.toAppSettings() }

    override suspend fun current(): AppSettings = settings.first()

    private fun Preferences.toAppSettings(): AppSettings {
        val defaults = AppSettings()
        val themeName = this[Keys.THEME_MODE] ?: defaults.themeMode.name
        return AppSettings(
            themeMode = runCatching { ThemeMode.valueOf(themeName) }
                .getOrDefault(defaults.themeMode),
            dynamicColor = this[Keys.DYNAMIC_COLOR] ?: defaults.dynamicColor,
            spokenReplies = this[Keys.SPOKEN_REPLIES] ?: defaults.spokenReplies,
            wakeWordEnabled = this[Keys.WAKE_WORD] ?: defaults.wakeWordEnabled,
            speechRate = this[Keys.SPEECH_RATE] ?: defaults.speechRate,
            speechPitch = this[Keys.SPEECH_PITCH] ?: defaults.speechPitch,
            confirmDangerousActions = this[Keys.CONFIRM_DANGEROUS]
                ?: defaults.confirmDangerousActions,
            aiProviderId = this[Keys.AI_PROVIDER] ?: Constants.PROVIDER_OFFLINE,
            localEndpoint = this[Keys.LOCAL_ENDPOINT] ?: defaults.localEndpoint,
            localModel = this[Keys.LOCAL_MODEL] ?: defaults.localModel,
            logRetentionDays = this[Keys.LOG_RETENTION] ?: defaults.logRetentionDays
        )
    }

    override suspend fun setThemeMode(mode: ThemeMode) {
        dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    override suspend fun setDynamicColor(enabled: Boolean) {
        dataStore.edit { it[Keys.DYNAMIC_COLOR] = enabled }
    }

    override suspend fun setSpokenReplies(enabled: Boolean) {
        dataStore.edit { it[Keys.SPOKEN_REPLIES] = enabled }
    }

    override suspend fun setWakeWordEnabled(enabled: Boolean) {
        dataStore.edit { it[Keys.WAKE_WORD] = enabled }
    }

    override suspend fun setSpeechRate(rate: Float) {
        dataStore.edit { it[Keys.SPEECH_RATE] = rate.coerceIn(0.5f, 2.0f) }
    }

    override suspend fun setSpeechPitch(pitch: Float) {
        dataStore.edit { it[Keys.SPEECH_PITCH] = pitch.coerceIn(0.5f, 2.0f) }
    }

    override suspend fun setConfirmDangerousActions(enabled: Boolean) {
        dataStore.edit { it[Keys.CONFIRM_DANGEROUS] = enabled }
    }

    override suspend fun setAiProvider(providerId: String) {
        dataStore.edit { it[Keys.AI_PROVIDER] = providerId }
    }

    override suspend fun setLocalEndpoint(endpoint: String) {
        dataStore.edit { it[Keys.LOCAL_ENDPOINT] = endpoint.trim() }
    }

    override suspend fun setLocalModel(model: String) {
        dataStore.edit { it[Keys.LOCAL_MODEL] = model.trim() }
    }

    override suspend fun setLogRetentionDays(days: Int) {
        dataStore.edit { it[Keys.LOG_RETENTION] = days.coerceIn(1, 365) }
    }
}
