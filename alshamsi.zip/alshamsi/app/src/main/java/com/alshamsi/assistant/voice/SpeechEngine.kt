package com.alshamsi.assistant.voice

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Wraps the free on-device text-to-speech engine already shipped with Android.
 * Arabic is selected when a voice is installed; otherwise the default voice is used.
 */
@Singleton
class SpeechEngine @Inject constructor(
    @ApplicationContext private val context: Context
) {

    private var tts: TextToSpeech? = null
    private val counter = AtomicLong(0L)

    private val _ready = MutableStateFlow(false)
    val ready: StateFlow<Boolean> = _ready.asStateFlow()

    private val _speaking = MutableStateFlow(false)
    val speaking: StateFlow<Boolean> = _speaking.asStateFlow()

    private var pendingRate = 1.0f
    private var pendingPitch = 1.0f

    fun initialize() {
        if (tts != null) return
        var engineRef: TextToSpeech? = null
        val initListener = TextToSpeech.OnInitListener { status ->
            val engine = engineRef
            if (status == TextToSpeech.SUCCESS && engine != null) {
                applyLocale(engine)
                engine.setSpeechRate(pendingRate.coerceIn(0.5f, 2.0f))
                engine.setPitch(pendingPitch.coerceIn(0.5f, 2.0f))
                _ready.value = true
            } else {
                _ready.value = false
            }
        }
        tts = TextToSpeech(context, initListener).also { engine ->
            engineRef = engine
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _speaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _speaking.value = false
                }

                @Suppress("OVERRIDE_DEPRECATION")
                override fun onError(utteranceId: String?) {
                    _speaking.value = false
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    _speaking.value = false
                }
            })
        }
    }

    private fun applyLocale(engine: TextToSpeech) {
        val candidates = listOf(
            Locale("ar", "AE"),
            Locale("ar", "SA"),
            Locale("ar"),
            Locale.getDefault()
        )
        for (locale in candidates) {
            val result = runCatching { engine.setLanguage(locale) }
                .getOrDefault(TextToSpeech.LANG_NOT_SUPPORTED)
            if (result != TextToSpeech.LANG_MISSING_DATA &&
                result != TextToSpeech.LANG_NOT_SUPPORTED
            ) {
                return
            }
        }
    }

    fun applyVoiceSettings(rate: Float, pitch: Float) {
        pendingRate = rate
        pendingPitch = pitch
        val engine = tts ?: return
        engine.setSpeechRate(rate.coerceIn(0.5f, 2.0f))
        engine.setPitch(pitch.coerceIn(0.5f, 2.0f))
    }

    fun speak(text: String, flush: Boolean = true) {
        if (text.isBlank()) return
        val engine = tts
        if (engine == null) {
            initialize()
            return
        }
        val mode = if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        val id = "alshamsi-" + counter.incrementAndGet()
        val params = Bundle()
        engine.speak(sanitize(text), mode, params, id)
    }

    fun stop() {
        runCatching { tts?.stop() }
        _speaking.value = false
    }

    fun shutdown() {
        runCatching { tts?.stop() }
        runCatching { tts?.shutdown() }
        tts = null
        _ready.value = false
        _speaking.value = false
    }

    /** Keeps spoken replies short and free of markup that the engine reads literally. */
    private fun sanitize(text: String): String {
        val cleaned = text
            .replace(Regex("[\\p{So}\\p{Cn}]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        return if (cleaned.length > 400) cleaned.take(400) + "…" else cleaned
    }
}
