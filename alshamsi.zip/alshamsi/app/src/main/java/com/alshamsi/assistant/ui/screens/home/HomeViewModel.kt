package com.alshamsi.assistant.ui.screens.home

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.alshamsi.assistant.command.CommandCoordinator
import com.alshamsi.assistant.device.control.PermissionsChecker
import com.alshamsi.assistant.domain.model.CommandSource
import com.alshamsi.assistant.domain.model.PermissionItem
import com.alshamsi.assistant.domain.repository.SettingsRepository
import com.alshamsi.assistant.voice.ListeningPhase
import com.alshamsi.assistant.voice.VoiceState
import com.alshamsi.assistant.voice.WakeWordService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@HiltViewModel
class HomeViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val permissionsChecker: PermissionsChecker,
    private val coordinator: CommandCoordinator,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _permissions = MutableStateFlow<List<PermissionItem>>(emptyList())
    val permissions: StateFlow<List<PermissionItem>> = _permissions.asStateFlow()

    private val _lastReply = MutableStateFlow("")
    val lastReply: StateFlow<String> = _lastReply.asStateFlow()

    val busy: StateFlow<Boolean> = coordinator.busy

    val listeningPhase: StateFlow<ListeningPhase> = VoiceState.phase
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ListeningPhase.IDLE)

    val serviceRunning: StateFlow<Boolean> = VoiceState.serviceRunning
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    val lastHeard: StateFlow<String> = VoiceState.lastHeard
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), "")

    init {
        refreshPermissions()
    }

    fun refreshPermissions() {
        _permissions.value = permissionsChecker.snapshot()
    }

    fun toggleListening() {
        if (VoiceState.serviceRunning.value) {
            WakeWordService.stop(context)
        } else {
            viewModelScope.launch { settingsRepository.setWakeWordEnabled(true) }
            WakeWordService.start(context)
        }
    }

    fun runQuickCommand(command: String) {
        viewModelScope.launch {
            val outcome = coordinator.handle(command, CommandSource.QUICK_ACTION)
            _lastReply.value = outcome.userMessage
            refreshPermissions()
        }
    }
}
