package com.alshamsi.assistant.device.accessibility

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Process-wide handle to the running accessibility service. The service registers itself
 * on connect and clears the reference on destroy, so injectable components can reach it
 * without holding an Android component reference themselves.
 */
object AccessibilityBridge {

    @Volatile
    private var service: ShamsiAccessibilityService? = null

    private val _connected = MutableStateFlow(false)
    val connected: StateFlow<Boolean> = _connected.asStateFlow()

    private val _foregroundPackage = MutableStateFlow("")
    val foregroundPackage: StateFlow<String> = _foregroundPackage.asStateFlow()

    fun attach(instance: ShamsiAccessibilityService) {
        service = instance
        _connected.value = true
    }

    fun detach() {
        service = null
        _connected.value = false
    }

    fun updateForegroundPackage(packageName: String) {
        _foregroundPackage.value = packageName
    }

    fun requireService(): ShamsiAccessibilityService? = service

    fun isConnected(): Boolean = service != null
}
