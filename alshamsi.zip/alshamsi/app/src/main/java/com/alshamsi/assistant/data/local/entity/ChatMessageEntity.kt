package com.alshamsi.assistant.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.alshamsi.assistant.domain.model.ChatMessage
import com.alshamsi.assistant.domain.model.CommandSource
import com.alshamsi.assistant.domain.model.MessageRole

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Long = 0L,
    @ColumnInfo(name = "content")
    val content: String,
    @ColumnInfo(name = "role")
    val role: MessageRole,
    @ColumnInfo(name = "source")
    val source: CommandSource,
    @ColumnInfo(name = "timestamp")
    val timestamp: Long
)

fun ChatMessageEntity.toDomain(): ChatMessage = ChatMessage(
    id = id,
    content = content,
    role = role,
    timestamp = timestamp,
    source = source
)

fun ChatMessage.toEntity(): ChatMessageEntity = ChatMessageEntity(
    id = id,
    content = content,
    role = role,
    source = source,
    timestamp = timestamp
)
