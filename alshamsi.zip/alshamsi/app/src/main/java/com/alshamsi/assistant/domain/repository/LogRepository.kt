package com.alshamsi.assistant.domain.repository

import com.alshamsi.assistant.domain.model.LogEntry
import kotlinx.coroutines.flow.Flow

interface LogRepository {
    fun observeLogs(limit: Int = 300): Flow<List<LogEntry>>
    suspend fun add(entry: LogEntry): Long
    suspend fun clear()
    suspend fun deleteOlderThan(timestamp: Long): Int
}
