package com.alshamsi.assistant.ui.screens.logs

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.alshamsi.assistant.domain.model.LogEntry
import com.alshamsi.assistant.domain.model.LogStatus
import com.alshamsi.assistant.ui.components.SectionCard
import com.alshamsi.assistant.ui.components.StatusPill
import java.text.SimpleDateFormat
import java.util.Locale

private val formatter = SimpleDateFormat("EEEE d MMM • hh:mm a", Locale("ar"))

@Composable
fun LogsScreen(viewModel: LogsViewModel = hiltViewModel()) {
    val logs by viewModel.logs.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "سجل العمليات", style = MaterialTheme.typography.headlineSmall)
            OutlinedButton(onClick = viewModel::clear, enabled = logs.isNotEmpty()) {
                Text(text = "مسح السجل")
            }
        }

        if (logs.isEmpty()) {
            Text(
                text = "السجل فارغ.",
                modifier = Modifier.padding(16.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(
                    horizontal = 16.dp,
                    vertical = 8.dp
                ),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(items = logs, key = { it.id }) { entry ->
                    LogCard(entry)
                }
            }
        }
    }
}

@Composable
private fun LogCard(entry: LogEntry) {
    SectionCard(title = entry.title, subtitle = formatter.format(entry.timestamp)) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusPill(
                text = statusLabel(entry.status),
                positive = entry.status == LogStatus.SUCCESS
            )
            if (entry.details.isNotBlank()) {
                Text(text = entry.details, style = MaterialTheme.typography.bodyMedium)
            }
            Text(
                text = "المصدر: " + sourceLabel(entry),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private fun statusLabel(status: LogStatus): String = when (status) {
    LogStatus.SUCCESS -> "تم بنجاح"
    LogStatus.FAILURE -> "فشل"
    LogStatus.CANCELLED -> "ملغي"
    LogStatus.PERMISSION_REQUIRED -> "يحتاج صلاحية"
}

private fun sourceLabel(entry: LogEntry): String = when (entry.source.name) {
    "VOICE" -> "أمر صوتي"
    "TEXT" -> "أمر نصي"
    "MACRO" -> "ماكرو"
    else -> "إجراء سريع"
}
