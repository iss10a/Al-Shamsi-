package com.alshamsi.assistant.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.alshamsi.assistant.data.local.dao.ChatDao
import com.alshamsi.assistant.data.local.dao.LogDao
import com.alshamsi.assistant.data.local.dao.MacroDao
import com.alshamsi.assistant.data.local.entity.ChatMessageEntity
import com.alshamsi.assistant.data.local.entity.LogEntryEntity
import com.alshamsi.assistant.data.local.entity.MacroEntity

@Database(
    entities = [
        ChatMessageEntity::class,
        LogEntryEntity::class,
        MacroEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AlshamsiDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun logDao(): LogDao
    abstract fun macroDao(): MacroDao
}
