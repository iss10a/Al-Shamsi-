package com.alshamsi.assistant.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ArabicTextTest {

    @Test
    fun `normalises hamza forms and diacritics`() {
        assertEquals("افتح الكاميرا", ArabicText.normalize("إفتَح الكاميرا"))
        assertEquals("احمد", ArabicText.normalize("أَحْمَد"))
    }

    @Test
    fun `converts arabic indic digits`() {
        assertEquals("540 1200", ArabicText.normalize("٥٤٠ ١٢٠٠"))
    }

    @Test
    fun `folds taa marbuta and alef maqsura`() {
        assertEquals("الشاشه الرئيسيه", ArabicText.normalize("الشاشة الرئيسية"))
        assertEquals("علي", ArabicText.normalize("على"))
    }

    @Test
    fun `contains any is tolerant to spelling variants`() {
        assertTrue(ArabicText.containsAny("شغّل الكشّاف الآن", listOf("الكشاف")))
    }

    @Test
    fun `extracts numbers`() {
        assertEquals(listOf(500, 1500, 500, 400), ArabicText.extractNumbers("اسحب 500 1500 500 400"))
    }
}
