package com.alshamsi.assistant.command

import com.alshamsi.assistant.domain.model.DeviceCommand
import com.alshamsi.assistant.domain.model.NavigationAction
import com.alshamsi.assistant.domain.model.SettingsSection
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CommandParserTest {

    private val parser = CommandParser()

    @Test
    fun `parses open application`() {
        val command = parser.parse("افتح الواتس")
        assertTrue(command is DeviceCommand.OpenApp)
        assertEquals("الواتس", (command as DeviceCommand.OpenApp).query)
    }

    @Test
    fun `parses flashlight on and off`() {
        assertEquals(DeviceCommand.Flashlight(true), parser.parse("شغل الكشاف"))
        assertEquals(DeviceCommand.Flashlight(false), parser.parse("اطفي الكشاف"))
    }

    @Test
    fun `parses settings section`() {
        val command = parser.parse("افتح إعدادات الواي فاي")
        assertTrue(command is DeviceCommand.OpenSettingsSection)
        assertEquals(
            SettingsSection.WIFI,
            (command as DeviceCommand.OpenSettingsSection).section
        )
    }

    @Test
    fun `parses tap with coordinates`() {
        val command = parser.parse("اضغط 540 1200")
        assertEquals(DeviceCommand.Tap(540, 1200), command)
    }

    @Test
    fun `parses delete as a dangerous command`() {
        val command = parser.parse("احذف تقرير.pdf")
        assertTrue(command is DeviceCommand.DeleteFile)
        assertTrue(command.isDangerous)
    }

    @Test
    fun `parses sequences separated by thumma`() {
        val command = parser.parse("افتح الكاميرا ثم ارجع")
        assertTrue(command is DeviceCommand.Sequence)
        val steps = (command as DeviceCommand.Sequence).commands
        assertEquals(2, steps.size)
        assertTrue(steps[0] is DeviceCommand.OpenApp || steps[0] is DeviceCommand.OpenCamera)
        assertEquals(
            DeviceCommand.GlobalNavigation(NavigationAction.BACK),
            steps[1]
        )
    }

    @Test
    fun `parses stop and confirmation words`() {
        assertEquals(DeviceCommand.StopListening, parser.parse("مع السلامة"))
        assertEquals(DeviceCommand.Affirm, parser.parse("نعم"))
        assertEquals(DeviceCommand.Deny, parser.parse("لا"))
    }

    @Test
    fun `falls back to chat`() {
        val command = parser.parse("كيف حالك اليوم")
        assertTrue(command is DeviceCommand.Chat)
    }

    @Test
    fun `parses copy with destination`() {
        val command = parser.parse("انسخ تقرير.pdf إلى Download/backup")
        assertTrue(command is DeviceCommand.CopyFile)
        val copy = command as DeviceCommand.CopyFile
        assertEquals("تقرير.pdf", copy.source)
        assertEquals("Download/backup", copy.destination)
    }
}
