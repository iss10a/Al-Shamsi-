-keepattributes Signature, InnerClasses, EnclosingMethod
-keepattributes RuntimeVisibleAnnotations, RuntimeVisibleParameterAnnotations
-keepattributes AnnotationDefault
-keepattributes SourceFile, LineNumberTable
-renamesourcefileattribute SourceFile

# ---------------- Application entry points ----------------
-keep class com.alshamsi.assistant.AlshamsiApp { *; }
-keep class com.alshamsi.assistant.MainActivity { *; }

# ---------------- Android components declared in the manifest ----------------
-keep class com.alshamsi.assistant.device.accessibility.ShamsiAccessibilityService { *; }
-keep class com.alshamsi.assistant.device.notification.ShamsiNotificationListener { *; }
-keep class com.alshamsi.assistant.voice.WakeWordService { *; }
-keep class * extends android.app.Service { *; }
-keep class * extends android.content.BroadcastReceiver { *; }
-keep class * extends android.content.ContentProvider { *; }

# ---------------- Domain / data models ----------------
-keep class com.alshamsi.assistant.domain.model.** { *; }
-keep class com.alshamsi.assistant.data.local.entity.** { *; }

# ---------------- Hilt / Dagger ----------------
-keep class dagger.hilt.** { *; }
-keep class javax.inject.** { *; }
-keep class * extends dagger.hilt.android.internal.managers.ViewComponentManager$FragmentContextWrapper { *; }
-dontwarn dagger.internal.codegen.**

# ---------------- Room ----------------
-keep class androidx.room.** { *; }
-keep class * extends androidx.room.RoomDatabase { *; }
-dontwarn androidx.room.paging.**

# ---------------- WorkManager ----------------
-keep class * extends androidx.work.Worker { *; }
-keep class * extends androidx.work.ListenableWorker { *; }
-keep class androidx.work.impl.** { *; }

# ---------------- Kotlin / Coroutines ----------------
-keepclassmembers class kotlin.Metadata { public <methods>; }
-dontwarn kotlinx.coroutines.**
-keepclassmembernames class kotlinx.** { volatile <fields>; }

# ---------------- Compose ----------------
-keep class androidx.compose.runtime.** { *; }
-dontwarn androidx.compose.**

# ---------------- OkHttp / Okio ----------------
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
-dontwarn javax.annotation.**
-keepnames class okhttp3.internal.publicsuffix.PublicSuffixDatabase

# ---------------- Misc ----------------
-dontwarn java.lang.invoke.**
-dontwarn org.codehaus.mojo.animal_sniffer.**
