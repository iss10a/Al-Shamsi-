package com.essa.iptvloader.ui.screens.movies

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FilterAltOff
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.essa.iptvloader.core.Formatters
import com.essa.iptvloader.domain.model.LanguageFilter
import com.essa.iptvloader.domain.model.Movie
import com.essa.iptvloader.domain.model.QualityFilter
import com.essa.iptvloader.domain.model.SortMode
import com.essa.iptvloader.ui.components.FeaturedBanner
import com.essa.iptvloader.ui.components.PosterCard
import com.essa.iptvloader.ui.components.RatingLine
import com.essa.iptvloader.ui.components.SectionShelf

@Composable
fun MoviesScreen(viewModel: MoviesViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var selected by remember { mutableStateOf<Movie?>(null) }

    LaunchedEffect(state.enqueuedName) {
        if (state.enqueuedName != null) {
            kotlinx.coroutines.delay(2500)
            viewModel.consumeEnqueued()
        }
    }
    LaunchedEffect(state.statusMessage, state.loading) {
        if (!state.loading && state.statusMessage != null) {
            kotlinx.coroutines.delay(2000)
            viewModel.consumeStatusMessage()
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        SearchAndFilters(
            query = state.query,
            sort = state.sort,
            quality = state.quality,
            language = state.language,
            filtersActive = state.gridActive,
            onQuery = viewModel::onQuery,
            onSort = viewModel::onSort,
            onQuality = viewModel::onQuality,
            onLanguage = viewModel::onLanguage,
            onClear = viewModel::clearFilters,
            onRefresh = viewModel::refresh
        )

        when {
            state.loading -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Text(
                        text = state.statusMessage ?: "جاري تحديث المحتوى...",
                        modifier = Modifier.padding(top = 10.dp),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            state.error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = state.error!!, color = MaterialTheme.colorScheme.error)
                    TextButton(onClick = viewModel::refresh) { Text(text = "إعادة المحاولة") }
                }
            }
            state.gridActive && state.showCategoryRecent -> MoviesCategoryGrid(
                recent = state.categoryRecent,
                rest = state.gridItems,
                onOpen = { selected = it }
            )
            state.gridActive -> MoviesGrid(
                movies = state.gridItems,
                onOpen = { selected = it }
            )
            else -> MoviesHome(
                state = state,
                onOpen = { selected = it },
                onViewAllCategory = viewModel::browseSection
            )
        }

        if (state.enqueuedName != null) {
            Snackbar(modifier = Modifier.padding(8.dp)) {
                Text(text = "أُضيف للتحميل: " + state.enqueuedName)
            }
        } else if (!state.loading && state.statusMessage != null) {
            Snackbar(modifier = Modifier.padding(8.dp)) {
                Text(text = state.statusMessage!!)
            }
        }
    }

    val movie = selected
    if (movie != null) {
        MovieDialog(
            movie = movie,
            categoryName = viewModel.categoryName(movie),
            onDownload = {
                viewModel.download(movie)
                selected = null
            },
            onDismiss = { selected = null }
        )
    }
}

@Composable
private fun MoviesHome(
    state: MoviesUiState,
    onOpen: (Movie) -> Unit,
    onViewAllCategory: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        val featured = state.featured
        if (featured != null) {
            item(key = "featured") {
                FeaturedBanner(
                    title = featured.name,
                    imageUrl = featured.icon,
                    infoLine = listOfNotNull(
                        featured.year,
                        Formatters.detectQuality(featured.name)
                    ).joinToString("  •  ").ifBlank { null },
                    actionLabel = "عرض وتحميل ⬇",
                    onAction = { onOpen(featured) }
                )
            }
        }
        state.sections.forEach { section ->
            item(key = "section-" + section.title) {
                SectionShelf(
                    title = section.title,
                    items = section.items,
                    key = { it.streamId },
                    onViewAll = { onViewAllCategory(section.title) }
                ) { movie ->
                    PosterCard(
                        title = movie.name,
                        imageUrl = movie.icon,
                        subtitle = movie.year,
                        badge = Formatters.detectQuality(movie.name),
                        onClick = { onOpen(movie) }
                    )
                }
            }
        }
    }
}

@Composable
private fun MoviesGrid(movies: List<Movie>, onOpen: (Movie) -> Unit) {
    if (movies.isEmpty()) {
        Box(Modifier.fillMaxSize(), Alignment.Center) {
            Text(text = "لا توجد نتائج.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        return
    }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 116.dp),
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(12.dp)
    ) {
        items(count = movies.size, key = { index -> movies[index].streamId }) { index ->
            val movie = movies[index]
            PosterCard(
                title = movie.name,
                imageUrl = movie.icon,
                subtitle = movie.year,
                badge = Formatters.detectQuality(movie.name),
                onClick = { onOpen(movie) }
            )
        }
    }
}

/**
 * Category browse view: a dynamic "أضيف حديثاً" shelf (server add-order, newest first)
 * followed by the rest of the category in the usual grid — rebuilt every time content
 * is refreshed, never a fixed list.
 */
@Composable
private fun MoviesCategoryGrid(
    recent: List<Movie>,
    rest: List<Movie>,
    onOpen: (Movie) -> Unit
) {
    if (recent.isEmpty() && rest.isEmpty()) {
        Box(Modifier.fillMaxSize(), Alignment.Center) {
            Text(text = "لا توجد نتائج.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        return
    }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 116.dp),
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(12.dp)
    ) {
        if (recent.isNotEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }, key = "category-recent-shelf") {
                SectionShelf(
                    title = "أضيف حديثاً",
                    items = recent,
                    key = { it.streamId },
                    onViewAll = null
                ) { movie ->
                    PosterCard(
                        title = movie.name,
                        imageUrl = movie.icon,
                        subtitle = movie.year,
                        badge = Formatters.detectQuality(movie.name),
                        onClick = { onOpen(movie) }
                    )
                }
            }
        }
        items(count = rest.size, key = { index -> rest[index].streamId }) { index ->
            val movie = rest[index]
            PosterCard(
                title = movie.name,
                imageUrl = movie.icon,
                subtitle = movie.year,
                badge = Formatters.detectQuality(movie.name),
                onClick = { onOpen(movie) }
            )
        }
    }
}

@Composable
private fun SearchAndFilters(
    query: String,
    sort: SortMode,
    quality: QualityFilter,
    language: LanguageFilter,
    filtersActive: Boolean,
    onQuery: (String) -> Unit,
    onSort: (SortMode) -> Unit,
    onQuality: (QualityFilter) -> Unit,
    onLanguage: (LanguageFilter) -> Unit,
    onClear: () -> Unit,
    onRefresh: () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = onQuery,
                label = { Text(text = "ابحث عن فيلم…") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onRefresh) {
                Icon(imageVector = Icons.Filled.Refresh, contentDescription = "تحديث المحتوى")
            }
            if (filtersActive) {
                IconButton(onClick = onClear) {
                    Icon(imageVector = Icons.Filled.FilterAltOff, contentDescription = "مسح الفلاتر")
                }
            }
        }
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            items(count = SortMode.entries.size, key = { i -> "sort-" + SortMode.entries[i].name }) { i ->
                val mode = SortMode.entries[i]
                FilterChip(
                    selected = sort == mode,
                    onClick = { onSort(mode) },
                    label = { Text(text = mode.label) }
                )
            }
            items(count = QualityFilter.entries.size, key = { i -> "q-" + QualityFilter.entries[i].name }) { i ->
                val q = QualityFilter.entries[i]
                FilterChip(
                    selected = quality == q,
                    onClick = { onQuality(q) },
                    label = { Text(text = q.label) }
                )
            }
            items(count = LanguageFilter.entries.size, key = { i -> "l-" + LanguageFilter.entries[i].name }) { i ->
                val l = LanguageFilter.entries[i]
                FilterChip(
                    selected = language == l,
                    onClick = { onLanguage(l) },
                    label = { Text(text = l.label) }
                )
            }
        }
    }
}

@Composable
private fun MovieDialog(
    movie: Movie,
    categoryName: String?,
    onDownload: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = movie.name) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                coil.compose.AsyncImage(
                    model = movie.icon,
                    contentDescription = null,
                    modifier = Modifier.fillMaxWidth().height(200.dp)
                )
                RatingLine(rating = movie.rating, year = movie.year)
                val quality = Formatters.detectQuality(movie.name)
                if (quality != null) Text(text = "الجودة: " + quality)
                if (categoryName != null) Text(text = "التصنيف: " + categoryName)
                Text(
                    text = "سيُحفظ في Download/Movies بنفس اسم السيرفر.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(onClick = onDownload) { Text(text = "⬇ تحميل") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(text = "إلغاء") }
        }
    )
}
