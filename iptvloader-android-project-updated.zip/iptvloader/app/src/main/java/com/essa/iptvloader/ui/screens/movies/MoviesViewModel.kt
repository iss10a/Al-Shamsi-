package com.essa.iptvloader.ui.screens.movies

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.essa.iptvloader.core.Constants
import com.essa.iptvloader.core.Formatters
import com.essa.iptvloader.data.remote.ApiResult
import com.essa.iptvloader.data.repository.ContentRepository
import com.essa.iptvloader.domain.model.Category
import com.essa.iptvloader.domain.model.ContentKind
import com.essa.iptvloader.domain.model.LanguageFilter
import com.essa.iptvloader.domain.model.Movie
import com.essa.iptvloader.domain.model.MovieSection
import com.essa.iptvloader.domain.model.QualityFilter
import com.essa.iptvloader.domain.model.SortMode
import com.essa.iptvloader.download.DownloadManager
import com.essa.iptvloader.download.DownloadService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class MoviesUiState(
    val loading: Boolean = false,
    val error: String? = null,
    val query: String = "",
    val sort: SortMode = SortMode.DEFAULT,
    val quality: QualityFilter = QualityFilter.ALL,
    val language: LanguageFilter = LanguageFilter.ALL,
    val browseCategory: Category? = null,
    val browseSection: String? = null,
    val featured: Movie? = null,
    val sections: List<MovieSection> = emptyList(),
    val gridItems: List<Movie> = emptyList(),
    val gridActive: Boolean = false,
    val showCategoryRecent: Boolean = false,
    val categoryRecent: List<Movie> = emptyList(),
    val enqueuedName: String? = null,
    val statusMessage: String? = null
)

@HiltViewModel
class MoviesViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: ContentRepository,
    private val downloadManager: DownloadManager
) : ViewModel() {

    private val _state = MutableStateFlow(MoviesUiState())
    val state: StateFlow<MoviesUiState> = _state.asStateFlow()

    private var all: List<Movie> = emptyList()
    private var categories: Map<String, Category> = emptyMap()
    private var categoryOrder: List<Category> = emptyList()

    init { refresh() }

    fun refresh() {
        _state.value = _state.value.copy(
            loading = true, error = null, statusMessage = "جاري تحديث المحتوى..."
        )
        viewModelScope.launch {
            try {
                val catsResult = repository.movieCategories()
                if (catsResult is ApiResult.Ok) {
                    categoryOrder = catsResult.data
                    categories = catsResult.data.associateBy { it.id }
                }
                // Re-fetch replaces `all` wholesale each time (keyed by streamId), so a
                // repeated tap on "تحديث المحتوى" never creates duplicate entries — it just
                // brings in newly added items and refreshes existing ones in place.
                when (val result = repository.movies()) {
                    is ApiResult.Ok -> {
                        all = result.data.distinctBy { it.streamId }
                        recompute(loading = false)
                        _state.value = _state.value.copy(statusMessage = "تم تحديث المحتوى بنجاح")
                    }
                    is ApiResult.Error ->
                        _state.value = _state.value.copy(
                            loading = false, error = result.message, statusMessage = null
                        )
                }
            } catch (throwable: Throwable) {
                _state.value = _state.value.copy(
                    loading = false,
                    error = "خطأ غير متوقع: " + (throwable.message ?: throwable.javaClass.simpleName),
                    statusMessage = null
                )
            }
        }
    }

    fun consumeStatusMessage() { _state.value = _state.value.copy(statusMessage = null) }

    fun onQuery(value: String) { _state.value = _state.value.copy(query = value); recompute() }
    fun onSort(value: SortMode) { _state.value = _state.value.copy(sort = value); recompute() }
    fun onQuality(value: QualityFilter) { _state.value = _state.value.copy(quality = value); recompute() }
    fun onLanguage(value: LanguageFilter) { _state.value = _state.value.copy(language = value); recompute() }
    fun browseCategory(category: Category?) {
        _state.value = _state.value.copy(browseCategory = category); recompute()
    }

    /** Opens the full contents of a home shelf (derived or server category) as a grid. */
    fun browseSection(title: String) {
        val cat = categoryOrder.firstOrNull { it.name == title }
        if (cat != null) {
            _state.value = _state.value.copy(browseCategory = cat, browseSection = null)
        } else {
            _state.value = _state.value.copy(browseSection = title, browseCategory = null)
        }
        recompute()
    }
    fun clearFilters() {
        _state.value = _state.value.copy(
            query = "", sort = SortMode.DEFAULT, quality = QualityFilter.ALL,
            language = LanguageFilter.ALL, browseCategory = null, browseSection = null
        )
        recompute()
    }
    fun consumeEnqueued() { _state.value = _state.value.copy(enqueuedName = null) }

    fun download(movie: Movie) {
        viewModelScope.launch {
            try {
                val url = repository.movieUrl(movie)
                val displayName = buildName(movie)
                downloadManager.enqueue(
                    url, displayName + "." + movie.extension, Constants.MOVIES_DIR, ContentKind.MOVIE
                )
                DownloadService.start(context)
                _state.value = _state.value.copy(enqueuedName = displayName)
            } catch (throwable: Throwable) {
                _state.value = _state.value.copy(
                    error = "تعذر إضافة التحميل: " + (throwable.message ?: "")
                )
            }
        }
    }

    fun categoryName(movie: Movie): String? = movie.categoryId?.let { categories[it]?.name }

    private fun buildName(movie: Movie): String {
        val year = movie.year?.takeIf { it.isNotBlank() }
        return if (year != null && !movie.name.contains(year)) {
            movie.name + " (" + year + ")"
        } else movie.name
    }

    private fun matchesKeywords(movie: Movie, keywords: List<String>): Boolean {
        if (keywords.isEmpty()) return true
        val haystack = (movie.name + " " + (categoryName(movie) ?: "")).uppercase()
        return keywords.any { haystack.contains(it.uppercase()) }
    }

    private fun recompute(loading: Boolean = _state.value.loading) {
        val s = _state.value
        val gridActive = s.query.isNotBlank() || s.sort != SortMode.DEFAULT ||
            s.quality != QualityFilter.ALL || s.language != LanguageFilter.ALL ||
            s.browseCategory != null || s.browseSection != null

        if (!gridActive) {
            val byAdded = all.sortedByDescending { it.added }
            val byRating = all.filter { it.rating > 0 }.sortedByDescending { it.rating }
            val sections = buildList {
                add(MovieSection("المضافة حديثاً", byAdded.take(20)))
                add(MovieSection("الأعلى تقييماً", byRating.take(20)))
                add(MovieSection("أفلام 2026", all.filter { it.year == "2026" }.take(30)))
                // Per-category shelves follow the server's own add order too (newest first),
                // not the raw listing order the API happens to return.
                for (cat in categoryOrder) {
                    val items = all.filter { it.categoryId == cat.id }.sortedByDescending { it.added }
                    if (items.isNotEmpty()) add(MovieSection(cat.name, items.take(30)))
                }
            }.filter { it.items.isNotEmpty() }
            val featured = byRating.firstOrNull { it.icon != null }
                ?: byAdded.firstOrNull { it.icon != null } ?: all.firstOrNull()
            _state.value = s.copy(
                loading = loading, gridActive = false, featured = featured,
                sections = sections, gridItems = emptyList(),
                showCategoryRecent = false, categoryRecent = emptyList()
            )
            return
        }

        var items = all.asSequence()
        s.browseCategory?.let { cat -> items = items.filter { it.categoryId == cat.id } }
        when (s.browseSection) {
            "المضافة حديثاً" -> items = items.sortedByDescending { it.added }
            "الأعلى تقييماً" -> items = items.filter { it.rating > 0 }.sortedByDescending { it.rating }
            "أفلام 2026" -> items = items.filter { it.year == "2026" }
        }
        if (s.query.isNotBlank()) {
            val q = s.query.trim()
            items = items.filter { it.name.contains(q, ignoreCase = true) }
        }
        if (s.quality != QualityFilter.ALL) {
            items = items.filter { movie ->
                s.quality.keywords.any { movie.name.uppercase().contains(it) }
            }
        }
        if (s.language != LanguageFilter.ALL) {
            items = items.filter { matchesKeywords(it, s.language.keywords) }
        }

        // Browsing a real server category (e.g. "تركي") with no extra filter applied: show a
        // dedicated "أضيف حديثاً" shelf, in true server add-order, ahead of the rest of the
        // category — rebuilt fresh every time content is fetched, never a fixed/static list.
        val plainCategoryBrowse = s.browseCategory != null && s.browseSection == null &&
            s.query.isBlank() && s.quality == QualityFilter.ALL && s.language == LanguageFilter.ALL &&
            s.sort == SortMode.DEFAULT

        if (plainCategoryBrowse) {
            val categorySorted = items.sortedByDescending { it.added }.toList()
            val recent = categorySorted.take(RECENT_SHELF_SIZE)
            val recentIds = recent.map { it.streamId }.toSet()
            val rest = categorySorted.filter { it.streamId !in recentIds }
            _state.value = s.copy(
                loading = loading, gridActive = true,
                showCategoryRecent = recent.isNotEmpty(),
                categoryRecent = recent, gridItems = rest
            )
            return
        }

        val sorted = when (s.sort) {
            SortMode.NAME -> items.sortedBy { it.name.lowercase() }
            SortMode.NEWEST -> items.sortedByDescending { it.added }
            SortMode.YEAR -> items.sortedByDescending { it.year?.toIntOrNull() ?: 0 }
            // Default order relies on the server's own add order (newest first), never a
            // random/alphabetical fallback and never the movie's release year.
            SortMode.DEFAULT -> items.sortedByDescending { it.added }
        }
        _state.value = s.copy(
            loading = loading, gridActive = true, gridItems = sorted.toList(),
            showCategoryRecent = false, categoryRecent = emptyList()
        )
    }

    private companion object {
        const val RECENT_SHELF_SIZE = 20
    }
}
