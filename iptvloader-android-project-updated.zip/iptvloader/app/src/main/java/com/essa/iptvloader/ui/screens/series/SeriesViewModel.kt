package com.essa.iptvloader.ui.screens.series

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.essa.iptvloader.core.Constants
import com.essa.iptvloader.core.Formatters
import com.essa.iptvloader.data.remote.ApiResult
import com.essa.iptvloader.data.repository.ContentRepository
import com.essa.iptvloader.domain.model.Category
import com.essa.iptvloader.domain.model.ContentKind
import com.essa.iptvloader.domain.model.Episode
import com.essa.iptvloader.domain.model.LanguageFilter
import com.essa.iptvloader.domain.model.QualityFilter
import com.essa.iptvloader.domain.model.SeasonGroup
import com.essa.iptvloader.domain.model.Series
import com.essa.iptvloader.domain.model.SeriesDetail
import com.essa.iptvloader.domain.model.SeriesSection
import com.essa.iptvloader.domain.model.SortMode
import com.essa.iptvloader.download.DownloadManager
import com.essa.iptvloader.download.DownloadService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class SeriesUiState(
    val loading: Boolean = false,
    val error: String? = null,
    val query: String = "",
    val sort: SortMode = SortMode.DEFAULT,
    val quality: QualityFilter = QualityFilter.ALL,
    val language: LanguageFilter = LanguageFilter.ALL,
    val browseCategory: Category? = null,
    val browseSection: String? = null,
    val featured: Series? = null,
    val sections: List<SeriesSection> = emptyList(),
    val gridItems: List<Series> = emptyList(),
    val gridActive: Boolean = false,
    val showCategoryRecent: Boolean = false,
    val categoryRecent: List<Series> = emptyList(),
    val detailLoading: Boolean = false,
    val detail: SeriesDetail? = null,
    val enqueuedName: String? = null,
    val statusMessage: String? = null
)

@HiltViewModel
class SeriesViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: ContentRepository,
    private val downloadManager: DownloadManager
) : ViewModel() {

    private val _state = MutableStateFlow(SeriesUiState())
    val state: StateFlow<SeriesUiState> = _state.asStateFlow()

    private var all: List<Series> = emptyList()
    private var categories: Map<String, Category> = emptyMap()
    private var categoryOrder: List<Category> = emptyList()

    init { refresh() }

    fun refresh() {
        _state.value = _state.value.copy(
            loading = true, error = null, statusMessage = "جاري تحديث المحتوى..."
        )
        viewModelScope.launch {
            try {
                val catsResult = repository.seriesCategories()
                if (catsResult is ApiResult.Ok) {
                    categoryOrder = catsResult.data
                    categories = catsResult.data.associateBy { it.id }
                }
                // Re-fetch replaces `all` wholesale each time (keyed by seriesId), so a
                // repeated tap on "تحديث المحتوى" never creates duplicate series — it just
                // brings in newly added series/seasons/episodes and refreshes existing ones.
                when (val result = repository.series()) {
                    is ApiResult.Ok -> {
                        all = result.data.distinctBy { it.seriesId }
                        recompute(loading = false)
                        _state.value = _state.value.copy(statusMessage = "تم تحديث المحتوى بنجاح")
                    }
                    is ApiResult.Error ->
                        _state.value = _state.value.copy(
                            loading = false, error = result.message, statusMessage = null
                        )
                }
            } catch (throwable: Throwable) {
                _state.value = _state.value.copy(
                    loading = false,
                    error = "خطأ غير متوقع: " + (throwable.message ?: throwable.javaClass.simpleName),
                    statusMessage = null
                )
            }
        }
    }

    fun consumeStatusMessage() { _state.value = _state.value.copy(statusMessage = null) }

    fun onQuery(value: String) { _state.value = _state.value.copy(query = value); recompute() }
    fun onSort(value: SortMode) { _state.value = _state.value.copy(sort = value); recompute() }
    fun onQuality(value: QualityFilter) { _state.value = _state.value.copy(quality = value); recompute() }
    fun onLanguage(value: LanguageFilter) { _state.value = _state.value.copy(language = value); recompute() }

    fun browseSection(title: String) {
        val cat = categoryOrder.firstOrNull { it.name == title }
        if (cat != null) {
            _state.value = _state.value.copy(browseCategory = cat, browseSection = null)
        } else {
            _state.value = _state.value.copy(browseSection = title, browseCategory = null)
        }
        recompute()
    }

    fun clearFilters() {
        _state.value = _state.value.copy(
            query = "", sort = SortMode.DEFAULT, quality = QualityFilter.ALL,
            language = LanguageFilter.ALL, browseCategory = null, browseSection = null
        )
        recompute()
    }

    fun consumeEnqueued() { _state.value = _state.value.copy(enqueuedName = null) }

    fun openSeries(series: Series) {
        _state.value = _state.value.copy(detailLoading = true, detail = null, error = null)
        viewModelScope.launch {
            try {
                when (val result = repository.seriesInfo(series)) {
                    is ApiResult.Ok ->
                        _state.value = _state.value.copy(detailLoading = false, detail = result.data)
                    is ApiResult.Error ->
                        _state.value = _state.value.copy(detailLoading = false, error = result.message)
                }
            } catch (throwable: Throwable) {
                _state.value = _state.value.copy(
                    detailLoading = false,
                    error = "خطأ غير متوقع: " + (throwable.message ?: throwable.javaClass.simpleName)
                )
            }
        }
    }

    fun closeDetail() { _state.value = _state.value.copy(detail = null) }

    fun downloadEpisode(episode: Episode) {
        viewModelScope.launch {
            enqueueEpisode(episode)
            DownloadService.start(context)
            _state.value = _state.value.copy(enqueuedName = episode.title)
        }
    }

    fun downloadSeason(season: SeasonGroup) {
        viewModelScope.launch {
            season.episodes.forEach { enqueueEpisode(it) }
            DownloadService.start(context)
            _state.value = _state.value.copy(
                enqueuedName = "الموسم " + season.season + " (" + season.episodes.size + " حلقة)"
            )
        }
    }

    fun categoryName(series: Series): String? = series.categoryId?.let { categories[it]?.name }

    private suspend fun enqueueEpisode(episode: Episode) {
        try {
            val url = repository.episodeUrl(episode)
            val seriesName = _state.value.detail?.series?.name.orEmpty()
            val subDir = Constants.SERIES_DIR + "/" +
                Formatters.safeFileName(seriesName.ifBlank { "Series" })
            downloadManager.enqueue(
                url = url,
                fileName = episode.title + "." + episode.extension,
                subDir = subDir,
                kind = ContentKind.SERIES,
                groupKey = subDir
            )
        } catch (throwable: Throwable) {
            _state.value = _state.value.copy(
                error = "تعذر إضافة التحميل: " + (throwable.message ?: "")
            )
        }
    }

    private fun matchesKeywords(series: Series, keywords: List<String>): Boolean {
        if (keywords.isEmpty()) return true
        val haystack = (series.name + " " + (categoryName(series) ?: "")).uppercase()
        return keywords.any { haystack.contains(it.uppercase()) }
    }

    private fun recompute(loading: Boolean = _state.value.loading) {
        val s = _state.value
        val gridActive = s.query.isNotBlank() || s.sort != SortMode.DEFAULT ||
            s.quality != QualityFilter.ALL || s.language != LanguageFilter.ALL ||
            s.browseCategory != null || s.browseSection != null

        if (!gridActive) {
            val byAdded = all.sortedByDescending { it.added }
            val byRating = all.filter { it.rating > 0 }.sortedByDescending { it.rating }
            val sections = buildList {
                add(SeriesSection("المضافة حديثاً", byAdded.take(20)))
                add(SeriesSection("الأعلى تقييماً", byRating.take(20)))
                add(SeriesSection("مسلسلات 2026", all.filter { it.year == "2026" }.take(30)))
                // Per-category shelves follow the server's own add order too (newest first),
                // not the raw listing order the API happens to return.
                for (cat in categoryOrder) {
                    val items = all.filter { it.categoryId == cat.id }.sortedByDescending { it.added }
                    if (items.isNotEmpty()) add(SeriesSection(cat.name, items.take(30)))
                }
            }.filter { it.items.isNotEmpty() }
            val featured = byRating.firstOrNull { it.cover != null }
                ?: byAdded.firstOrNull { it.cover != null } ?: all.firstOrNull()
            _state.value = s.copy(
                loading = loading, gridActive = false, featured = featured,
                sections = sections, gridItems = emptyList(),
                showCategoryRecent = false, categoryRecent = emptyList()
            )
            return
        }

        var items = all.asSequence()
        s.browseCategory?.let { cat -> items = items.filter { it.categoryId == cat.id } }
        when (s.browseSection) {
            "المضافة حديثاً" -> items = items.sortedByDescending { it.added }
            "الأعلى تقييماً" -> items = items.filter { it.rating > 0 }.sortedByDescending { it.rating }
            "مسلسلات 2026" -> items = items.filter { it.year == "2026" }
        }
        if (s.query.isNotBlank()) {
            val q = s.query.trim()
            items = items.filter { it.name.contains(q, ignoreCase = true) }
        }
        if (s.quality != QualityFilter.ALL) {
            items = items.filter { series ->
                s.quality.keywords.any { series.name.uppercase().contains(it) }
            }
        }
        if (s.language != LanguageFilter.ALL) {
            items = items.filter { matchesKeywords(it, s.language.keywords) }
        }

        // Browsing a real server category (e.g. "تركي") with no extra filter applied: show a
        // dedicated "أضيف حديثاً" shelf, in true server add-order, ahead of the rest of the
        // category — rebuilt fresh every time content is fetched, never a fixed/static list.
        val plainCategoryBrowse = s.browseCategory != null && s.browseSection == null &&
            s.query.isBlank() && s.quality == QualityFilter.ALL && s.language == LanguageFilter.ALL &&
            s.sort == SortMode.DEFAULT

        if (plainCategoryBrowse) {
            val categorySorted = items.sortedByDescending { it.added }.toList()
            val recent = categorySorted.take(RECENT_SHELF_SIZE)
            val recentIds = recent.map { it.seriesId }.toSet()
            val rest = categorySorted.filter { it.seriesId !in recentIds }
            _state.value = s.copy(
                loading = loading, gridActive = true,
                showCategoryRecent = recent.isNotEmpty(),
                categoryRecent = recent, gridItems = rest
            )
            return
        }

        val sorted = when (s.sort) {
            SortMode.NAME -> items.sortedBy { it.name.lowercase() }
            SortMode.NEWEST -> items.sortedByDescending { it.added }
            SortMode.YEAR -> items.sortedByDescending { it.year?.toIntOrNull() ?: 0 }
            // Default order relies on the server's own add order (newest first), never a
            // random/alphabetical fallback and never the series' release year.
            SortMode.DEFAULT -> items.sortedByDescending { it.added }
        }
        _state.value = s.copy(
            loading = loading, gridActive = true, gridItems = sorted.toList(),
            showCategoryRecent = false, categoryRecent = emptyList()
        )
    }

    private companion object {
        const val RECENT_SHELF_SIZE = 20
    }
}
