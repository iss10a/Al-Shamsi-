package com.essa.iptvloader.ui.screens.series

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FilterAltOff
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.essa.iptvloader.core.Formatters
import com.essa.iptvloader.domain.model.LanguageFilter
import com.essa.iptvloader.domain.model.QualityFilter
import com.essa.iptvloader.domain.model.SeasonGroup
import com.essa.iptvloader.domain.model.Series
import com.essa.iptvloader.domain.model.SeriesDetail
import com.essa.iptvloader.domain.model.SortMode
import com.essa.iptvloader.ui.components.FeaturedBanner
import com.essa.iptvloader.ui.components.PosterCard
import com.essa.iptvloader.ui.components.RatingLine
import com.essa.iptvloader.ui.components.SectionShelf

@Composable
fun SeriesScreen(viewModel: SeriesViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    LaunchedEffect(state.enqueuedName) {
        if (state.enqueuedName != null) {
            kotlinx.coroutines.delay(2500)
            viewModel.consumeEnqueued()
        }
    }
    LaunchedEffect(state.statusMessage, state.loading) {
        if (!state.loading && state.statusMessage != null) {
            kotlinx.coroutines.delay(2000)
            viewModel.consumeStatusMessage()
        }
    }

    val detail = state.detail
    if (detail != null || state.detailLoading) {
        if (state.detailLoading) {
            Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        } else if (detail != null) {
            SeriesDetailView(
                detail = detail,
                categoryName = viewModel.categoryName(detail.series),
                enqueuedName = state.enqueuedName,
                onBack = viewModel::closeDetail,
                onEpisode = viewModel::downloadEpisode,
                onSeason = viewModel::downloadSeason
            )
        }
        return
    }

    Column(modifier = Modifier.fillMaxSize()) {
        SearchAndFilters(
            query = state.query,
            sort = state.sort,
            quality = state.quality,
            language = state.language,
            filtersActive = state.gridActive,
            onQuery = viewModel::onQuery,
            onSort = viewModel::onSort,
            onQuality = viewModel::onQuality,
            onLanguage = viewModel::onLanguage,
            onClear = viewModel::clearFilters,
            onRefresh = viewModel::refresh
        )

        when {
            state.loading -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Text(
                        text = state.statusMessage ?: "جاري تحديث المحتوى...",
                        modifier = Modifier.padding(top = 10.dp),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            state.error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = state.error!!, color = MaterialTheme.colorScheme.error)
                    TextButton(onClick = viewModel::refresh) { Text(text = "إعادة المحاولة") }
                }
            }
            state.gridActive && state.showCategoryRecent -> SeriesCategoryGrid(
                recent = state.categoryRecent,
                rest = state.gridItems,
                onOpen = viewModel::openSeries
            )
            state.gridActive -> SeriesGrid(items = state.gridItems, onOpen = viewModel::openSeries)
            else -> SeriesHome(
                state = state,
                onOpen = viewModel::openSeries,
                onViewAll = viewModel::browseSection
            )
        }

        if (state.enqueuedName != null) {
            Snackbar(modifier = Modifier.padding(8.dp)) {
                Text(text = "أُضيف للتحميل: " + state.enqueuedName)
            }
        } else if (!state.loading && state.statusMessage != null) {
            Snackbar(modifier = Modifier.padding(8.dp)) {
                Text(text = state.statusMessage!!)
            }
        }
    }
}

@Composable
private fun SeriesHome(
    state: SeriesUiState,
    onOpen: (Series) -> Unit,
    onViewAll: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        val featured = state.featured
        if (featured != null) {
            item(key = "featured") {
                FeaturedBanner(
                    title = featured.name,
                    imageUrl = featured.cover,
                    infoLine = featured.year,
                    actionLabel = "عرض المواسم ⬇",
                    onAction = { onOpen(featured) }
                )
            }
        }
        state.sections.forEach { section ->
            item(key = "section-" + section.title) {
                SectionShelf(
                    title = section.title,
                    items = section.items,
                    key = { it.seriesId },
                    onViewAll = { onViewAll(section.title) }
                ) { series ->
                    PosterCard(
                        title = series.name,
                        imageUrl = series.cover,
                        subtitle = series.year,
                        badge = Formatters.detectQuality(series.name),
                        onClick = { onOpen(series) }
                    )
                }
            }
        }
    }
}

@Composable
private fun SeriesGrid(items: List<Series>, onOpen: (Series) -> Unit) {
    if (items.isEmpty()) {
        Box(Modifier.fillMaxSize(), Alignment.Center) {
            Text(text = "لا توجد نتائج.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        return
    }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 116.dp),
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(12.dp)
    ) {
        items(count = items.size, key = { index -> items[index].seriesId }) { index ->
            val series = items[index]
            PosterCard(
                title = series.name,
                imageUrl = series.cover,
                subtitle = series.year,
                badge = Formatters.detectQuality(series.name),
                onClick = { onOpen(series) }
            )
        }
    }
}

/**
 * Category browse view: a dynamic "أضيف حديثاً" shelf (server add-order, newest first)
 * followed by the rest of the category in the usual grid — rebuilt every time content
 * is refreshed, never a fixed list.
 */
@Composable
private fun SeriesCategoryGrid(
    recent: List<Series>,
    rest: List<Series>,
    onOpen: (Series) -> Unit
) {
    if (recent.isEmpty() && rest.isEmpty()) {
        Box(Modifier.fillMaxSize(), Alignment.Center) {
            Text(text = "لا توجد نتائج.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        return
    }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 116.dp),
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(12.dp)
    ) {
        if (recent.isNotEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }, key = "category-recent-shelf") {
                SectionShelf(
                    title = "أضيف حديثاً",
                    items = recent,
                    key = { it.seriesId },
                    onViewAll = null
                ) { series ->
                    PosterCard(
                        title = series.name,
                        imageUrl = series.cover,
                        subtitle = series.year,
                        badge = Formatters.detectQuality(series.name),
                        onClick = { onOpen(series) }
                    )
                }
            }
        }
        items(count = rest.size, key = { index -> rest[index].seriesId }) { index ->
            val series = rest[index]
            PosterCard(
                title = series.name,
                imageUrl = series.cover,
                subtitle = series.year,
                badge = Formatters.detectQuality(series.name),
                onClick = { onOpen(series) }
            )
        }
    }
}

@Composable
private fun SearchAndFilters(
    query: String,
    sort: SortMode,
    quality: QualityFilter,
    language: LanguageFilter,
    filtersActive: Boolean,
    onQuery: (String) -> Unit,
    onSort: (SortMode) -> Unit,
    onQuality: (QualityFilter) -> Unit,
    onLanguage: (LanguageFilter) -> Unit,
    onClear: () -> Unit,
    onRefresh: () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = onQuery,
                label = { Text(text = "ابحث عن مسلسل…") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onRefresh) {
                Icon(imageVector = Icons.Filled.Refresh, contentDescription = "تحديث المحتوى")
            }
            if (filtersActive) {
                IconButton(onClick = onClear) {
                    Icon(imageVector = Icons.Filled.FilterAltOff, contentDescription = "مسح الفلاتر")
                }
            }
        }
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            items(count = SortMode.entries.size, key = { i -> "sort-" + SortMode.entries[i].name }) { i ->
                val mode = SortMode.entries[i]
                FilterChip(selected = sort == mode, onClick = { onSort(mode) },
                    label = { Text(text = mode.label) })
            }
            items(count = QualityFilter.entries.size, key = { i -> "q-" + QualityFilter.entries[i].name }) { i ->
                val q = QualityFilter.entries[i]
                FilterChip(selected = quality == q, onClick = { onQuality(q) },
                    label = { Text(text = q.label) })
            }
            items(count = LanguageFilter.entries.size, key = { i -> "l-" + LanguageFilter.entries[i].name }) { i ->
                val l = LanguageFilter.entries[i]
                FilterChip(selected = language == l, onClick = { onLanguage(l) },
                    label = { Text(text = l.label) })
            }
        }
    }
}

@Composable
private fun SeriesDetailView(
    detail: SeriesDetail,
    categoryName: String?,
    enqueuedName: String?,
    onBack: () -> Unit,
    onEpisode: (com.essa.iptvloader.domain.model.Episode) -> Unit,
    onSeason: (SeasonGroup) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            item(key = "header") {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                        .height(200.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    if (detail.series.cover != null) {
                        AsyncImage(
                            model = detail.series.cover,
                            contentDescription = detail.series.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, Color(0xE6000000))
                                )
                            )
                    )
                    Column(
                        modifier = Modifier.align(Alignment.BottomStart).padding(14.dp)
                    ) {
                        Text(
                            text = detail.series.name,
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = listOfNotNull(
                                detail.series.year,
                                categoryName,
                                detail.seasons.size.toString() + " مواسم"
                            ).joinToString("  •  "),
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFE0E0E0)
                        )
                    }
                    TextButton(
                        onClick = onBack,
                        modifier = Modifier.align(Alignment.TopEnd).padding(6.dp)
                    ) { Text(text = "رجوع", color = Color.White) }
                }
            }
            item(key = "rating") {
                RatingLine(rating = detail.series.rating, year = null)
            }
            detail.seasons.forEach { season ->
                item(key = "season-" + season.season) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "الموسم " + season.season +
                                " — " + season.episodes.size + " حلقة",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Button(onClick = { onSeason(season) }) {
                            Icon(
                                imageVector = Icons.Filled.Download,
                                contentDescription = null,
                                modifier = Modifier.padding(end = 6.dp)
                            )
                            Text(text = "الموسم كامل")
                        }
                    }
                }
                items(
                    items = season.episodes,
                    key = { "ep-" + season.season + "-" + it.episodeNum + "-" + it.id }
                ) { episode ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = episode.title,
                                style = MaterialTheme.typography.bodyLarge,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { onEpisode(episode) }) {
                                Icon(imageVector = Icons.Filled.Download, contentDescription = "تحميل")
                            }
                        }
                    }
                }
                item(key = "div-" + season.season) { HorizontalDivider() }
            }
        }
        if (enqueuedName != null) {
            Snackbar(modifier = Modifier.padding(8.dp)) {
                Text(text = "أُضيف للتحميل: " + enqueuedName)
            }
        }
    }
}
