package com.alshamsi.assistant.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import com.alshamsi.assistant.R

sealed class Destination(
    val route: String,
    val titleRes: Int,
    val icon: ImageVector
) {
    data object Home : Destination("home", R.string.nav_home, Icons.Filled.Home)
    data object Chat : Destination("chat", R.string.nav_chat, Icons.Filled.Chat)
    data object Commands : Destination("commands", R.string.nav_commands, Icons.Filled.Bolt)
    data object Logs : Destination("logs", R.string.nav_logs, Icons.Filled.History)
    data object Settings : Destination("settings", R.string.nav_settings, Icons.Filled.Settings)
    data object Permissions :
        Destination("permissions", R.string.nav_permissions, Icons.Filled.Settings)

    companion object {
        val bottomBar: List<Destination> = listOf(Home, Chat, Commands, Logs, Settings)
    }
}
