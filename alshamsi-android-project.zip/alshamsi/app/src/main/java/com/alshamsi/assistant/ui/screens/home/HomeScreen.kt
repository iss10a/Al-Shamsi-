package com.alshamsi.assistant.ui.screens.home

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.alshamsi.assistant.ui.components.LabelledRow
import com.alshamsi.assistant.ui.components.SectionCard
import com.alshamsi.assistant.ui.components.StatusPill
import com.alshamsi.assistant.voice.ListeningPhase

private data class QuickAction(val label: String, val command: String)

private val quickActions = listOf(
    QuickAction("افتح الكاميرا", "افتح الكاميرا"),
    QuickAction("شغل الكشاف", "شغل الكشاف"),
    QuickAction("اطفِ الكشاف", "اطفي الكشاف"),
    QuickAction("اقرأ الإشعارات", "اقرأ الإشعارات"),
    QuickAction("اقرأ الشاشة", "اقرأ الشاشة"),
    QuickAction("الشاشة الرئيسية", "روح للرئيسية"),
    QuickAction("رجوع", "ارجع"),
    QuickAction("الإعدادات", "افتح الإعدادات"),
    QuickAction("واي فاي", "افتح إعدادات الواي فاي"),
    QuickAction("الملفات", "افتح الملفات")
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    onOpenPermissions: () -> Unit,
    onOpenChat: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val permissions by viewModel.permissions.collectAsStateWithLifecycle()
    val phase by viewModel.listeningPhase.collectAsStateWithLifecycle()
    val running by viewModel.serviceRunning.collectAsStateWithLifecycle()
    val heard by viewModel.lastHeard.collectAsStateWithLifecycle()
    val reply by viewModel.lastReply.collectAsStateWithLifecycle()
    val busy by viewModel.busy.collectAsStateWithLifecycle()

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { viewModel.refreshPermissions() }

    val allGranted = permissions.isNotEmpty() && permissions.all { it.granted }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 16.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(text = "الشامسي", style = MaterialTheme.typography.displaySmall)
                Text(
                    text = "مساعدك الشخصي على الجهاز — يشتغل بدون حساب وبدون خدمات مدفوعة.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item {
            SectionCard(
                title = "الحالة",
                subtitle = if (allGranted) "كل الصلاحيات جاهزة." else "بعض الصلاحيات ناقصة."
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    permissions.forEach { permission ->
                        LabelledRow(label = permission.title) {
                            StatusPill(
                                text = if (permission.granted) "ممنوحة" else "غير ممنوحة",
                                positive = permission.granted
                            )
                        }
                    }
                    OutlinedButton(
                        onClick = onOpenPermissions,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "إدارة الصلاحيات")
                    }
                }
            }
        }

        item {
            SectionCard(
                title = "المساعد الصوتي",
                subtitle = when (phase) {
                    ListeningPhase.IDLE -> "متوقف."
                    ListeningPhase.WAITING_FOR_WAKE_WORD -> "بانتظار «يا الشامسي»."
                    ListeningPhase.LISTENING_FOR_COMMAND -> "أسمعك، تفضل."
                    ListeningPhase.PROCESSING -> "جاري التنفيذ…"
                }
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (heard.isNotBlank()) {
                        Text(
                            text = "آخر ما سمعته: " + heard,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Button(
                        onClick = {
                            val needed = ArrayList<String>()
                            needed.add(Manifest.permission.RECORD_AUDIO)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                needed.add(Manifest.permission.POST_NOTIFICATIONS)
                            }
                            permissionLauncher.launch(needed.toTypedArray())
                            viewModel.toggleListening()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = if (running) Icons.Filled.MicOff else Icons.Filled.Mic,
                            contentDescription = null
                        )
                        Text(
                            text = if (running) "إيقاف الاستماع" else "ابدأ الاستماع",
                            modifier = Modifier.padding(start = 8.dp)
                        )
                    }
                    OutlinedButton(onClick = onOpenChat, modifier = Modifier.fillMaxWidth()) {
                        Text(text = "افتح المحادثة")
                    }
                }
            }
        }

        item {
            SectionCard(title = "إجراءات سريعة") {
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    quickActions.forEach { action ->
                        AssistChip(
                            onClick = { viewModel.runQuickCommand(action.command) },
                            label = { Text(text = action.label) }
                        )
                    }
                }
            }
        }

        if (busy) {
            item {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
        }

        if (reply.isNotBlank()) {
            item {
                SectionCard(title = "آخر رد") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = reply, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        }
    }
}
