package com.alshamsi.assistant.device.control

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.FileProvider
import com.alshamsi.assistant.core.OperationResult
import com.alshamsi.assistant.domain.model.SettingsSection
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/** Everything that is achieved through public Android intents. */
@Singleton
class DeviceController @Inject constructor(
    @ApplicationContext private val context: Context,
    private val appLauncher: AppLauncher
) {

    fun startExternal(intent: Intent): OperationResult<Unit> =
        OperationResult.runCatchingResult("تعذر تنفيذ العملية") {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                context.startActivity(intent)
            } catch (notFound: ActivityNotFoundException) {
                throw IllegalStateException("ما فيه تطبيق يقدر يفتح هذا الطلب", notFound)
            }
        }

    fun openApp(query: String): OperationResult<String> {
        val app = appLauncher.resolve(query)
            ?: return OperationResult.Failure("ما لقيت تطبيقاً باسم «" + query + "».")
        val intent = appLauncher.launchIntentFor(app.packageName)
            ?: return OperationResult.Failure("تطبيق «" + app.label + "» ما يدعم الفتح المباشر.")
        return when (val result = startExternal(intent)) {
            is OperationResult.Success -> OperationResult.Success(app.label)
            is OperationResult.Failure -> result
        }
    }

    fun openSettings(section: SettingsSection): OperationResult<Unit> {
        val action = when (section) {
            SettingsSection.MAIN -> Settings.ACTION_SETTINGS
            SettingsSection.WIFI -> Settings.ACTION_WIFI_SETTINGS
            SettingsSection.BLUETOOTH -> Settings.ACTION_BLUETOOTH_SETTINGS
            SettingsSection.DISPLAY -> Settings.ACTION_DISPLAY_SETTINGS
            SettingsSection.SOUND -> Settings.ACTION_SOUND_SETTINGS
            SettingsSection.BATTERY -> Intent.ACTION_POWER_USAGE_SUMMARY
            SettingsSection.STORAGE -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            SettingsSection.APPS -> Settings.ACTION_APPLICATION_SETTINGS
            SettingsSection.LOCATION -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            SettingsSection.SECURITY -> Settings.ACTION_SECURITY_SETTINGS
            SettingsSection.ACCESSIBILITY -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            SettingsSection.NOTIFICATIONS -> Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS
            SettingsSection.DATE -> Settings.ACTION_DATE_SETTINGS
        }
        return startExternal(Intent(action))
    }

    fun openAccessibilitySettings(): OperationResult<Unit> =
        startExternal(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))

    fun openNotificationListenerSettings(): OperationResult<Unit> =
        startExternal(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))

    fun openAppDetailsSettings(): OperationResult<Unit> {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        intent.data = Uri.fromParts("package", context.packageName, null)
        return startExternal(intent)
    }

    fun openAllFilesAccessSettings(): OperationResult<Unit> {
        val intent = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
        intent.data = Uri.fromParts("package", context.packageName, null)
        return when (val result = startExternal(intent)) {
            is OperationResult.Success -> result
            is OperationResult.Failure ->
                startExternal(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
        }
    }

    fun openCamera(): OperationResult<Unit> {
        val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        return when (val result = startExternal(intent)) {
            is OperationResult.Success -> result
            is OperationResult.Failure -> {
                val fallback = appLauncher.resolve("الكاميرا")
                val launch = fallback?.let { appLauncher.launchIntentFor(it.packageName) }
                if (launch != null) startExternal(launch) else result
            }
        }
    }

    fun openFilesApp(): OperationResult<Unit> {
        val intent = Intent(Intent.ACTION_VIEW)
        intent.type = "*/*"
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        return when (val result = startExternal(intent)) {
            is OperationResult.Success -> result
            is OperationResult.Failure -> {
                val documents = Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                startExternal(documents)
            }
        }
    }

    fun openUrl(url: String): OperationResult<Unit> {
        val normalized = when {
            url.startsWith("http://") || url.startsWith("https://") -> url
            else -> "https://" + url
        }
        return startExternal(Intent(Intent.ACTION_VIEW, Uri.parse(normalized)))
    }

    fun webSearch(query: String): OperationResult<Unit> {
        val intent = Intent(Intent.ACTION_WEB_SEARCH)
        intent.putExtra("query", query)
        return when (val result = startExternal(intent)) {
            is OperationResult.Success -> result
            is OperationResult.Failure -> openUrl(
                "https://duckduckgo.com/?q=" + Uri.encode(query)
            )
        }
    }

    fun shareFile(file: File): OperationResult<Unit> =
        OperationResult.runCatchingResult("تعذر مشاركة الملف") {
            val uri = FileProvider.getUriForFile(
                context,
                context.packageName + ".fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_SEND)
            intent.type = mimeTypeOf(file)
            intent.putExtra(Intent.EXTRA_STREAM, uri)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val chooser = Intent.createChooser(intent, "مشاركة الملف")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        }

    fun shareText(text: String): OperationResult<Unit> =
        OperationResult.runCatchingResult("تعذر مشاركة النص") {
            val intent = Intent(Intent.ACTION_SEND)
            intent.type = "text/plain"
            intent.putExtra(Intent.EXTRA_TEXT, text)
            val chooser = Intent.createChooser(intent, "مشاركة")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        }

    fun launchRawIntent(action: String, data: String?): OperationResult<Unit> {
        val intent = Intent(action)
        if (!data.isNullOrBlank()) {
            intent.data = Uri.parse(data)
        }
        return startExternal(intent)
    }

    private fun mimeTypeOf(file: File): String {
        val extension = file.extension.lowercase()
        return when (extension) {
            "jpg", "jpeg", "png", "webp", "gif", "bmp" -> "image/*"
            "mp4", "mkv", "3gp", "avi", "mov" -> "video/*"
            "mp3", "wav", "ogg", "m4a", "aac" -> "audio/*"
            "pdf" -> "application/pdf"
            "txt", "log", "md", "json", "xml", "csv" -> "text/plain"
            "apk" -> "application/vnd.android.package-archive"
            "zip" -> "application/zip"
            else -> "*/*"
        }
    }
}
