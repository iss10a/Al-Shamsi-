package com.essa.iptvloader.download

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.essa.iptvloader.MainActivity
import com.essa.iptvloader.R
import com.essa.iptvloader.core.ApplicationScope
import com.essa.iptvloader.core.Constants
import com.essa.iptvloader.core.Formatters
import com.essa.iptvloader.domain.model.DownloadStatus
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch

/**
 * Foreground service that keeps downloads alive and shows aggregate progress.
 * The actual work is driven by [DownloadManager]; this service only owns the notification
 * and the process-priority guarantee required for long transfers.
 */
@AndroidEntryPoint
class DownloadService : Service() {

    @Inject lateinit var manager: DownloadManager

    @Inject
    @field:ApplicationScope
    lateinit var scope: CoroutineScope

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForegroundCompat(buildNotification("جاري التحضير…", 0, 0, true))
        scope.launch { manager.restoreOnStart() }
        observe()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            Constants.ACTION_PAUSE -> intent.taskId()?.let { scope.launch { manager.pause(it) } }
            Constants.ACTION_RESUME -> intent.taskId()?.let { scope.launch { manager.resume(it) } }
            Constants.ACTION_CANCEL -> intent.taskId()?.let { scope.launch { manager.remove(it) } }
        }
        return START_STICKY
    }

    private fun Intent.taskId(): Long? =
        getLongExtra(Constants.EXTRA_TASK_ID, -1L).takeIf { it >= 0 }

    private fun observe() {
        manager.items.onEach { items ->
            val active = items.filter { it.status == DownloadStatus.RUNNING }
            val notification = if (active.isEmpty()) {
                val queued = items.count { it.status == DownloadStatus.QUEUED }
                if (queued > 0) {
                    buildNotification("في الانتظار: " + queued, 0, 0, true)
                } else {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                    return@onEach
                }
            } else {
                val first = active.first()
                val percent = (first.progress * 100).toInt()
                val speed = Formatters.speed(active.sumOf { it.speedBytesPerSec })
                buildNotification(
                    first.fileName + "  •  " + speed,
                    100,
                    percent,
                    false
                )
            }
            notify(notification)
        }.launchIn(scope)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = getSystemService(NotificationManager::class.java) ?: return
        if (nm.getNotificationChannel(Constants.DOWNLOAD_CHANNEL_ID) != null) return
        val channel = NotificationChannel(
            Constants.DOWNLOAD_CHANNEL_ID,
            "التحميلات",
            NotificationManager.IMPORTANCE_LOW
        )
        channel.setShowBadge(false)
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(
        text: String,
        max: Int,
        progress: Int,
        indeterminate: Boolean
    ): Notification {
        val contentIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = NotificationCompat.Builder(this, Constants.DOWNLOAD_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(contentIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
        if (max > 0 || indeterminate) {
            builder.setProgress(max, progress, indeterminate)
        }
        return builder.build()
    }

    private fun startForegroundCompat(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                Constants.DOWNLOAD_NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(Constants.DOWNLOAD_NOTIFICATION_ID, notification)
        }
    }

    private fun notify(notification: Notification) {
        val nm = getSystemService(NotificationManager::class.java) ?: return
        nm.notify(Constants.DOWNLOAD_NOTIFICATION_ID, notification)
    }

    companion object {
        fun start(context: Context) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, DownloadService::class.java)
            )
        }

        fun action(context: Context, action: String, taskId: Long) {
            val intent = Intent(context, DownloadService::class.java)
                .setAction(action)
                .putExtra(Constants.EXTRA_TASK_ID, taskId)
            ContextCompat.startForegroundService(context, intent)
        }
    }
}
