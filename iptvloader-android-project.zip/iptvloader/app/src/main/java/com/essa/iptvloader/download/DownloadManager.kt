package com.essa.iptvloader.download

import android.content.Context
import com.essa.iptvloader.core.ApplicationScope
import com.essa.iptvloader.core.Constants
import com.essa.iptvloader.core.Formatters
import com.essa.iptvloader.data.local.DownloadDao
import com.essa.iptvloader.data.local.entity.DownloadEntity
import com.essa.iptvloader.data.local.entity.toItem
import com.essa.iptvloader.data.repository.SettingsRepository
import com.essa.iptvloader.domain.model.ContentKind
import com.essa.iptvloader.domain.model.DownloadItem
import com.essa.iptvloader.domain.model.DownloadPriority
import com.essa.iptvloader.domain.model.DownloadStatus
import com.essa.iptvloader.domain.model.Segment
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Owns the download queue: enforces the max-concurrent limit, honours priority ordering,
 * and drives each active task through the [SegmentedDownloader]. Survives UI restarts and
 * restores unfinished tasks from Room on first use.
 */
@Singleton
class DownloadManager @Inject constructor(
    @ApplicationContext private val context: Context,
    @ApplicationScope private val scope: CoroutineScope,
    private val dao: DownloadDao,
    private val settingsRepository: SettingsRepository
) {
    private val downloader = SegmentedDownloader(SegmentedDownloader.defaultClient())
    private val jobs = ConcurrentHashMap<Long, Job>()
    private val speeds = ConcurrentHashMap<Long, Long>()
    private val mutex = Mutex()

    private val _activeCount = MutableStateFlow(0)
    val activeCount: StateFlow<Int> = _activeCount.asStateFlow()

    val items: Flow<List<DownloadItem>> =
        combine(dao.observeAll(), _speedTick()) { entities, _ ->
            entities.map { it.toItem(speeds[it.id] ?: 0L) }
        }

    private fun _speedTick(): Flow<Long> = _activeCount.map { System.currentTimeMillis() }

    suspend fun enqueue(
        url: String,
        fileName: String,
        subDir: String,
        kind: ContentKind
    ): Long {
        if (dao.countByUrl(url) > 0) return -1L
        val settings = settingsRepository.currentSettings()
        val safeName = Formatters.safeFileName(fileName)
        val dir = File(publicDownloadsRoot(), subDir)
        val target = File(dir, safeName).absolutePath
        val entity = DownloadEntity(
            url = url,
            fileName = safeName,
            targetPath = target,
            kind = kind,
            totalBytes = 0,
            downloadedBytes = 0,
            status = DownloadStatus.QUEUED,
            priority = settings.priority,
            connections = settings.connections,
            segments = "",
            error = null,
            createdAt = System.currentTimeMillis()
        )
        val id = dao.insert(entity)
        pump()
        return id
    }

    suspend fun pause(id: Long) {
        jobs[id]?.cancel()
        jobs.remove(id)
        speeds.remove(id)
        dao.updateStatus(id, DownloadStatus.PAUSED.name)
        recomputeActive()
        pump()
    }

    suspend fun resume(id: Long) {
        val entity = dao.getById(id) ?: return
        if (entity.status == DownloadStatus.COMPLETED) return
        dao.updateStatus(id, DownloadStatus.QUEUED.name)
        pump()
    }

    suspend fun remove(id: Long) {
        jobs[id]?.cancel()
        jobs.remove(id)
        speeds.remove(id)
        val entity = dao.getById(id)
        if (entity != null && entity.status != DownloadStatus.COMPLETED) {
            runCatching { File(entity.targetPath + PART_SUFFIX).delete() }
        }
        dao.delete(id)
        recomputeActive()
        pump()
    }

    suspend fun restoreOnStart() {
        dao.pending().forEach { entity ->
            if (entity.status == DownloadStatus.RUNNING) {
                dao.updateStatus(entity.id, DownloadStatus.QUEUED.name)
            }
        }
        pump()
    }

    /** Starts as many queued tasks as the concurrency limit allows, respecting priority. */
    private fun pump() {
        scope.launch {
            mutex.withLock {
                val settings = settingsRepository.currentSettings()
                val maxConcurrent = settings.maxConcurrentDownloads
                if (jobs.size >= maxConcurrent) return@withLock
                val pending = dao.pending()
                    .filter { it.status == DownloadStatus.QUEUED && !jobs.containsKey(it.id) }
                    .sortedWith(compareBy({ priorityRank(it.priority) }, { it.createdAt }))
                for (entity in pending) {
                    if (jobs.size >= maxConcurrent) break
                    startJob(entity.id)
                }
            }
            recomputeActive()
        }
    }

    private fun startJob(id: Long) {
        val job = scope.launch {
            runTask(id)
            jobs.remove(id)
            speeds.remove(id)
            recomputeActive()
            pump()
        }
        jobs[id] = job
    }

    private suspend fun runTask(id: Long) {
        val entity = dao.getById(id) ?: return
        dao.updateStatus(id, DownloadStatus.RUNNING.name)

        val partFile = File(entity.targetPath + PART_SUFFIX)
        partFile.parentFile?.mkdirs()

        var total = entity.totalBytes
        var segments: List<Segment> = SegmentStore.decode(entity.segments)
        var singleStream = false

        if (segments.isEmpty()) {
            when (val probe = downloader.probe(entity.url)) {
                is ProbeResult.Error -> {
                    dao.markFailed(id, DownloadStatus.FAILED.name, probe.message)
                    return
                }
                is ProbeResult.Ok -> {
                    total = probe.totalBytes
                    if (total > 0 && probe.acceptRanges) {
                        segments = SegmentStore.planSegments(total, entity.connections, Constants.MIN_SEGMENT_SIZE)
                    } else {
                        singleStream = true
                        segments = listOf(Segment(0, 0, if (total > 0) total - 1 else -1, 0))
                    }
                    dao.update(
                        entity.copy(
                            totalBytes = total,
                            segments = SegmentStore.encode(segments),
                            status = DownloadStatus.RUNNING
                        )
                    )
                }
            }
        } else {
            singleStream = segments.size == 1 && segments.first().end < 0
        }

        val raf = RandomAccessFile(partFile, "rw")
        if (total > 0) runCatching { raf.setLength(total) }

        var lastBytes = entity.downloadedBytes
        var lastTime = System.currentTimeMillis()

        val result = raf.use { file ->
            downloader.download(entity.url, file, segments, singleStream) { downloaded, segs ->
                val now = System.currentTimeMillis()
                val dt = (now - lastTime).coerceAtLeast(1)
                if (now - lastTime >= 1000) {
                    speeds[id] = ((downloaded - lastBytes) * 1000 / dt)
                    lastBytes = downloaded
                    lastTime = now
                }
                dao.updateProgress(id, downloaded, SegmentStore.encode(segs))
            }
        }

        when (result) {
            is DownloadResult.Completed -> {
                val finalFile = File(entity.targetPath)
                runCatching {
                    if (finalFile.exists()) finalFile.delete()
                    partFile.renameTo(finalFile)
                }
                dao.updateProgress(id, total.coerceAtLeast(entity.downloadedBytes), entity.segments)
                dao.update(
                    (dao.getById(id) ?: entity).copy(
                        status = DownloadStatus.COMPLETED,
                        downloadedBytes = if (total > 0) total else entity.downloadedBytes,
                        error = null
                    )
                )
            }
            is DownloadResult.Paused -> {
                val current = dao.getById(id)
                if (current?.status == DownloadStatus.RUNNING) {
                    dao.updateStatus(id, DownloadStatus.PAUSED.name)
                }
            }
            is DownloadResult.Failed -> dao.markFailed(id, DownloadStatus.FAILED.name, result.message)
        }
        speeds.remove(id)
    }

    private fun recomputeActive() {
        _activeCount.value = jobs.size
    }

    private fun priorityRank(p: DownloadPriority): Int = when (p) {
        DownloadPriority.HIGH -> 0
        DownloadPriority.NORMAL -> 1
        DownloadPriority.LOW -> 2
    }

    private fun publicDownloadsRoot(): File {
        val downloads = android.os.Environment.getExternalStoragePublicDirectory(
            android.os.Environment.DIRECTORY_DOWNLOADS
        )
        return downloads ?: File(context.getExternalFilesDir(null), Constants.ROOT_DIR)
    }

    companion object {
        const val PART_SUFFIX = ".part"
    }
}
