package com.essa.iptvloader.core

object Constants {
    const val DATABASE_NAME = "iptvloader.db"
    const val PREFS_STORE = "iptvloader_prefs"

    const val DOWNLOAD_CHANNEL_ID = "iptv_downloads"
    const val DOWNLOAD_NOTIFICATION_ID = 2001

    const val ACTION_START = "com.essa.iptvloader.START"
    const val ACTION_PAUSE = "com.essa.iptvloader.PAUSE"
    const val ACTION_RESUME = "com.essa.iptvloader.RESUME"
    const val ACTION_CANCEL = "com.essa.iptvloader.CANCEL"
    const val EXTRA_TASK_ID = "task_id"

    const val ROOT_DIR = "Download"
    const val MOVIES_DIR = "Movies"
    const val SERIES_DIR = "Series"

    const val DEFAULT_CONNECTIONS = 8
    const val DEFAULT_MAX_DOWNLOADS = 3
    const val MIN_SEGMENT_SIZE = 1L * 1024 * 1024
}
