package com.essa.iptvloader.data.repository

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import com.essa.iptvloader.core.Constants
import com.essa.iptvloader.domain.model.AppSettings
import com.essa.iptvloader.domain.model.DownloadPriority
import com.essa.iptvloader.domain.model.ServerCredentials
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

@Singleton
class SettingsRepository @Inject constructor(
    private val dataStore: DataStore<Preferences>
) {
    private object Keys {
        val SERVER = stringPreferencesKey("server_url")
        val USER = stringPreferencesKey("username")
        val PASS = stringPreferencesKey("password")
        val PRIORITY = stringPreferencesKey("priority")
        val CONNECTIONS = intPreferencesKey("connections")
        val MAX_DOWNLOADS = intPreferencesKey("max_downloads")
    }

    val credentials: Flow<ServerCredentials> = dataStore.data.map { prefs ->
        ServerCredentials(
            serverUrl = prefs[Keys.SERVER].orEmpty(),
            username = prefs[Keys.USER].orEmpty(),
            password = prefs[Keys.PASS].orEmpty()
        )
    }

    val settings: Flow<AppSettings> = dataStore.data.map { prefs ->
        AppSettings(
            priority = runCatching {
                DownloadPriority.valueOf(prefs[Keys.PRIORITY] ?: DownloadPriority.HIGH.name)
            }.getOrDefault(DownloadPriority.HIGH),
            connections = prefs[Keys.CONNECTIONS] ?: Constants.DEFAULT_CONNECTIONS,
            maxConcurrentDownloads = prefs[Keys.MAX_DOWNLOADS] ?: Constants.DEFAULT_MAX_DOWNLOADS
        )
    }

    suspend fun currentCredentials(): ServerCredentials = credentials.first()
    suspend fun currentSettings(): AppSettings = settings.first()

    suspend fun saveCredentials(creds: ServerCredentials) {
        dataStore.edit {
            it[Keys.SERVER] = creds.serverUrl.trim()
            it[Keys.USER] = creds.username.trim()
            it[Keys.PASS] = creds.password
        }
    }

    suspend fun clearCredentials() {
        dataStore.edit {
            it.remove(Keys.SERVER)
            it.remove(Keys.USER)
            it.remove(Keys.PASS)
        }
    }

    suspend fun setPriority(priority: DownloadPriority) {
        dataStore.edit { it[Keys.PRIORITY] = priority.name }
    }

    suspend fun setConnections(value: Int) {
        dataStore.edit { it[Keys.CONNECTIONS] = value.coerceIn(1, 16) }
    }

    suspend fun setMaxDownloads(value: Int) {
        dataStore.edit { it[Keys.MAX_DOWNLOADS] = value.coerceIn(1, 10) }
    }
}
