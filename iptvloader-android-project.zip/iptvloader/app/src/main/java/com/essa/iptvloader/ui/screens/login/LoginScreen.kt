package com.essa.iptvloader.ui.screens.login

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun LoginScreen(
    onConnected: () -> Unit,
    viewModel: LoginViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val clipboard = LocalClipboardManager.current

    if (state.connected) {
        viewModel.consumeConnected()
        onConnected()
    }

    fun pasted(): String = clipboard.getText()?.text.orEmpty()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "الدخول للسيرفر",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(top = 32.dp, bottom = 8.dp)
        )

        FieldWithPaste(
            label = "عنوان السيرفر",
            value = state.serverUrl,
            onChange = viewModel::onServer,
            onPaste = { viewModel.onServer(pasted()) }
        )
        FieldWithPaste(
            label = "اسم المستخدم",
            value = state.username,
            onChange = viewModel::onUser,
            onPaste = { viewModel.onUser(pasted()) }
        )
        FieldWithPaste(
            label = "كلمة المرور",
            value = state.password,
            onChange = viewModel::onPass,
            onPaste = { viewModel.onPass(pasted()) },
            password = true
        )

        if (state.error != null) {
            Text(text = state.error!!, color = MaterialTheme.colorScheme.error)
        }

        OutlinedButton(
            onClick = viewModel::save,
            modifier = Modifier.fillMaxWidth()
        ) { Text(text = "حفظ البيانات") }

        Button(
            onClick = viewModel::connect,
            enabled = !state.connecting,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (state.connecting) {
                CircularProgressIndicator(
                    modifier = Modifier.padding(end = 8.dp),
                    strokeWidth = 2.dp
                )
                Text(text = "جاري الاتصال…")
            } else {
                Text(text = "اتصال")
            }
        }
    }
}

@Composable
private fun FieldWithPaste(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    onPaste: () -> Unit,
    password: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = onChange,
            label = { Text(text = label) },
            singleLine = true,
            visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
            modifier = Modifier.weight(1f)
        )
        IconButton(onClick = onPaste) {
            Icon(imageVector = Icons.Filled.ContentPaste, contentDescription = "لصق")
        }
    }
}
