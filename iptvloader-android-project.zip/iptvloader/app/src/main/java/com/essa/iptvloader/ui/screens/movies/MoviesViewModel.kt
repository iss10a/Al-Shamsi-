package com.essa.iptvloader.ui.screens.movies

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.essa.iptvloader.core.Constants
import com.essa.iptvloader.data.remote.ApiResult
import com.essa.iptvloader.data.repository.ContentRepository
import com.essa.iptvloader.domain.model.ContentKind
import com.essa.iptvloader.domain.model.Movie
import com.essa.iptvloader.download.DownloadManager
import com.essa.iptvloader.download.DownloadService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class MoviesUiState(
    val loading: Boolean = false,
    val movies: List<Movie> = emptyList(),
    val query: String = "",
    val error: String? = null
)

@HiltViewModel
class MoviesViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: ContentRepository,
    private val downloadManager: DownloadManager
) : ViewModel() {

    private val _state = MutableStateFlow(MoviesUiState())
    val state: StateFlow<MoviesUiState> = _state.asStateFlow()

    private var all: List<Movie> = emptyList()

    init { refresh() }

    fun onQuery(value: String) {
        _state.value = _state.value.copy(query = value, movies = filter(value))
    }

    fun refresh() {
        _state.value = _state.value.copy(loading = true, error = null)
        viewModelScope.launch {
            when (val result = repository.movies()) {
                is ApiResult.Ok -> {
                    all = result.data
                    _state.value = _state.value.copy(
                        loading = false,
                        movies = filter(_state.value.query)
                    )
                }
                is ApiResult.Error ->
                    _state.value = _state.value.copy(loading = false, error = result.message)
            }
        }
    }

    fun download(movie: Movie) {
        viewModelScope.launch {
            val url = repository.movieUrl(movie)
            val displayName = buildName(movie)
            downloadManager.enqueue(url, displayName + "." + movie.extension, Constants.MOVIES_DIR, ContentKind.MOVIE)
            DownloadService.start(context)
        }
    }

    private fun buildName(movie: Movie): String {
        val year = movie.year?.takeIf { it.isNotBlank() }
        return if (year != null && !movie.name.contains(year)) {
            movie.name + " (" + year + ")"
        } else {
            movie.name
        }
    }

    private fun filter(query: String): List<Movie> {
        if (query.isBlank()) return all
        val q = query.trim()
        return all.filter { it.name.contains(q, ignoreCase = true) }
    }
}
