package com.essa.iptvloader.domain.model

data class Movie(
    val streamId: Int,
    val name: String,
    val extension: String,
    val icon: String?,
    val year: String?
)

data class Series(
    val seriesId: Int,
    val name: String,
    val cover: String?,
    val year: String?
)

data class Episode(
    val id: String,
    val title: String,
    val season: Int,
    val episodeNum: Int,
    val extension: String
)

data class SeasonGroup(
    val season: Int,
    val episodes: List<Episode>
)

data class SeriesDetail(
    val series: Series,
    val seasons: List<SeasonGroup>
)
