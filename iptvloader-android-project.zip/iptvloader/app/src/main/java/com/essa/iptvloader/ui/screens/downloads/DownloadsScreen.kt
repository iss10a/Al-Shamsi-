package com.essa.iptvloader.ui.screens.downloads

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.essa.iptvloader.core.Formatters
import com.essa.iptvloader.domain.model.DownloadItem
import com.essa.iptvloader.domain.model.DownloadStatus

@Composable
fun DownloadsScreen(viewModel: DownloadsViewModel = hiltViewModel()) {
    val downloads by viewModel.items.collectAsStateWithLifecycle()

    if (downloads.isEmpty()) {
        Box(Modifier.fillMaxSize(), Alignment.Center) {
            Text(text = "لا توجد تحميلات بعد.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 12.dp)
    ) {
        items(items = downloads, key = { it.id }) { item ->
            DownloadCard(
                item = item,
                onPause = { viewModel.pause(item) },
                onResume = { viewModel.resume(item) },
                onDelete = { viewModel.remove(item) }
            )
        }
    }
}

@Composable
private fun DownloadCard(
    item: DownloadItem,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onDelete: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(text = item.fileName, style = MaterialTheme.typography.titleMedium, maxLines = 2)

            LinearProgressIndicator(
                progress = { item.progress },
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = (item.progress * 100).toInt().toString() + "%  •  " +
                        Formatters.bytes(item.downloadedBytes) + " / " + Formatters.bytes(item.totalBytes),
                    style = MaterialTheme.typography.bodySmall
                )
                Text(text = statusText(item), style = MaterialTheme.typography.bodySmall)
            }

            if (item.status == DownloadStatus.RUNNING) {
                Text(
                    text = Formatters.speed(item.speedBytesPerSec) + "  •  " +
                        "المتبقّي " + Formatters.eta(
                            item.totalBytes - item.downloadedBytes,
                            item.speedBytesPerSec
                        ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            if (item.error != null) {
                Text(text = item.error, color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                when (item.status) {
                    DownloadStatus.RUNNING, DownloadStatus.QUEUED ->
                        IconButton(onClick = onPause) {
                            Icon(imageVector = Icons.Filled.Pause, contentDescription = "إيقاف")
                        }
                    DownloadStatus.PAUSED, DownloadStatus.FAILED ->
                        IconButton(onClick = onResume) {
                            Icon(imageVector = Icons.Filled.PlayArrow, contentDescription = "استكمال")
                        }
                    DownloadStatus.COMPLETED -> Unit
                }
                IconButton(onClick = onDelete) {
                    Icon(imageVector = Icons.Filled.Delete, contentDescription = "حذف")
                }
            }
        }
    }
}

private fun statusText(item: DownloadItem): String = when (item.status) {
    DownloadStatus.QUEUED -> "في الانتظار"
    DownloadStatus.RUNNING -> "جاري التحميل"
    DownloadStatus.PAUSED -> "متوقف"
    DownloadStatus.COMPLETED -> "مكتمل"
    DownloadStatus.FAILED -> "فشل"
}
