package com.essa.iptvloader.core

import java.util.Locale

object Formatters {

    fun bytes(value: Long): String {
        if (value <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        var size = value.toDouble()
        var unit = 0
        while (size >= 1024 && unit < units.size - 1) {
            size /= 1024
            unit++
        }
        return String.format(Locale.US, "%.1f %s", size, units[unit])
    }

    fun speed(bytesPerSecond: Long): String = bytes(bytesPerSecond) + "/s"

    fun eta(remainingBytes: Long, bytesPerSecond: Long): String {
        if (bytesPerSecond <= 0) return "—"
        val seconds = remainingBytes / bytesPerSecond
        return when {
            seconds >= 3600 -> (seconds / 3600).toString() + " س " + ((seconds % 3600) / 60) + " د"
            seconds >= 60 -> (seconds / 60).toString() + " د " + (seconds % 60) + " ث"
            else -> seconds.toString() + " ث"
        }
    }

    /** Removes characters that are illegal in file names while keeping the server name intact. */
    fun safeFileName(name: String): String =
        name.replace(Regex("[\\\\/:*?\"<>|]"), " ").replace(Regex("\\s+"), " ").trim()
}
