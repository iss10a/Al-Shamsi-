package com.essa.iptvloader.download

import com.essa.iptvloader.domain.model.Segment
import java.io.RandomAccessFile
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext
import okhttp3.OkHttpClient
import okhttp3.Request

sealed class ProbeResult {
    data class Ok(val totalBytes: Long, val acceptRanges: Boolean) : ProbeResult()
    data class Error(val message: String) : ProbeResult()
}

sealed class DownloadResult {
    data object Completed : DownloadResult()
    data object Paused : DownloadResult()
    data class Failed(val message: String) : DownloadResult()
}

/**
 * Multi-connection, range-based downloader. Splits the file into segments and downloads
 * them in parallel, writing each into its own offset with a shared RandomAccessFile.
 * Progress and per-segment cursors are reported so the caller can persist and resume.
 */
class SegmentedDownloader(
    private val client: OkHttpClient
) {

    suspend fun probe(url: String): ProbeResult = withContext(Dispatchers.IO) {
        runCatching {
            val request = Request.Builder()
                .url(url)
                .header("Range", "bytes=0-0")
                .get()
                .build()
            client.newCall(request).execute().use { response ->
                val code = response.code
                if (code == 206) {
                    val contentRange = response.header("Content-Range")
                    val total = contentRange?.substringAfter('/')?.toLongOrNull() ?: -1L
                    ProbeResult.Ok(total, acceptRanges = true)
                } else if (code == 200) {
                    val total = response.header("Content-Length")?.toLongOrNull() ?: -1L
                    val accept = response.header("Accept-Ranges")?.contains("bytes") == true
                    ProbeResult.Ok(total, acceptRanges = accept)
                } else {
                    ProbeResult.Error("السيرفر رد بالرمز " + code)
                }
            }
        }.getOrElse { ProbeResult.Error(it.message ?: "تعذر بدء التحميل") }
    }

    /**
     * Downloads all [segments] into [file]. Calls [onProgress] with the total bytes
     * downloaded so far and the (mutated) segment list, roughly once per second.
     * Returns when finished, paused (coroutine cancelled) or failed.
     */
    suspend fun download(
        url: String,
        file: RandomAccessFile,
        segments: List<Segment>,
        singleStream: Boolean,
        onProgress: suspend (Long, List<Segment>) -> Unit
    ): DownloadResult {
        val totalDownloaded = AtomicLong(segments.sumOf { it.downloaded })
        return try {
            if (singleStream || segments.size <= 1) {
                downloadSegment(url, file, segments.first(), totalDownloaded, onProgress, segments)
            } else {
                coroutineScope {
                    val limiter = Semaphore(segments.size)
                    segments.filterNot { it.done }.forEach { segment ->
                        launch(Dispatchers.IO) {
                            limiter.withPermit {
                                downloadSegment(url, file, segment, totalDownloaded, onProgress, segments)
                            }
                        }
                    }
                }
            }
            onProgress(totalDownloaded.get(), segments)
            if (segments.all { it.done }) DownloadResult.Completed else DownloadResult.Paused
        } catch (cancel: CancellationException) {
            onProgress(totalDownloaded.get(), segments)
            DownloadResult.Paused
        } catch (throwable: Throwable) {
            DownloadResult.Failed(throwable.message ?: "خطأ أثناء التحميل")
        }
    }

    private suspend fun downloadSegment(
        url: String,
        file: RandomAccessFile,
        segment: Segment,
        totalDownloaded: AtomicLong,
        onProgress: suspend (Long, List<Segment>) -> Unit,
        allSegments: List<Segment>
    ) {
        var lastError: Throwable? = null
        repeat(MAX_SEGMENT_RETRIES) { attempt ->
            try {
                downloadSegmentOnce(url, file, segment, totalDownloaded, onProgress, allSegments)
                return
            } catch (cancel: CancellationException) {
                throw cancel
            } catch (io: java.io.IOException) {
                lastError = io
                if (attempt < MAX_SEGMENT_RETRIES - 1) {
                    kotlinx.coroutines.delay(RETRY_DELAY_MS * (attempt + 1))
                }
            }
        }
        throw lastError ?: java.io.IOException("فشل تحميل الجزء " + segment.index)
    }

    private suspend fun downloadSegmentOnce(
        url: String,
        file: RandomAccessFile,
        segment: Segment,
        totalDownloaded: AtomicLong,
        onProgress: suspend (Long, List<Segment>) -> Unit,
        allSegments: List<Segment>
    ) {
        if (segment.done) return
        val requestBuilder = Request.Builder().url(url)
        val ranged = segment.end >= 0
        if (ranged) {
            requestBuilder.header("Range", "bytes=" + segment.current + "-" + segment.end)
        }
        val request = requestBuilder.get().build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("رمز " + response.code)
            val source = response.body?.byteStream() ?: error("لا يوجد محتوى")
            val buffer = ByteArray(128 * 1024)
            var lastReport = System.currentTimeMillis()
            var position = segment.current

            source.use { input ->
                while (true) {
                    coroutineContext.ensureActive()
                    val read = input.read(buffer)
                    if (read <= 0) break
                    synchronized(file) {
                        file.seek(position)
                        file.write(buffer, 0, read)
                    }
                    position += read
                    segment.current = position
                    totalDownloaded.addAndGet(read.toLong())

                    val now = System.currentTimeMillis()
                    if (now - lastReport >= 1000) {
                        lastReport = now
                        onProgress(totalDownloaded.get(), allSegments)
                    }
                    if (ranged && position > segment.end) break
                }
            }
            if (!ranged) {
                // Length was unknown; mark the segment complete once the stream ends.
                segment.current = if (segment.end >= 0) segment.end + 1 else position
            }
        }
    }

    companion object {
        private const val MAX_SEGMENT_RETRIES = 3
        private const val RETRY_DELAY_MS = 1500L

        fun defaultClient(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }
}
