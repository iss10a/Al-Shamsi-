package com.essa.iptvloader.ui.screens.series

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.essa.iptvloader.domain.model.SeasonGroup
import com.essa.iptvloader.domain.model.Series

@Composable
fun SeriesScreen(viewModel: SeriesViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    if (state.detail != null) {
        SeriesDetailView(
            title = state.detail!!.series.name,
            seasons = state.detail!!.seasons,
            onBack = viewModel::closeDetail,
            onEpisode = viewModel::downloadEpisode,
            onSeason = viewModel::downloadSeason
        )
        return
    }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = state.query,
                onValueChange = viewModel::onQuery,
                label = { Text(text = "بحث…") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = viewModel::refresh) {
                Icon(imageVector = Icons.Filled.Refresh, contentDescription = "تحديث")
            }
        }
        when {
            state.loading || state.detailLoading ->
                Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            state.error != null ->
                Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Text(text = state.error!!, color = MaterialTheme.colorScheme.error)
                }
            else -> LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 8.dp)
            ) {
                items(items = state.series, key = { it.seriesId }) { series ->
                    SeriesRow(series = series, onOpen = { viewModel.openSeries(series) })
                }
            }
        }
    }
}

@Composable
private fun SeriesRow(series: Series, onOpen: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen)) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(text = series.name, style = MaterialTheme.typography.titleMedium)
            if (!series.year.isNullOrBlank()) {
                Text(
                    text = series.year,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun SeriesDetailView(
    title: String,
    seasons: List<SeasonGroup>,
    onBack: () -> Unit,
    onEpisode: (com.essa.iptvloader.domain.model.Episode) -> Unit,
    onSeason: (SeasonGroup) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text(text = "رجوع") }
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(start = 8.dp)
            )
        }
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 8.dp)
        ) {
            seasons.forEach { season ->
                item(key = "season-" + season.season) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "الموسم " + season.season,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Button(onClick = { onSeason(season) }) {
                            Icon(
                                imageVector = Icons.Filled.Download,
                                contentDescription = null,
                                modifier = Modifier.padding(end = 6.dp)
                            )
                            Text(text = "الموسم كامل")
                        }
                    }
                }
                items(items = season.episodes, key = { "ep-" + season.season + "-" + it.episodeNum + "-" + it.id }) { episode ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = episode.title,
                                style = MaterialTheme.typography.bodyLarge,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { onEpisode(episode) }) {
                                Icon(imageVector = Icons.Filled.Download, contentDescription = "تحميل")
                            }
                        }
                    }
                }
                item(key = "div-" + season.season) { HorizontalDivider() }
            }
        }
    }
}
