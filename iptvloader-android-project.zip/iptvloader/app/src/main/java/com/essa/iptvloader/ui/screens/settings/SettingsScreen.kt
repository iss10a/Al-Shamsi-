package com.essa.iptvloader.ui.screens.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.essa.iptvloader.domain.model.DownloadPriority

@Composable
fun SettingsScreen(viewModel: SettingsViewModel = hiltViewModel()) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(text = "الإعدادات", style = MaterialTheme.typography.headlineSmall)

        Card {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(text = "أولوية التحميل", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DownloadPriority.entries.forEach { priority ->
                        FilterChip(
                            selected = settings.priority == priority,
                            onClick = { viewModel.setPriority(priority) },
                            label = { Text(text = priorityLabel(priority)) }
                        )
                    }
                }
                Text(
                    text = "الأولوية العالية تستخدم كامل سرعة الإنترنت وأكبر عدد اتصالات.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Card {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "عدد الاتصالات لكل ملف: " + settings.connections,
                    style = MaterialTheme.typography.titleMedium
                )
                Slider(
                    value = settings.connections.toFloat(),
                    onValueChange = { viewModel.setConnections(it.toInt()) },
                    valueRange = 1f..16f,
                    steps = 14
                )
                Text(
                    text = "كل ملف يُقسَّم إلى أجزاء تُحمَّل بالتوازي — قيمة أعلى = سرعة أعلى.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Card {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "أقصى تحميلات متزامنة: " + settings.maxConcurrentDownloads,
                    style = MaterialTheme.typography.titleMedium
                )
                Slider(
                    value = settings.maxConcurrentDownloads.toFloat(),
                    onValueChange = { viewModel.setMaxDownloads(it.toInt()) },
                    valueRange = 1f..10f,
                    steps = 8
                )
                Text(
                    text = "الملفات تُحمَّل بالترتيب: ما زاد عن الحد ينتظر في الطابور حسب الأولوية.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

private fun priorityLabel(priority: DownloadPriority): String = when (priority) {
    DownloadPriority.HIGH -> "عالية ⭐"
    DownloadPriority.NORMAL -> "عادية"
    DownloadPriority.LOW -> "منخفضة"
}
