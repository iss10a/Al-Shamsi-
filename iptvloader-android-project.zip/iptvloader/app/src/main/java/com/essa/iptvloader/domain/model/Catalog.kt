package com.essa.iptvloader.domain.model

/** Sorting applied when browsing the flat grid. Default keeps the sections view. */
enum class SortMode(val label: String) {
    DEFAULT("الأقسام"),
    NAME("الاسم"),
    NEWEST("الأحدث"),
    YEAR("السنة")
}

enum class QualityFilter(val label: String, val keywords: List<String>) {
    ALL("كل الجودات", emptyList()),
    UHD("4K", listOf("4K", "2160", "UHD")),
    FHD("1080p", listOf("1080", "FHD")),
    HD("720p", listOf("720"))
}

enum class LanguageFilter(val label: String, val keywords: List<String>) {
    ALL("كل اللغات", emptyList()),
    ARABIC("عربي", listOf("عرب", "ARAB")),
    ENGLISH("إنجليزي", listOf("انجليزي", "إنجليزي", "اجنبي", "أجنبي", "EN", "ENGLISH")),
    TURKISH("تركي", listOf("ترك", "TURK")),
    KOREAN("كوري", listOf("كوري", "KOR")),
    INDIAN("هندي", listOf("هند", "HIND", "INDIA")),
    ANIME("أنمي", listOf("انمي", "أنمي", "ANIME"))
}

/** A horizontally scrolling shelf like the ones in IPTV Smarters. */
data class MovieSection(val title: String, val items: List<Movie>)
data class SeriesSection(val title: String, val items: List<Series>)
