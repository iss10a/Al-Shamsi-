package com.essa.iptvloader.domain.model

enum class DownloadStatus { QUEUED, RUNNING, PAUSED, COMPLETED, FAILED }

enum class DownloadPriority { HIGH, NORMAL, LOW }

enum class ContentKind { MOVIE, SERIES }

data class Segment(
    val index: Int,
    val start: Long,
    val end: Long,
    var current: Long
) {
    val done: Boolean get() = current > end
    val downloaded: Long get() = (current - start).coerceAtLeast(0)
    val size: Long get() = end - start + 1
}

data class DownloadItem(
    val id: Long,
    val url: String,
    val fileName: String,
    val targetPath: String,
    val kind: ContentKind,
    val totalBytes: Long,
    val downloadedBytes: Long,
    val status: DownloadStatus,
    val priority: DownloadPriority,
    val connections: Int,
    val speedBytesPerSec: Long = 0,
    val error: String? = null
) {
    val progress: Float
        get() = if (totalBytes > 0) (downloadedBytes.toFloat() / totalBytes).coerceIn(0f, 1f) else 0f
}
