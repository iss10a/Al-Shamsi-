package com.essa.iptvloader.ui.screens.series

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.essa.iptvloader.core.Constants
import com.essa.iptvloader.core.Formatters
import com.essa.iptvloader.data.remote.ApiResult
import com.essa.iptvloader.data.repository.ContentRepository
import com.essa.iptvloader.domain.model.ContentKind
import com.essa.iptvloader.domain.model.Episode
import com.essa.iptvloader.domain.model.SeasonGroup
import com.essa.iptvloader.domain.model.Series
import com.essa.iptvloader.domain.model.SeriesDetail
import com.essa.iptvloader.download.DownloadManager
import com.essa.iptvloader.download.DownloadService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class SeriesUiState(
    val loading: Boolean = false,
    val series: List<Series> = emptyList(),
    val query: String = "",
    val error: String? = null,
    val detailLoading: Boolean = false,
    val detail: SeriesDetail? = null
)

@HiltViewModel
class SeriesViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: ContentRepository,
    private val downloadManager: DownloadManager
) : ViewModel() {

    private val _state = MutableStateFlow(SeriesUiState())
    val state: StateFlow<SeriesUiState> = _state.asStateFlow()

    private var all: List<Series> = emptyList()

    init { refresh() }

    fun onQuery(value: String) {
        _state.value = _state.value.copy(query = value, series = filter(value))
    }

    fun refresh() {
        _state.value = _state.value.copy(loading = true, error = null)
        viewModelScope.launch {
            when (val result = repository.series()) {
                is ApiResult.Ok -> {
                    all = result.data
                    _state.value = _state.value.copy(loading = false, series = filter(_state.value.query))
                }
                is ApiResult.Error ->
                    _state.value = _state.value.copy(loading = false, error = result.message)
            }
        }
    }

    fun openSeries(series: Series) {
        _state.value = _state.value.copy(detailLoading = true, detail = null, error = null)
        viewModelScope.launch {
            when (val result = repository.seriesInfo(series)) {
                is ApiResult.Ok ->
                    _state.value = _state.value.copy(detailLoading = false, detail = result.data)
                is ApiResult.Error ->
                    _state.value = _state.value.copy(detailLoading = false, error = result.message)
            }
        }
    }

    fun closeDetail() { _state.value = _state.value.copy(detail = null) }

    fun downloadEpisode(episode: Episode) {
        viewModelScope.launch {
            enqueueEpisode(episode)
            DownloadService.start(context)
        }
    }

    fun downloadSeason(season: SeasonGroup) {
        viewModelScope.launch {
            season.episodes.forEach { enqueueEpisode(it) }
            DownloadService.start(context)
        }
    }

    private suspend fun enqueueEpisode(episode: Episode) {
        val url = repository.episodeUrl(episode)
        val seriesName = _state.value.detail?.series?.name.orEmpty()
        val subDir = Constants.SERIES_DIR + "/" + Formatters.safeFileName(seriesName.ifBlank { "Series" })
        downloadManager.enqueue(
            url = url,
            fileName = episode.title + "." + episode.extension,
            subDir = subDir,
            kind = ContentKind.SERIES
        )
    }

    private fun filter(query: String): List<Series> {
        if (query.isBlank()) return all
        return all.filter { it.name.contains(query.trim(), ignoreCase = true) }
    }
}
