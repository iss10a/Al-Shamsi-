package com.essa.iptvloader.download

import com.essa.iptvloader.domain.model.Segment
import org.json.JSONArray
import org.json.JSONObject

/** Serialises the segment table so a download can resume exactly where it stopped. */
object SegmentStore {

    fun encode(segments: List<Segment>): String {
        val array = JSONArray()
        for (s in segments) {
            val o = JSONObject()
            o.put("i", s.index)
            o.put("s", s.start)
            o.put("e", s.end)
            o.put("c", s.current)
            array.put(o)
        }
        return array.toString()
    }

    fun decode(raw: String): List<Segment> {
        if (raw.isBlank()) return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            val list = ArrayList<Segment>(array.length())
            for (i in 0 until array.length()) {
                val o = array.optJSONObject(i) ?: continue
                list.add(
                    Segment(
                        index = o.optInt("i"),
                        start = o.optLong("s"),
                        end = o.optLong("e"),
                        current = o.optLong("c", o.optLong("s"))
                    )
                )
            }
            list
        }.getOrDefault(emptyList())
    }

    fun planSegments(totalBytes: Long, connections: Int, minSegment: Long): List<Segment> {
        if (totalBytes <= 0) return emptyList()
        val usableConnections = connections.coerceIn(1, 16)
        val count = maxOf(1, minOf(usableConnections, (totalBytes / minSegment).toInt().coerceAtLeast(1)))
        val chunk = totalBytes / count
        val segments = ArrayList<Segment>(count)
        var start = 0L
        for (i in 0 until count) {
            val end = if (i == count - 1) totalBytes - 1 else start + chunk - 1
            segments.add(Segment(i, start, end, start))
            start = end + 1
        }
        return segments
    }
}
