package com.essa.iptvloader.data.repository

import com.essa.iptvloader.data.remote.ApiResult
import com.essa.iptvloader.data.remote.XtreamApi
import com.essa.iptvloader.domain.model.Movie
import com.essa.iptvloader.domain.model.Series
import com.essa.iptvloader.domain.model.SeriesDetail
import com.essa.iptvloader.domain.model.ServerCredentials
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ContentRepository @Inject constructor(
    private val api: XtreamApi,
    private val settingsRepository: SettingsRepository
) {
    suspend fun authenticate(creds: ServerCredentials): ApiResult<String> =
        api.authenticate(creds)

    suspend fun movies(): ApiResult<List<Movie>> =
        api.getMovies(settingsRepository.currentCredentials())

    suspend fun series(): ApiResult<List<Series>> =
        api.getSeries(settingsRepository.currentCredentials())

    suspend fun seriesInfo(series: Series): ApiResult<SeriesDetail> =
        api.getSeriesInfo(settingsRepository.currentCredentials(), series)

    suspend fun movieUrl(movie: Movie): String =
        api.movieDownloadUrl(settingsRepository.currentCredentials(), movie)

    suspend fun episodeUrl(episode: com.essa.iptvloader.domain.model.Episode): String =
        api.episodeDownloadUrl(settingsRepository.currentCredentials(), episode)
}
