package com.essa.iptvloader.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.essa.iptvloader.domain.model.ContentKind
import com.essa.iptvloader.domain.model.DownloadItem
import com.essa.iptvloader.domain.model.DownloadPriority
import com.essa.iptvloader.domain.model.DownloadStatus

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val fileName: String,
    val targetPath: String,
    val kind: ContentKind,
    val totalBytes: Long,
    val downloadedBytes: Long,
    val status: DownloadStatus,
    val priority: DownloadPriority,
    val connections: Int,
    val segments: String,
    val error: String?,
    val createdAt: Long
)

fun DownloadEntity.toItem(speed: Long = 0): DownloadItem = DownloadItem(
    id = id,
    url = url,
    fileName = fileName,
    targetPath = targetPath,
    kind = kind,
    totalBytes = totalBytes,
    downloadedBytes = downloadedBytes,
    status = status,
    priority = priority,
    connections = connections,
    speedBytesPerSec = speed,
    error = error
)
