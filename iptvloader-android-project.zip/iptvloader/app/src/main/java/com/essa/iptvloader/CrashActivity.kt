package com.essa.iptvloader

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.essa.iptvloader.ui.theme.IptvLoaderTheme

/**
 * Shown by the global exception handler instead of a silent crash.
 * Displays the full stack trace with the exact file/line, with a copy button.
 */
class CrashActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val trace = intent.getStringExtra(EXTRA_TRACE) ?: "لا توجد تفاصيل."
        setContent {
            IptvLoaderTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    CrashContent(trace = trace, onClose = { finishAffinity() })
                }
            }
        }
    }

    companion object {
        const val EXTRA_TRACE = "trace"
    }
}

@Composable
private fun CrashContent(trace: String, onClose: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "حدث خطأ غير متوقع",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.error
        )
        Text(
            text = "انسخ النص التالي وأرسله للمطور — يحتوي السطر الدقيق الذي سبب المشكلة. " +
                "نسخة محفوظة أيضاً في Download/IptvLoader-crash.txt",
            style = MaterialTheme.typography.bodyMedium
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { clipboard.setText(AnnotatedString(trace)) }) {
                Text(text = "نسخ التقرير")
            }
            OutlinedButton(onClick = onClose) { Text(text = "إغلاق") }
        }
        Text(
            text = trace,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .horizontalScroll(rememberScrollState())
        )
    }
}
