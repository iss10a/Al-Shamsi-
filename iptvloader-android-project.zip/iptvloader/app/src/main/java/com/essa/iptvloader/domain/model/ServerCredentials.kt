package com.essa.iptvloader.domain.model

data class ServerCredentials(
    val serverUrl: String = "",
    val username: String = "",
    val password: String = ""
) {
    val isComplete: Boolean
        get() = serverUrl.isNotBlank() && username.isNotBlank() && password.isNotBlank()

    /** Normalised base like http://host:port with no trailing slash. */
    fun baseUrl(): String {
        var url = serverUrl.trim().trimEnd('/')
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "http://" + url
        }
        return url
    }
}
