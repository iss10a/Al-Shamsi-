package com.essa.iptvloader.data.local

import androidx.room.TypeConverter
import com.essa.iptvloader.domain.model.ContentKind
import com.essa.iptvloader.domain.model.DownloadPriority
import com.essa.iptvloader.domain.model.DownloadStatus

class Converters {
    @TypeConverter fun fromStatus(v: DownloadStatus): String = v.name
    @TypeConverter fun toStatus(v: String): DownloadStatus =
        runCatching { DownloadStatus.valueOf(v) }.getOrDefault(DownloadStatus.QUEUED)

    @TypeConverter fun fromPriority(v: DownloadPriority): String = v.name
    @TypeConverter fun toPriority(v: String): DownloadPriority =
        runCatching { DownloadPriority.valueOf(v) }.getOrDefault(DownloadPriority.NORMAL)

    @TypeConverter fun fromKind(v: ContentKind): String = v.name
    @TypeConverter fun toKind(v: String): ContentKind =
        runCatching { ContentKind.valueOf(v) }.getOrDefault(ContentKind.MOVIE)
}
