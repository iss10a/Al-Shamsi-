package com.essa.iptvloader.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.essa.iptvloader.data.repository.SettingsRepository
import com.essa.iptvloader.domain.model.AppSettings
import com.essa.iptvloader.domain.model.DownloadPriority
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    val settings: StateFlow<AppSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    fun setPriority(priority: DownloadPriority) =
        viewModelScope.launch { settingsRepository.setPriority(priority) }

    fun setConnections(value: Int) =
        viewModelScope.launch { settingsRepository.setConnections(value) }

    fun setMaxDownloads(value: Int) =
        viewModelScope.launch { settingsRepository.setMaxDownloads(value) }
}
