package com.essa.iptvloader

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class IptvLoaderApp : Application()
