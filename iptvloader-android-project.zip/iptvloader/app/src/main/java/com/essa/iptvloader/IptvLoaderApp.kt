package com.essa.iptvloader

import android.app.Application
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.os.Process
import dagger.hilt.android.HiltAndroidApp
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.system.exitProcess

@HiltAndroidApp
class IptvLoaderApp : Application() {

    override fun onCreate() {
        super.onCreate()
        installCrashHandler()
    }

    /**
     * Global exception handler:
     *  1. Writes the full stack trace + device info to crash files.
     *  2. Opens [CrashActivity] showing the exact failing line with a copy button.
     */
    private fun installCrashHandler() {
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            val report = buildReport(thread, throwable)
            writeReportFiles(report)
            runCatching {
                val intent = Intent(this, CrashActivity::class.java)
                    .putExtra(CrashActivity.EXTRA_TRACE, report)
                    .addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP
                    )
                startActivity(intent)
            }
            Process.killProcess(Process.myPid())
            exitProcess(10)
        }
    }

    private fun buildReport(thread: Thread, throwable: Throwable): String {
        val writer = StringWriter()
        throwable.printStackTrace(PrintWriter(writer))
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        return buildString {
            append("==== IPTV Loader crash report ====\n")
            append("Time: ").append(stamp).append('\n')
            append("App version: ").append(BuildConfig.VERSION_NAME)
                .append(" (").append(BuildConfig.VERSION_CODE).append(")\n")
            append("Build type: ").append(BuildConfig.BUILD_TYPE).append('\n')
            append("Device: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
                .append(" — Android ").append(Build.VERSION.RELEASE)
                .append(" (API ").append(Build.VERSION.SDK_INT).append(")\n")
            append("Thread: ").append(thread.name).append('\n')
            append("----------------------------------\n")
            append(writer.toString())
        }
    }

    private fun writeReportFiles(report: String) {
        runCatching {
            File(getExternalFilesDir(null), "crash.txt").appendText(report + "\n\n")
        }
        runCatching {
            val downloads = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS
            )
            if (downloads != null) {
                downloads.mkdirs()
                File(downloads, "IptvLoader-crash.txt").appendText(report + "\n\n")
            }
        }
    }
}
