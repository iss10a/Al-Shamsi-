package com.essa.iptvloader

import android.app.Application
import android.os.Environment
import dagger.hilt.android.HiltAndroidApp
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@HiltAndroidApp
class IptvLoaderApp : Application() {

    override fun onCreate() {
        super.onCreate()
        installCrashLogger()
    }

    /**
     * Writes any uncaught crash to a text file so the user can share it:
     *  - always to: Android/data/com.essa.iptvloader/files/crash.txt
     *  - and, when storage access allows, to: Download/IptvLoader-crash.txt
     */
    private fun installCrashLogger() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            runCatching {
                val writer = StringWriter()
                throwable.printStackTrace(PrintWriter(writer))
                val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
                val text = "==== IPTV Loader crash " + stamp + " ====\n" +
                    "Thread: " + thread.name + "\n" + writer.toString() + "\n\n"

                val internal = File(getExternalFilesDir(null), "crash.txt")
                internal.appendText(text)

                runCatching {
                    val downloads = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS
                    )
                    if (downloads != null) {
                        downloads.mkdirs()
                        File(downloads, "IptvLoader-crash.txt").appendText(text)
                    }
                }
            }
            previous?.uncaughtException(thread, throwable)
        }
    }
}
