package com.essa.iptvloader.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import com.essa.iptvloader.ui.navigation.Destination
import com.essa.iptvloader.ui.screens.downloads.DownloadsScreen
import com.essa.iptvloader.ui.screens.login.LoginScreen
import com.essa.iptvloader.ui.screens.movies.MoviesScreen
import com.essa.iptvloader.ui.screens.series.SeriesScreen
import com.essa.iptvloader.ui.screens.settings.SettingsScreen

@Composable
fun AppRoot() {
    var loggedIn by remember { mutableStateOf(false) }

    if (!loggedIn) {
        LoginScreen(onConnected = { loggedIn = true })
        return
    }

    var current by remember { mutableStateOf<Destination>(Destination.Movies) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                Destination.tabs.forEach { destination ->
                    NavigationBarItem(
                        selected = current == destination,
                        onClick = { current = destination },
                        icon = {
                            Icon(
                                imageVector = destination.icon,
                                contentDescription = stringResource(id = destination.titleRes)
                            )
                        },
                        label = { Text(text = stringResource(id = destination.titleRes)) }
                    )
                }
            }
        }
    ) { padding ->
        androidx.compose.foundation.layout.Box(
            modifier = Modifier.fillMaxSize().padding(padding)
        ) {
            when (current) {
                Destination.Movies -> MoviesScreen()
                Destination.Series -> SeriesScreen()
                Destination.Downloads -> DownloadsScreen()
                Destination.Settings -> SettingsScreen()
            }
        }
    }
}
