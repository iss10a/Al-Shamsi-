package com.essa.iptvloader.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.essa.iptvloader.ui.navigation.Destination
import com.essa.iptvloader.ui.screens.downloads.DownloadsScreen
import com.essa.iptvloader.ui.screens.login.LoginScreen
import com.essa.iptvloader.ui.screens.movies.MoviesScreen
import com.essa.iptvloader.ui.screens.series.SeriesScreen
import com.essa.iptvloader.ui.screens.settings.SettingsScreen

@Composable
fun AppRoot() {
    var loggedIn by rememberSaveable { mutableStateOf(false) }

    if (!loggedIn) {
        LoginScreen(onConnected = { loggedIn = true })
        return
    }

    var current by remember { mutableStateOf<Destination>(Destination.Movies) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                Destination.tabs.forEach { destination ->
                    NavigationBarItem(
                        selected = current == destination,
                        onClick = { current = destination },
                        icon = {
                            Icon(
                                imageVector = destination.icon,
                                contentDescription = stringResource(id = destination.titleRes)
                            )
                        },
                        label = { Text(text = stringResource(id = destination.titleRes)) }
                    )
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding)
        ) {
            StoragePermissionBanner()
            when (current) {
                Destination.Movies -> MoviesScreen()
                Destination.Series -> SeriesScreen()
                Destination.Downloads -> DownloadsScreen()
                Destination.Settings -> SettingsScreen(onLogout = { loggedIn = false })
            }
        }
    }
}

/**
 * On Android 11+ saving into the public Downloads folder needs "All files access".
 * Shown as an in-app banner with an explicit button — never opened automatically.
 */
@Composable
private fun StoragePermissionBanner() {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return

    val context = LocalContext.current
    var refreshKey by remember { mutableIntStateOf(0) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { refreshKey++ }

    val granted = remember(refreshKey) { Environment.isExternalStorageManager() }
    if (granted) return

    Card(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "يحتاج التطبيق صلاحية الوصول للملفات لحفظ التحميلات في مجلد التنزيلات.",
                style = MaterialTheme.typography.bodyMedium
            )
            Button(
                onClick = {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                        .setData(Uri.parse("package:" + context.packageName))
                    runCatching { context.startActivity(intent) }.onFailure {
                        runCatching {
                            context.startActivity(
                                Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                            )
                        }
                    }
                },
                modifier = Modifier.padding(top = 10.dp)
            ) { Text(text = "منح الصلاحية") }
        }
    }
}
