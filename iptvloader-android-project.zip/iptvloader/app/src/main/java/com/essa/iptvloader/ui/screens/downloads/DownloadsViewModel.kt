package com.essa.iptvloader.ui.screens.downloads

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.essa.iptvloader.core.Constants
import com.essa.iptvloader.domain.model.DownloadItem
import com.essa.iptvloader.download.DownloadManager
import com.essa.iptvloader.download.DownloadService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

@HiltViewModel
class DownloadsViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val manager: DownloadManager
) : ViewModel() {

    val items: StateFlow<List<DownloadItem>> = manager.items
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun pause(item: DownloadItem) = DownloadService.action(context, Constants.ACTION_PAUSE, item.id)
    fun resume(item: DownloadItem) {
        DownloadService.action(context, Constants.ACTION_RESUME, item.id)
        DownloadService.start(context)
    }
    fun remove(item: DownloadItem) = DownloadService.action(context, Constants.ACTION_CANCEL, item.id)
}
