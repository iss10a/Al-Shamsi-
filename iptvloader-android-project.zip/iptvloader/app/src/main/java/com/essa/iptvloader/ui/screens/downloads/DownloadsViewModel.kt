package com.essa.iptvloader.ui.screens.downloads

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.essa.iptvloader.core.Constants
import com.essa.iptvloader.domain.model.DownloadItem
import com.essa.iptvloader.download.DownloadManager
import com.essa.iptvloader.download.DownloadService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@HiltViewModel
class DownloadsViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val manager: DownloadManager
) : ViewModel() {

    val items: StateFlow<List<DownloadItem>> = manager.items
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _selected = MutableStateFlow<Set<Long>>(emptySet())
    val selected: StateFlow<Set<Long>> = _selected.asStateFlow()

    fun pause(item: DownloadItem) = DownloadService.action(context, Constants.ACTION_PAUSE, item.id)

    fun resume(item: DownloadItem) {
        DownloadService.action(context, Constants.ACTION_RESUME, item.id)
        DownloadService.start(context)
    }

    fun remove(item: DownloadItem) = DownloadService.action(context, Constants.ACTION_CANCEL, item.id)

    fun toggleSelected(id: Long) {
        _selected.value = _selected.value.let { current ->
            if (id in current) current - id else current + id
        }
    }

    /** Selects every visible item; if everything is already selected, clears the selection. */
    fun toggleSelectAll() {
        val allIds = items.value.map { it.id }.toSet()
        _selected.value = if (_selected.value == allIds) emptySet() else allIds
    }

    fun clearSelection() { _selected.value = emptySet() }

    fun deleteSelected() {
        val ids = _selected.value.toList()
        _selected.value = emptySet()
        viewModelScope.launch {
            ids.forEach { id -> manager.remove(id) }
        }
    }
}
