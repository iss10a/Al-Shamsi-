package com.essa.iptvloader.domain.model

import com.essa.iptvloader.core.Constants

data class AppSettings(
    val priority: DownloadPriority = DownloadPriority.HIGH,
    val connections: Int = Constants.DEFAULT_CONNECTIONS,
    val maxConcurrentDownloads: Int = Constants.DEFAULT_MAX_DOWNLOADS
)
