package com.essa.iptvloader.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tv
import androidx.compose.ui.graphics.vector.ImageVector
import com.essa.iptvloader.R

sealed class Destination(val route: String, val titleRes: Int, val icon: ImageVector) {
    data object Movies : Destination("movies", R.string.tab_movies, Icons.Filled.Movie)
    data object Series : Destination("series", R.string.tab_series, Icons.Filled.Tv)
    data object Downloads : Destination("downloads", R.string.tab_downloads, Icons.Filled.Download)
    data object Settings : Destination("settings", R.string.tab_settings, Icons.Filled.Settings)

    companion object {
        val tabs = listOf(Movies, Series, Downloads, Settings)
    }
}
