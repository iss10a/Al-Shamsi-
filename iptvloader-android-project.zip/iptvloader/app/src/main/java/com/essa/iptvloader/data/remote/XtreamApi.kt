package com.essa.iptvloader.data.remote

import com.essa.iptvloader.core.IoDispatcher
import com.essa.iptvloader.domain.model.Episode
import com.essa.iptvloader.domain.model.Movie
import com.essa.iptvloader.domain.model.SeasonGroup
import com.essa.iptvloader.domain.model.Series
import com.essa.iptvloader.domain.model.SeriesDetail
import com.essa.iptvloader.domain.model.ServerCredentials
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject

sealed class ApiResult<out T> {
    data class Ok<out T>(val data: T) : ApiResult<T>()
    data class Error(val message: String) : ApiResult<Nothing>()
}

/**
 * Client for the Xtream Codes player API used by IPTV panels.
 * Only VOD (movies) and series metadata are requested — no live TV, no streaming.
 */
@Singleton
class XtreamApi @Inject constructor(
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) {

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private fun apiUrl(creds: ServerCredentials, action: String?, extra: Map<String, String> = emptyMap()): String {
        val builder = StringBuilder(creds.baseUrl())
        builder.append("/player_api.php?username=")
        builder.append(encode(creds.username))
        builder.append("&password=")
        builder.append(encode(creds.password))
        if (action != null) {
            builder.append("&action=").append(action)
        }
        for ((key, value) in extra) {
            builder.append("&").append(key).append("=").append(encode(value))
        }
        return builder.toString()
    }

    private fun encode(value: String): String =
        java.net.URLEncoder.encode(value, "UTF-8")

    private suspend fun getJson(url: String): ApiResult<String> = withContext(ioDispatcher) {
        if (url.toHttpUrlOrNull() == null) {
            return@withContext ApiResult.Error("عنوان السيرفر غير صحيح.")
        }
        runCatching {
            val request = Request.Builder().url(url).get().build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@use ApiResult.Error("السيرفر رد بالرمز " + response.code)
                }
                val body = response.body?.string().orEmpty()
                ApiResult.Ok(body)
            }
        }.getOrElse { throwable ->
            ApiResult.Error("تعذر الاتصال: " + (throwable.message ?: throwable.javaClass.simpleName))
        }
    }

    suspend fun authenticate(creds: ServerCredentials): ApiResult<String> {
        return when (val result = getJson(apiUrl(creds, null))) {
            is ApiResult.Error -> result
            is ApiResult.Ok -> runCatching {
                val root = JSONObject(result.data)
                val userInfo = root.optJSONObject("user_info")
                val auth = userInfo?.optInt("auth", 0) ?: 0
                val status = userInfo?.optString("status").orEmpty()
                if (auth == 1 || status.equals("Active", true)) {
                    ApiResult.Ok(userInfo?.optString("username").orEmpty())
                } else {
                    ApiResult.Error("بيانات الدخول غير صحيحة أو الحساب غير مفعّل.")
                }
            }.getOrElse { ApiResult.Error("رد السيرفر غير مفهوم.") }
        }
    }

    suspend fun getMovies(creds: ServerCredentials): ApiResult<List<Movie>> {
        return when (val result = getJson(apiUrl(creds, "get_vod_streams"))) {
            is ApiResult.Error -> result
            is ApiResult.Ok -> runCatching {
                val array = JSONArray(result.data)
                val movies = ArrayList<Movie>(array.length())
                for (i in 0 until array.length()) {
                    val obj = array.optJSONObject(i) ?: continue
                    val id = obj.optInt("stream_id", -1)
                    if (id < 0) continue
                    val name = obj.optString("name").ifBlank { "Movie " + id }
                    val ext = obj.optString("container_extension").ifBlank { "mp4" }
                    movies.add(
                        Movie(
                            streamId = id,
                            name = name,
                            extension = ext,
                            icon = obj.optString("stream_icon").takeIf { it.isNotBlank() },
                            year = obj.optString("year").takeIf { it.isNotBlank() }
                        )
                    )
                }
                ApiResult.Ok(movies as List<Movie>)
            }.getOrElse { ApiResult.Error("تعذر قراءة قائمة الأفلام.") }
        }
    }

    suspend fun getSeries(creds: ServerCredentials): ApiResult<List<Series>> {
        return when (val result = getJson(apiUrl(creds, "get_series"))) {
            is ApiResult.Error -> result
            is ApiResult.Ok -> runCatching {
                val array = JSONArray(result.data)
                val list = ArrayList<Series>(array.length())
                for (i in 0 until array.length()) {
                    val obj = array.optJSONObject(i) ?: continue
                    val id = obj.optInt("series_id", -1)
                    if (id < 0) continue
                    list.add(
                        Series(
                            seriesId = id,
                            name = obj.optString("name").ifBlank { "Series " + id },
                            cover = obj.optString("cover").takeIf { it.isNotBlank() },
                            year = obj.optString("year").takeIf { it.isNotBlank() }
                        )
                    )
                }
                ApiResult.Ok(list as List<Series>)
            }.getOrElse { ApiResult.Error("تعذر قراءة قائمة المسلسلات.") }
        }
    }

    suspend fun getSeriesInfo(creds: ServerCredentials, series: Series): ApiResult<SeriesDetail> {
        val url = apiUrl(creds, "get_series_info", mapOf("series_id" to series.seriesId.toString()))
        return when (val result = getJson(url)) {
            is ApiResult.Error -> result
            is ApiResult.Ok -> runCatching {
                val root = JSONObject(result.data)
                val episodesObj = root.optJSONObject("episodes") ?: JSONObject()
                val seasons = ArrayList<SeasonGroup>()
                val keys = episodesObj.keys()
                while (keys.hasNext()) {
                    val seasonKey = keys.next()
                    val seasonNum = seasonKey.toIntOrNull() ?: continue
                    val epArray = episodesObj.optJSONArray(seasonKey) ?: continue
                    val episodes = ArrayList<Episode>(epArray.length())
                    for (i in 0 until epArray.length()) {
                        val ep = epArray.optJSONObject(i) ?: continue
                        val id = ep.optString("id")
                        if (id.isBlank()) continue
                        val ext = ep.optString("container_extension").ifBlank { "mp4" }
                        val epNum = ep.optInt("episode_num", i + 1)
                        val title = ep.optString("title").ifBlank {
                            series.name + " S" + pad(seasonNum) + "E" + pad(epNum)
                        }
                        episodes.add(Episode(id, title, seasonNum, epNum, ext))
                    }
                    if (episodes.isNotEmpty()) {
                        seasons.add(SeasonGroup(seasonNum, episodes.sortedBy { it.episodeNum }))
                    }
                }
                seasons.sortBy { it.season }
                ApiResult.Ok(SeriesDetail(series, seasons))
            }.getOrElse { ApiResult.Error("تعذر قراءة تفاصيل المسلسل.") }
        }
    }

    fun movieDownloadUrl(creds: ServerCredentials, movie: Movie): String =
        creds.baseUrl() + "/movie/" + encode(creds.username) + "/" + encode(creds.password) +
            "/" + movie.streamId + "." + movie.extension

    fun episodeDownloadUrl(creds: ServerCredentials, episode: Episode): String =
        creds.baseUrl() + "/series/" + encode(creds.username) + "/" + encode(creds.password) +
            "/" + episode.id + "." + episode.extension

    private fun pad(value: Int): String = if (value < 10) "0" + value else value.toString()
}
