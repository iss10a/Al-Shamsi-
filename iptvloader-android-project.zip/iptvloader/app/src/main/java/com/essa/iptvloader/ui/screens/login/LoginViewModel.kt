package com.essa.iptvloader.ui.screens.login

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.essa.iptvloader.data.remote.ApiResult
import com.essa.iptvloader.data.repository.ContentRepository
import com.essa.iptvloader.data.repository.SettingsRepository
import com.essa.iptvloader.domain.model.ServerCredentials
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class LoginUiState(
    val serverUrl: String = "",
    val username: String = "",
    val password: String = "",
    val connecting: Boolean = false,
    val error: String? = null,
    val connected: Boolean = false
)

@HiltViewModel
class LoginViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val contentRepository: ContentRepository
) : ViewModel() {

    private val _state = MutableStateFlow(LoginUiState())
    val state: StateFlow<LoginUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            val creds = settingsRepository.currentCredentials()
            _state.value = _state.value.copy(
                serverUrl = creds.serverUrl,
                username = creds.username,
                password = creds.password
            )
        }
    }

    fun onServer(value: String) { _state.value = _state.value.copy(serverUrl = value, error = null) }
    fun onUser(value: String) { _state.value = _state.value.copy(username = value, error = null) }
    fun onPass(value: String) { _state.value = _state.value.copy(password = value, error = null) }

    fun save() {
        viewModelScope.launch { settingsRepository.saveCredentials(currentCreds()) }
    }

    fun connect() {
        val creds = currentCreds()
        if (!creds.isComplete) {
            _state.value = _state.value.copy(error = "أكمل جميع الحقول.")
            return
        }
        val base = creds.baseUrl()
        if (!base.matches(Regex("https?://[\\w.-]+(:\\d+)?(/.*)?"))) {
            _state.value = _state.value.copy(error = "عنوان السيرفر غير صحيح. مثال: http://host:8080")
            return
        }
        _state.value = _state.value.copy(connecting = true, error = null)
        viewModelScope.launch {
            settingsRepository.saveCredentials(creds)
            when (val result = contentRepository.authenticate(creds)) {
                is ApiResult.Ok ->
                    _state.value = _state.value.copy(connecting = false, connected = true)
                is ApiResult.Error ->
                    _state.value = _state.value.copy(connecting = false, error = result.message)
            }
        }
    }

    fun consumeConnected() { _state.value = _state.value.copy(connected = false) }

    private fun currentCreds() = ServerCredentials(
        serverUrl = _state.value.serverUrl,
        username = _state.value.username,
        password = _state.value.password
    )
}
